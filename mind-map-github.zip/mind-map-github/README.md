# MIND MAP

**An AI-assisted planner for university students.** It keeps classes, extracurricular activities and personal goals in one plan, finds the free time between them, and moves missed work into time that is actually free.

*Plan smarter. Balance better.*

![Dashboard](docs/screenshots/dashboard.png)

## The problem

Students juggle a class routine, clubs and events, assignment deadlines and long-term goals (a skill, an exam, a research paper). These live in different places, so work gets missed, the week becomes overloaded without warning, and long-term goals never get time.

MIND MAP answers three questions, in this order:

1. **What do I do now?** Today in time order, with missed work at the top.
2. **When am I free, and what's coming?** Day, week and month views with free gaps shown.
3. **Am I getting closer to my goals?** Each goal is a plant that grows as its tasks get done.

## Features

| Area | What it does |
|---|---|
| **Class routine** | Add classes by hand, or **import a photo of your routine** (Gemini vision). Extracted rows are shown for review, and nothing is saved until confirmed. Classes repeat inside the semester dates. |
| **Smart add** | Type "Lab report 2h by Friday" or "Call Mitu tomorrow 5pm". It is parsed (duration, day, time, deadline, urgency) and placed in real free time, avoiding clashes. |
| **Goals + AI roadmap** | A goal with a deadline and weekly hours becomes milestones and tasks drafted by AI. **The scheduler, not the AI, decides when each task happens**, within the weekly budget and only in free time. The student edits, then accepts. |
| **Missed tasks** | Unfinished tasks become "missed" at the end of their day. One tap on **Later** moves the task to the best free slot (with Undo). The full dialog shows ranked slots with reasons, a split plan when nothing fits, and a deadline-risk warning. |
| **AI Assistant** | Chat such as "Do I have free time tomorrow?" or "Move it to Thursday". The model only sees free slots the server computed and can only choose among them, so it can't invent free time. |
| **Drag and drop** | In the week view, drag a task into a free gap. The server rejects clashes. |
| **Conflicts** | Overlaps between classes, activities and tasks are detected and shown with fixes. |
| **Extracurricular** | Clubs, workshops, competitions and more, with registration deadlines and status (interested → registered → attended). |
| **Reminders** | For tasks, classes, events and deadlines (1 hour / 1 day / 3 days / 7 days before, or a custom time), shown as in-app and browser notifications. |
| **Hard day mode** | A calm focus screen: one task, a time ring, Done / Later, and an offer to move smaller tasks to later in the week. |
| **Progress** | Tasks done and missed, weekly completion, hours by category, streak, and a **weekly review** at the start of each week. |
| **Miso the cat** | A first-visit tour and **Miso's guide**, a 10-chapter in-app user manual where each chapter has a "Show me" walkthrough on the real page. |
| **Feel** | Light/dark theme, soft optional sounds, small one-shot animations, and a layout that works on phones. |

<table>
<tr>
<td><img src="docs/screenshots/schedule-week.png" alt="Week view"/><br/><sub>My Schedule: week view with free gaps and drag and drop</sub></td>
<td><img src="docs/screenshots/goals.png" alt="Goals"/><br/><sub>Goals as plants</sub></td>
</tr>
<tr>
<td><img src="docs/screenshots/assistant.png" alt="AI Assistant"/><br/><sub>AI Assistant answering from real free time</sub></td>
<td><img src="docs/screenshots/hard-day.png" alt="Hard day mode"/><br/><sub>Hard day mode</sub></td>
</tr>
<tr>
<td><img src="docs/screenshots/guide.png" alt="Miso's guide"/><br/><sub>Miso's guide (user manual)</sub></td>
<td><img src="docs/screenshots/classes.png" alt="Classes"/><br/><sub>Weekly class routine</sub></td>
</tr>
</table>

## Tech stack

| Layer | Choice |
|---|---|
| Frontend | React 19, Vite, React Router, plain CSS design system (light and dark), lucide icons |
| Backend | Node.js, Express |
| Database | SQLite (better-sqlite3), created automatically on first run |
| AI | Groq (`openai/gpt-oss-120b`, then `gpt-oss-20b`), then Gemini as backup; built-in rules if no key or no network |
| Routine OCR | Gemini vision |
| Auth | Email + password (bcrypt), JWT in an httpOnly cookie, password reset by one-time link |
| Tests | Node's built-in test runner (`node --test`) |

## Architecture

```mermaid
flowchart LR
  UI["React client<br/>(pages, dialogs, Miso)"] -->|JSON over /api| API["Express routes"]
  API --> SCHED["Scheduling engine<br/>free time · ranking · conflicts<br/>placement · deadline risk"]
  API --> AI["AI layer<br/>Groq → Gemini → rules"]
  SCHED --> DB[(SQLite)]
  API --> DB
  AI -. reads facts computed by .-> SCHED
```

**Key design rule: the backend owns time.** The scheduling engine (`server/src/lib/scheduler/`) computes busy blocks, free slots, conflicts and deadline feasibility. The AI only drafts content (roadmap tasks, chat wording) and can only pick from options the engine produced. Every move is checked by the server, which answers **409 Conflict** if the time isn't free.

How a slot is chosen: all legal start times before the deadline are scored by priority (sooner for urgent work), the student's preferred study window, how busy that day already is, the daily study limit, and buffer before the deadline. Each result carries plain-language reasons ("light day", "matches your evening study time").

## Data model

```mermaid
erDiagram
  USERS ||--|| USER_PREFERENCES : has
  USERS ||--o{ CLASSES : attends
  USERS ||--o{ GOALS : sets
  GOALS ||--o{ ROADMAPS : "AI drafts"
  GOALS ||--o{ MILESTONES : has
  MILESTONES ||--o{ TASKS : contains
  USERS ||--o{ TASKS : owns
  USERS ||--o{ ACTIVITIES : joins
  USERS ||--o{ REMINDERS : sets
  USERS ||--o{ CHAT_MESSAGES : sends
  TASKS ||--o{ TASK_HISTORY : logs
  USERS ||--o{ PASSWORD_RESETS : requests
```

The full schema is in [`server/src/db.js`](server/src/db.js), and the endpoints are listed in [`docs/API.md`](docs/API.md).

## Getting started

Requirements: Node.js 20+.

```bash
npm install            # root tooling
npm run setup          # installs server and client dependencies
cp server/.env.example server/.env
#   add GROQ_API_KEY and/or GEMINI_API_KEY (both optional; without them the app uses built-in rules)
npm run dev            # API on http://localhost:4000, app on http://localhost:5173
```

Open http://localhost:5173 and choose **Continue as Demo User**. That loads a sample semester for *Kaniz Fatema (BUBT, CSE)*: 8 weekly classes, 3 goals with roadmaps, some missed tasks, clubs and events, and a real conflict. The demo data resets every time you choose it.

Production build: `npm run build && npm start`, which serves everything from http://localhost:4000.

### Suggested demo path
1. Log in as the demo user. Miso's tour explains the Dashboard.
2. **My Schedule → Classes → Import from image** reads a routine photo.
3. **Goals → Create goal → Generate AI Roadmap → Accept.** Tasks land in free time.
4. **Dashboard:** tap **Later** on a missed task, and it moves to the next free slot.
5. **AI Assistant:** "When can I do it instead?"

## Tests

```bash
npm test
```

11 tests cover the scheduling engine (free slots, ranking never overlapping busy time, conflicts and overlap minutes, refusing clashing moves, task splitting, deadline risk, semester dates) and the smart-add parser.

## Project structure

```
server/
  src/
    index.js            Express app and route mounting
    db.js               SQLite schema and small migrations
    auth.js             session cookie + JWT
    seed.js             demo semester
    routes/             account, classes, tasks, goals, activities (+ reminders), views
    lib/
      scheduler.js      re-exports the scheduling engine
      scheduler/        time-blocks · workload · placement · tasks · goals
      planner.js        AI roadmap drafting (+ offline templates)
      assistant.js      chat: facts from the engine, model picks from real slots
      quickadd.js       "Lab report 2h by Friday" parser
      ai.js             Groq / Gemini client with fallbacks
      time.js           local date/time helpers
  test/                 node:test suites
client/
  src/
    App.jsx             routes
    index.css           design tokens and shared styles
    lib/                API client, app state, formatting, sounds, guide content
    components/         layout, dialogs, Miso (Cat, Tour, MisoGuide), Plant, GrowMoment, WeeklyReview
    pages/              Dashboard, My Schedule (pages/schedule/ holds Day, Week, Month), Goals, Roadmap review,
                        Extracurricular, Reminders, AI Assistant, Profile, Settings, Login, Onboarding, Search
docs/
  project-brief.md      the original requirements
  design-decisions.md   why each screen shows what it shows
  API.md                REST endpoints
  screenshots/
```

## Security and privacy notes

- Passwords are hashed with bcrypt. Sessions use an **httpOnly, SameSite=Lax** cookie (also `Secure` in production), so scripts on the page can't read the token.
- Password reset links are single-use, expire after 30 minutes, and only a SHA-256 hash is stored. The reply is identical whether or not the email exists.
- API keys live only in `server/.env`, which git ignores.
- Every data query is scoped to the signed-in user.

## Time zones

All dates and times are stored as **local wall-clock time** without a zone. That is correct for a planner that runs on one student's machine. Hosting it for students in many countries would need a per-user time zone.

## Limitations and future work

- Password-reset email needs SMTP settings; without them the link is printed in the server console.
- Browser notifications only fire while the app is open in a tab (no push service).
- Free AI tiers have rate limits; the app falls back to rule-based answers when they are hit.
- Ideas: calendar (ICS) import and export, shared study groups, push notifications.

## Author

**Kaniz Fatema**, Computer Science & Engineering, Bangladesh University of Business and Technology (BUBT).
