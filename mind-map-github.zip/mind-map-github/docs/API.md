# MIND MAP REST API

All endpoints are under `/api` and speak JSON. After sign-in the server sets an httpOnly session
cookie, which the browser sends automatically. A `Authorization: Bearer <jwt>` header also works (handy for scripts).
Errors come back as `{ "error": "A friendly message" }` with a 4xx/5xx status.

Dates are `YYYY-MM-DD`, datetimes `YYYY-MM-DDTHH:MM` (local time, see the README).

## Account
| Method | Path | Body / query | Returns |
|---|---|---|---|
| POST | `/auth/register` | `name, email, password` | `{ user }` + session cookie |
| POST | `/auth/login` | `email, password` | `{ user }` + session cookie |
| POST | `/auth/demo` | | Resets and signs in the demo student |
| POST | `/auth/logout` | | Clears the cookie |
| POST | `/auth/forgot` | `email` | Always `{ ok, delivery }` (email or server console) |
| POST | `/auth/reset` | `token, password` | `{ user }` + session cookie |
| GET | `/me` | | `{ user, preferences }` |
| PUT | `/me` | `name, department, university, year, onboarded` | `{ user }` |
| PUT | `/me/preferences` | `day_start, day_end, sleep_start, sleep_end, preferred_study, max_daily_minutes, week_start, semester_start, semester_end, theme, …` | `{ preferences }` |
| PUT | `/me/password` | `current, next` | `{ ok }` |
| DELETE | `/me/data` | | Removes all planner data, keeps the account |

## Classes
| Method | Path | Notes |
|---|---|---|
| GET | `/classes` | Weekly classes: `course_code, title, day (0 = Sunday), start_time, end_time, room, instructor` |
| POST / PUT / DELETE | `/classes`, `/classes/:id` | Create, edit, delete |
| POST | `/classes/bulk` | `{ classes: [...] }`, skips exact duplicates |
| POST | `/classes/import-image` | Multipart field `image`. Returns extracted rows only; nothing is saved until `/classes/bulk` |

## Tasks
| Method | Path | Notes |
|---|---|---|
| GET | `/tasks?status=&goal_id=&from=&to=&priority=&q=` | Filtered list |
| POST | `/tasks` | `title, estimated_minutes, deadline, priority, goal_id`, plus `scheduled_start` **or** `auto_schedule` (with optional `date`) |
| POST | `/tasks/quick` | `{ text }` e.g. "Lab report 2h by Friday". Parsed and placed in free time |
| PUT / DELETE | `/tasks/:id` | Edit, delete |
| POST | `/tasks/:id/complete`, `/uncomplete`, `/missed`, `/status` | Status changes. `complete` returns goal growth and celebrations |
| GET | `/tasks/:id/suggestions?after=` | Ranked free slots with reasons, a split plan if nothing fits, deadline risk |
| POST | `/tasks/:id/move` | `{ start, end }`. **409** if it overlaps anything |
| POST | `/tasks/:id/split` | `{ chunks }` from the split plan |
| POST | `/tasks/lighten` | Hard-day helper: moves today's non-urgent tasks to later this week |

## Goals and AI roadmaps
| Method | Path | Notes |
|---|---|---|
| GET / POST | `/goals` | List with progress and feasibility, create |
| GET / PUT / DELETE | `/goals/:id` | Goal with milestones and tasks |
| POST | `/goals/:id/roadmap` | AI draft (5–25 s). Tasks are placed by the scheduler, not the AI |
| GET / PUT | `/goals/roadmaps/:rid` | Read or edit a draft (the server re-places tasks after edits) |
| POST | `/goals/roadmaps/:rid/accept` | Writes milestones and tasks into the schedule |

## Activities and reminders
| Method | Path | Notes |
|---|---|---|
| GET / POST / PUT / DELETE | `/activities`, `/activities/:id` | Saving returns any `conflicts` it creates |
| GET / POST / PUT / DELETE | `/reminders`, `/reminders/:id` | Offsets: `1h, 1d, 3d, 7d` or a custom time |
| GET | `/reminders/due` | Polled every minute by the app |

## Views
| Method | Path | Notes |
|---|---|---|
| GET | `/dashboard` | Today, missed tasks, deadlines, goals, week load, streak, conflicts, risks |
| GET | `/timeline?from=&to=` | Days with items, free slots, deadlines, reminders, load (≤ 62 days) |
| GET | `/free?from=&to=` | Free slots per day |
| GET | `/conflicts`, POST `/conflicts/ignore` | Overlaps, and hiding one |
| GET | `/progress` | Totals, weekly completion, hours by category, streak |
| GET | `/review?week=` | Weekly review for a week (defaults to last week) |
| GET | `/search?q=&type=&priority=&status=&from=&to=` | Across tasks, goals, classes, activities |
| GET / DELETE | `/assistant/messages` | Chat history |
| POST | `/assistant/chat` | `{ message, focus_task_id?, slot? }`. The model can only choose among slots the server computed |
