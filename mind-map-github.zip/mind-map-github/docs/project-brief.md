Build a responsive web application called **MIND MAP**.

MIND MAP is an AI-assisted student planning system that helps students manage three major areas in one place:

1. Academic routine
2. Extracurricular activities
3. Personal goals

The main problem the system solves is poor time management and difficulty balancing classes, extracurricular activities, deadlines, and long-term personal goals.

The application should feel useful, modern, lightweight, and enjoyable to use. Avoid making it look like a generic admin dashboard. It should feel like a smart personal planner designed specifically for students.

---

# 1. Core Concept

A student should be able to:

- Add or upload a class routine
- Automatically create recurring class schedules
- Add extracurricular activities
- Add personal goals
- Generate an AI-based roadmap for a personal goal
- See daily and weekly tasks
- See upcoming deadlines
- See completed and upcoming extracurricular activities
- Track goal progress
- Receive reminders
- Detect schedule conflicts
- Automatically reschedule missed tasks
- Talk with an AI chatbot when deciding where to reschedule a missed task
- See everything together in one organized timeline

The platform should initially be web-based and fully responsive for desktop, tablet, and mobile.

---

# 2. Suggested Technology Stack

Use:

Frontend:
- React.js
- JavaScript
- HTML
- CSS

Backend:
- Node.js
- Express.js

Database:
- SQLite

AI:
- Gemini API or another free/low-cost AI API

Authentication:
- Simple email/password authentication

Routine Image Processing:
- Gemini Vision, OCR API, Tesseract, or another suitable free solution

Notifications:
- Browser notifications
- In-app reminders

Do not overcomplicate the technology stack.

---

# 3. Visual Style

Create a clean, modern, student-friendly interface.

The visual style should feel:

- Calm
- Smart
- Organized
- Friendly
- Slightly playful
- Minimal but not boring

Do not make the interface overly corporate.

Use soft cards, rounded corners, clean spacing, subtle borders, and light shadows.

Suggested visual direction:

- White or soft neutral background
- A strong primary accent such as purple, indigo, blue, teal, or a combination
- Soft success green
- Warm warning orange
- Red only for urgent deadlines or errors
- Muted gray for secondary information

Use color meaningfully.

Examples:

Purple = Personal goals

Blue = Academic classes

Green = Completed tasks

Orange = Upcoming deadlines

Teal = Extracurricular activities

Red = Conflicts or overdue tasks

Support dark mode if possible.

---

# 4. Main Navigation

Create a left sidebar on desktop and a bottom navigation or compact menu on mobile.

Main navigation items:

- Dashboard
- My Schedule
- Goals
- AI Planner
- Extracurricular
- Timeline
- Reminders
- Progress
- AI Assistant
- Profile
- Settings

The currently active section should be visually clear.

Add subtle animated transitions when moving between sections.

---

# 5. Dashboard

The dashboard should immediately show the student what matters today.

Top section:

"Good morning, [Student Name]"

Below it show something contextual such as:

"3 tasks today · 2 upcoming deadlines · 1 extracurricular event this week"

Add a small motivational message but keep it short.

Example:

"One step at a time. Your week is looking manageable."

Main dashboard cards:

## Today's Schedule

Show a vertical timeline with time blocks.

Example:

9:00 AM
CSE 327 Class

11:30 AM
Research Meeting

2:00 PM
React Practice

5:00 PM
Programming Club

Each item should have:

- Time
- Title
- Type
- Duration
- Status
- Optional icon

Use different colors for academic, personal goals, and extracurricular activities.

## Upcoming Deadlines

Show the nearest deadlines first.

Each card should show:

- Task name
- Deadline
- Time remaining
- Priority

Example:

React Assignment
Due tomorrow
High Priority

## Goal Progress

Show active goals with progress bars.

Example:

Become a Frontend Developer
68%

IELTS Preparation
42%

Research Paper
25%

Use smooth animated progress bars when the page loads.

## Extracurricular Overview

Show:

- Upcoming activities
- Completed activities
- Registration deadlines

Example:

Upcoming: 4
Completed: 8
Registration deadlines: 2

## Weekly Load

Show a compact weekly view.

Example:

Mon: Medium
Tue: Busy
Wed: Light
Thu: Very Busy
Fri: Free

This can be represented through small bars or heatmap-style blocks.

---

# 6. Class Routine Management

Create a section called "My Schedule".

Allow the student to manually add a class.

Fields:

- Course code
- Course title
- Day
- Start time
- End time
- Room
- Instructor
- Recurrence

Support weekly recurring classes.

Add a visual weekly calendar grid.

Example:

Columns:
Sunday
Monday
Tuesday
Wednesday
Thursday
Friday
Saturday

Rows:
8 AM
9 AM
10 AM
etc.

Class cards should appear inside the appropriate time slots.

Allow drag-and-drop only if easy to implement.

If drag-and-drop is not included, allow edit and delete through a menu.

---

# 7. Routine Image Upload

Add a feature called:

"Import Routine from Image"

The student can upload:

- Screenshot
- JPG
- PNG
- Scanned routine image

Show a drag-and-drop upload area.

After upload:

1. Show loading animation
2. Extract the routine
3. Display extracted classes in editable rows
4. Let the user correct mistakes
5. Let the user confirm

Example extracted result:

CSE 327
Sunday
9:40 AM – 11:10 AM
Room 301

CSE 323
Tuesday
1:00 PM – 2:30 PM
Room 405

Add:

"Looks correct"
"Edit"
"Try again"

Never directly save extracted information without confirmation.

---

# 8. Personal Goals

Create a "Goals" section.

The user should be able to create a goal.

Fields:

- Goal title
- Description
- Target deadline
- Current level
- Weekly available time
- Priority
- Preferred study time
- Existing knowledge
- Optional budget
- Notes

Example:

Goal:
Become a Frontend Developer

Deadline:
6 months

Current level:
Beginner

Available time:
8 hours/week

When a goal is created, show:

"Generate AI Roadmap"

---

# 9. AI Roadmap Generator

The AI planner should create a structured roadmap based on:

- Goal
- Deadline
- Current skill level
- Available weekly hours
- Existing class schedule
- Extracurricular activities
- Other active goals
- Existing workload
- Free time slots

The generated roadmap should include:

- Milestones
- Weekly tasks
- Estimated duration
- Suggested deadlines
- Suggested resources
- Difficulty
- Priority
- Expected progress

Example:

Milestone 1
HTML & CSS Foundations
Duration: 2 weeks

Tasks:
- Learn semantic HTML
- Learn Flexbox
- Learn CSS Grid
- Build a landing page

Estimated weekly time:
6 hours

Recommended resources:
- MDN
- freeCodeCamp

The user must be able to:

- Accept roadmap
- Edit roadmap
- Regenerate roadmap
- Delete a task
- Change deadline
- Change task duration
- Add custom tasks

After confirmation, roadmap tasks should be added to the schedule.

---

# 10. Extracurricular Activity Management

Create a section called "Extracurricular".

Allow users to add:

- Club activity
- Competition
- Workshop
- Seminar
- Hackathon
- Volunteer work
- Sports
- Cultural event
- Career fair
- Other

Fields:

- Activity title
- Category
- Description
- Registration deadline
- Event date
- Start time
- End time
- Location
- Priority
- Status
- Notes

Statuses:

- Interested
- Registered
- Upcoming
- Completed
- Cancelled

Show activities as cards.

Each card should visually display status.

Add tabs:

- Upcoming
- Registered
- Completed
- All

---

# 11. Unified Timeline

Create a visual timeline combining:

- Classes
- Personal goal tasks
- Extracurricular activities
- Deadlines
- Reminders

Allow views:

- Today
- Week
- Month
- Timeline

Example:

9:00 AM
CSE 327

11:30 AM
Free

1:00 PM
React Practice

3:00 PM
Free

5:00 PM
Club Meeting

Free time should be visually visible.

This is important because free time is used for rescheduling tasks.

---

# 12. Conflict Detection

If two activities overlap, show a clear warning.

Example:

Schedule Conflict

CSE 327
2:00 PM – 3:30 PM

Programming Workshop
3:00 PM – 5:00 PM

Overlap:
30 minutes

Provide options:

- Change workshop time
- Ignore
- Edit activity
- Ask AI Assistant

Use subtle shake or highlight animation for conflict warnings.

Do not use aggressive red flashing.

---

# 13. Automatic Rescheduling

If a student does not complete a task scheduled for that day, the system should automatically detect it.

At the end of the day or when the student marks it as unfinished:

Show:

"You didn't complete this task."

Task:
React Hooks Practice

Estimated time:
1 hour

Deadline:
Friday

The system should:

1. Check free time before deadline
2. Check class schedule
3. Check extracurricular activities
4. Check other tasks
5. Check task priority
6. Check workload of each day
7. Find suitable free slots

Then display suggestions.

Example:

Best time:
Wednesday
6:00 PM – 7:00 PM

Other options:
Thursday 4:00 PM – 5:00 PM
Friday 10:00 AM – 11:00 AM

Buttons:

- Reschedule
- Ask AI
- Choose manually

---

# 14. AI Chatbot for Rescheduling

Create an AI Assistant panel.

The user should be able to speak naturally.

Example:

User:
"I don't want to do this Wednesday evening. What other options do I have?"

AI:
"You have a free one-hour slot Thursday from 4:00 PM to 5:00 PM. Friday morning is also free, but Thursday is safer because your deadline is Friday."

User:
"Move it to Thursday."

AI:
"Done. I moved React Hooks Practice to Thursday from 4:00 PM to 5:00 PM."

The AI should never invent free time.

The backend must provide actual free slots.

The AI should only discuss available options and recommend one.

---

# 15. AI Assistant Capabilities

The chatbot should support questions such as:

- "What should I focus on today?"
- "Do I have free time tomorrow?"
- "Can I move this task to Friday?"
- "Why is Tuesday so busy?"
- "Can I finish this goal before December?"
- "Move my unfinished task to the next best slot."
- "Which task is most urgent?"
- "Show me my upcoming extracurricular activities."
- "Reduce my workload on Thursday."

The chatbot should feel conversational and helpful.

---

# 16. Daily Overview

Create a daily planner.

Show:

- Classes
- Goal tasks
- Extracurricular activities
- Reminders
- Deadlines
- Free time

At the top show:

Today's Focus

Example:

1. Complete React Assignment
2. Attend CSE 327
3. Register for Programming Contest

Add a progress ring:

4 of 6 tasks completed

Animate the ring smoothly.

---

# 17. Weekly Overview

Create a weekly planning screen.

Show all seven days.

Each day should display:

- Number of classes
- Number of tasks
- Extracurricular activities
- Workload level

Example:

Monday
3 classes
2 tasks
Medium

Tuesday
2 classes
5 tasks
Very Busy

Wednesday
1 class
2 tasks
Light

Add a small workload bar.

---

# 18. Progress Page

Create a progress dashboard.

Show:

- Goal completion percentage
- Completed tasks
- Missed tasks
- Rescheduled tasks
- Extracurricular activities completed
- Weekly consistency
- Average task completion rate

Do not overdo analytics.

Keep charts simple.

Possible charts:

- Weekly task completion
- Goal progress
- Activity breakdown
- Time spent by category

---

# 19. Reminder System

Allow reminders for:

- Classes
- Deadlines
- Goal tasks
- Extracurricular events
- Registration deadlines

Options:

- 1 hour before
- 1 day before
- 3 days before
- 7 days before
- Custom

Show reminder cards.

Example:

Programming Contest Registration
Tomorrow
10:00 AM

---

# 20. Micro-Interactions

The app should feel alive through small interactions.

Use subtle animations.

Examples:

## Buttons

On hover:
- Slight scale
- Soft background change
- Small shadow increase

On click:
- Quick scale-down effect

Do not overanimate.

## Cards

When hovering over a task card:
- Lift slightly
- Show quick actions

Quick actions:
- Complete
- Edit
- Reschedule

## Task Completion

When a task is completed:

- Checkbox animates
- Card briefly turns green
- Progress bar updates
- Small confetti burst or sparkle effect

Keep confetti very subtle.

Use it only for meaningful actions such as:

- Completing a major milestone
- Completing a personal goal

Do not show confetti for every tiny task.

## Progress Bars

Animate from previous value to new value.

## Notifications

Use small slide-in toast notifications.

Example:

"Task moved to Thursday, 4:00 PM"

## Adding Tasks

When a new task is added:

- Slide it smoothly into the timeline

## Removing Tasks

Fade out instead of instantly disappearing.

---

# 21. Fun Elements

Make the system enjoyable without becoming childish.

Ideas:

## Streak

Show:

"4 productive days in a row"

Use a small flame icon.

Do not punish the user if a streak breaks.

## Weekly Summary

At the end of the week show:

"This week you completed 14 tasks, attended 3 activities, and made 18% progress toward your goals."

## Small Celebrations

When a goal reaches:

25%
50%
75%
100%

Show subtle celebratory feedback.

Example:

"Halfway there!"

## Mood / Workload Indicator

Show:

Your week looks:

Relaxed
Balanced
Busy
Overloaded

Based on scheduled hours.

---

# 22. Empty States

Do not leave empty pages blank.

Examples:

No goals:

"Your next big goal starts here."

Button:
Create Goal

No activities:

"Nothing planned yet. Add your first extracurricular activity."

No tasks today:

"Your schedule is clear today."

No reminders:

"You're all caught up."

Add simple illustrations or icons.

---

# 23. Search and Filtering

Add global search.

Users should be able to search:

- Goals
- Tasks
- Courses
- Extracurricular activities

Allow filters:

- Date
- Priority
- Type
- Status
- Goal
- Category

---

# 24. Priority System

Use:

High
Medium
Low

High priority should be visually noticeable but not overly alarming.

The scheduling system should consider priority during automatic rescheduling.

---

# 25. Task Status

Support:

- Pending
- In Progress
- Completed
- Missed
- Rescheduled
- Cancelled

---

# 26. Free Time Detection

The system should calculate free time based on:

- Classes
- Extracurricular activities
- Existing tasks
- Sleep hours if provided
- User preferred study hours

Example:

Tuesday

Free:
11:30 AM – 1:00 PM
4:00 PM – 6:00 PM
8:00 PM – 10:00 PM

Use this information for scheduling.

---

# 27. Automatic Task Scheduling Logic

Do not rely only on AI.

The backend should handle actual time logic.

When placing a task:

1. Get task duration
2. Get task deadline
3. Get priority
4. Get user's preferred work hours
5. Get occupied time slots
6. Find available slots
7. Exclude conflicting slots
8. Rank valid free slots
9. Choose the best slot
10. Save the schedule

AI may help explain the recommendation.

---

# 28. Task Splitting

If a 3-hour task cannot fit into one free slot, allow splitting.

Example:

Original task:
Complete JavaScript Project
3 hours

Suggested split:

Tuesday
1 hour

Wednesday
1 hour

Thursday
1 hour

Ask the user before splitting.

---

# 29. Deadline Risk Warning

If there is not enough free time before a deadline:

Show:

"Deadline at Risk"

Example:

Task:
Research Report

Required:
5 hours

Available free time before deadline:
2.5 hours

Provide options:

- Extend deadline
- Split task
- Reduce lower-priority tasks
- Ask AI for advice

---

# 30. Responsive Design

Desktop:

Use sidebar and multi-column dashboard.

Tablet:

Use compact sidebar or top navigation.

Mobile:

Use bottom navigation.

Important mobile tabs:

- Home
- Timeline
- Add
- AI
- Profile

Make all interactions touch-friendly.

---

# 31. Login Page

Create a clean login page.

Include:

MIND MAP logo

Tagline:

"Plan smarter. Balance better."

Fields:

- Email
- Password

Buttons:

- Log In
- Create Account

Optional:

"Continue as Demo User"

---

# 32. Onboarding

After first login, guide the user through setup.

Step 1:
Add basic profile information

Step 2:
Upload or create class routine

Step 3:
Add extracurricular activities

Step 4:
Create first personal goal

Step 5:
Generate AI roadmap

Show progress:

1 of 5

Keep onboarding skippable.

---

# 33. Dashboard Quick Add

Add a floating or prominent "+" button.

When clicked show:

Add:

- Class
- Task
- Goal
- Extracurricular Activity
- Reminder

Use a smooth expanding menu animation.

---

# 34. Data Storage with SQLite

Use SQLite tables such as:

Users

Classes

Goals

Roadmaps

RoadmapTasks

ExtracurricularActivities

Reminders

ChatMessages

Notifications

UserPreferences

TaskHistory

Suggested basic relationships:

User
→ Classes

User
→ Goals
→ Roadmap
→ Tasks

User
→ Activities

User
→ Reminders

---

# 35. Suggested Database Fields

Users:
- id
- name
- email
- password
- department
- preferences

Classes:
- id
- user_id
- course_code
- title
- day
- start_time
- end_time
- room
- recurring

Goals:
- id
- user_id
- title
- description
- start_date
- deadline
- priority
- progress
- status

RoadmapTasks:
- id
- goal_id
- title
- description
- estimated_duration
- scheduled_start
- scheduled_end
- deadline
- priority
- status

ExtracurricularActivities:
- id
- user_id
- title
- category
- registration_deadline
- event_date
- start_time
- end_time
- location
- status

Reminders:
- id
- user_id
- reference_type
- reference_id
- reminder_time
- status

---

# 36. Important AI Rule

Do not give AI complete control of the schedule.

The application backend should calculate:

- Actual conflicts
- Available slots
- Task durations
- Deadline feasibility

The AI assistant should help with:

- Roadmap generation
- Explaining recommendations
- Helping the student choose between available options
- Suggesting workload improvements
- Conversational rescheduling

---

# 37. Important UX Rules

Do not overwhelm the user.

Show the most important information first.

Use progressive disclosure.

For example:

Dashboard:
Only show today's important information.

Detailed pages:
Show full information.

Avoid unnecessary popups.

Use modal dialogs only for important actions.

Keep forms simple.

---

# 38. Animation Style

Animations should feel smooth and modern.

Use:

- 150–300ms transitions
- Ease-out motion
- Soft fade
- Slide
- Slight scale

Avoid:

- Large bouncing
- Excessive spinning
- Flashing
- Long animations

The system should still feel fast.

---

# 39. Important Screens to Build

Create these screens:

1. Login
2. Registration
3. Onboarding
4. Dashboard
5. Weekly Schedule
6. Routine Image Upload
7. Extracurricular Activities
8. Goals
9. Goal Details
10. AI Roadmap Generator
11. Roadmap Review
12. Timeline
13. Daily Planner
14. Weekly Planner
15. Progress
16. Reminders
17. AI Assistant
18. Profile
19. Settings

---

# 40. Main User Journey

A typical user journey should be:

Student creates account

↓

Uploads class routine

↓

System extracts classes

↓

Student confirms routine

↓

Student adds extracurricular activities

↓

Student creates a personal goal

↓

System calculates current free time

↓

AI generates realistic roadmap

↓

Student reviews roadmap

↓

Student accepts roadmap

↓

Tasks are placed into free time

↓

Student sees daily and weekly plan

↓

Student misses a task

↓

System finds available slots

↓

AI assistant discusses alternatives

↓

Student selects a new time

↓

Task is rescheduled

↓

Timeline and progress update automatically

---

# 41. Project Personality

The app should feel like:

"A smart student companion that quietly keeps your life organized."

Do not make the AI assistant overly robotic.

Use friendly responses such as:

"You have a free hour Thursday afternoon. That looks like the safest place for this task."

Instead of:

"The optimal task rescheduling slot has been determined."

Keep the language natural.

---

# 42. Final Product Goal

The final application should make it easy for a student to answer:

- What do I need to do today?
- What is due soon?
- When am I free?
- What extracurricular activities are coming up?
- Am I overloaded this week?
- Am I making progress toward my goals?
- If I miss a task, when should I do it instead?
- Can AI help me create a realistic plan for my goal?

The application should present this information visually, clearly, and in an enjoyable way.

Build MIND MAP as a polished, realistic Software Engineering project rather than a simple to-do application with an AI chatbot attached.