# MIND MAP: design decisions

## Problem (from the brief)

Students lose track of classes, clubs, deadlines and long-term goals, so work gets missed and goals never get time.
MIND MAP answers three questions, in this order:

1. **What do I do now?** (today, in time order)
2. **When am I free, and what's coming?** (the week)
3. **Am I getting closer to my goals?** (goals and their plans)

Anything that doesn't answer one of these stays off the main screens.

## Decisions

- **Audience:** the student, and the teacher watching a demo. When they conflict, clarity for the demo wins.
- **Menu:** unchanged, as the student asked: Dashboard, My Schedule, Goals, Extracurricular, Reminders, AI Assistant (+ Profile, Settings).
- **One job per screen.** Each screen gets one title, at most one primary action, and one main list or grid.
- **One source of truth per piece of information:**
  - Missed tasks are shown in the Today list, not in a separate card.
  - The current task is highlighted inside the list, not repeated in a separate "Now" card.
  - Goal progress is the plant on Goals and in the garden. There are no extra goal bars.
- **Miso** appears only in the first-visit tour, empty states, the alarm, and the goal-growth moment. There is no permanent speech bubble.

## Screens

| Screen | Job | Shows | Removed |
|---|---|---|---|
| **Dashboard** | What do I do now? | Greeting + streak; smart add box; **Today list** (missed first, then today's items in time order, the current one marked "Now", free gaps as thin lines, Done/Later on tasks); side: garden (small), next 3 deadlines; Progress as one compact stats row with "Show details" | Now card, day bar card, attention chip, Miso bubble, mood picker row (becomes a small "Hard day?" toggle) |
| **My Schedule** | When am I free? | Tabs **Day · Week · Month · Classes** | Timeline tab (same as Week), Daily/Weekly planner buttons and pages (duplicates of Day/Week) |
| **Goals** | Am I getting closer? | Plant cards: title, stage and %, next task, one button (Open / Generate AI Roadmap / Review draft) | Feasibility sentence, cheer pill, deadline sentence on cards (kept on the goal page) |
| Extracurricular, Reminders, AI Assistant | unchanged | | |

Old addresses redirect: `/day` → `/schedule`, `/week` → `/schedule?view=week`, `/timeline` → `/schedule`, `/progress` → `/#progress`, `/planner` → `/goals`.

## Demo journey this must support (for the teacher)

1. Log in as demo, and the tour explains the Dashboard.
2. Schedule → Classes → Import from image, and the classes appear.
3. Goals → Create goal → Generate AI Roadmap → review → accept, and the tasks land in free time.
4. Dashboard: a missed task is at the top of Today, tap Later, and it moves to the next free slot (Undo available).
5. AI Assistant: "When can I do it instead?" answers with real free slots.

## Testing

- Existing server tests keep passing.
- Browser check: each screen at 1440px and 390px, no console errors, and the demo journey above runs end to end.
