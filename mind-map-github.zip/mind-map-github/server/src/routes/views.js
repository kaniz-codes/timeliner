// Read-heavy composite endpoints: dashboard, timeline, progress, search, conflicts, assistant.
import { Router } from 'express';
import { db } from '../db.js';
import { requireAuth, h } from '../auth.js';
import * as T from '../lib/time.js';
import {
  busyBlocks, freeSlots, workload, conflicts, deadlineRisks, suggestSlots, goalStats, sweepMissed, httpError, streakFor,
} from '../lib/scheduler.js';
import { chat } from '../lib/assistant.js';
import { hydrate } from './tasks.js';

export const router = Router();
router.use(requireAuth);

const PRIORITY_RANK = { high: 0, medium: 1, low: 2 };

function upcomingDeadlines(userId, days = 7) {
  const from = T.today();
  const to = T.addDays(from, days);
  const tasks = db.prepare(
    `SELECT t.id, t.title, t.deadline, t.priority, t.status, t.estimated_minutes, g.title AS goal_title FROM tasks t
     LEFT JOIN goals g ON g.id = t.goal_id
     WHERE t.user_id = ? AND t.deadline BETWEEN ? AND ? AND t.status NOT IN ('completed','cancelled')`
  ).all(userId, from, `${to}T23:59`);
  // Goal tasks share their milestone deadline; only surface the ones that are standalone or high priority.
  const regs = db.prepare(
    `SELECT id, title, registration_deadline, priority, status, category FROM activities
     WHERE user_id = ? AND registration_deadline BETWEEN ? AND ? AND status IN ('interested','upcoming')`
  ).all(userId, from, to);
  return [
    ...tasks.map((t) => ({ kind: 'task', id: t.id, title: t.title, due: t.deadline, priority: t.priority, status: t.status, context: t.goal_title || 'Task' })),
    ...regs.map((a) => ({ kind: 'registration', id: a.id, title: `Register: ${a.title}`, due: a.registration_deadline, priority: a.priority, status: a.status, context: a.category })),
  ].sort((a, b) => a.due.localeCompare(b.due) || PRIORITY_RANK[a.priority] - PRIORITY_RANK[b.priority]);
}

function dayItems(userId, date) {
  return busyBlocks(userId, date, date).map((b) => ({ ...b, minutes: T.minutesBetween(b.start, b.end) }));
}

function motivation(mood, missed) {
  if (missed > 2) return 'A few things slipped. Pick one and give it a new time; the rest can wait.';
  return {
    Relaxed: 'Plenty of breathing room this week. A good time to get ahead on a goal.',
    Balanced: 'One step at a time. Your week is looking manageable.',
    Busy: 'Full week, but it fits. Start with the first thing.',
    Overloaded: 'This week is heavy. Let\'s move what can wait.',
  }[mood];
}

function weeklySummary(userId) {
  const since = T.addDays(T.today(), -6);
  const done = db.prepare("SELECT COUNT(*) AS n, COALESCE(SUM(estimated_minutes),0) AS m FROM tasks WHERE user_id = ? AND status = 'completed' AND completed_at >= ?").get(userId, since);
  const acts = db.prepare("SELECT COUNT(*) AS n FROM activities WHERE user_id = ? AND status = 'completed' AND event_date >= ?").get(userId, since).n;
  const goalDone = db.prepare(
    `SELECT COALESCE(SUM(t.estimated_minutes),0) AS m FROM tasks t JOIN goals g ON g.id = t.goal_id
     WHERE t.user_id = ? AND t.status = 'completed' AND t.completed_at >= ?`
  ).get(userId, since).m;
  const goalTotal = db.prepare(
    "SELECT COALESCE(SUM(estimated_minutes),0) AS m FROM tasks WHERE user_id = ? AND goal_id IS NOT NULL AND status != 'cancelled'"
  ).get(userId).m;
  const pct = goalTotal ? Math.round((goalDone / goalTotal) * 100) : 0;
  return {
    tasks: done.n, minutes: done.m, activities: acts, goalPercent: pct,
    text: `This week you completed ${done.n} task${done.n === 1 ? '' : 's'}, attended ${acts} activit${acts === 1 ? 'y' : 'ies'}, and made ${pct}% progress toward your goals.`,
  };
}

router.get('/dashboard', (req, res) => {
  const uid = req.userId;
  sweepMissed(uid);
  const today = T.today();
  const user = db.prepare('SELECT name FROM users WHERE id = ?').get(uid);
  const items = dayItems(uid, today);
  const todayTasks = items.filter((i) => i.kind === 'task');
  const free = freeSlots(uid, today, today, { nowDt: `${today}T00:00` })[today];
  const prefsWeek = db.prepare('SELECT week_start FROM user_preferences WHERE user_id = ?').get(uid)?.week_start || 0;
  const weekStart = T.startOfWeek(today, prefsWeek);
  const week = workload(uid, weekStart, T.addDays(weekStart, 6));

  const missed = db.prepare(
    `SELECT t.*, g.title AS goal_title FROM tasks t LEFT JOIN goals g ON g.id = t.goal_id
     WHERE t.user_id = ? AND t.status = 'missed' AND (t.deadline IS NULL OR t.deadline >= ?)
     ORDER BY CASE t.priority WHEN 'high' THEN 0 WHEN 'medium' THEN 1 ELSE 2 END, COALESCE(t.deadline, '9999')`
  ).all(uid, today).map((t) => ({
    ...hydrate(t),
    suggestion: suggestSlots(uid, { minutes: t.estimated_minutes, deadline: t.deadline, priority: t.priority, excludeTaskId: t.id, limit: 1 })[0] || null,
  }));

  const deadlines = upcomingDeadlines(uid, 7);
  // Completed goals stay so their fully grown plants show in the garden.
  const goals = db.prepare("SELECT * FROM goals WHERE user_id = ? AND status IN ('active','completed') ORDER BY CASE status WHEN 'active' THEN 0 ELSE 1 END, deadline").all(uid)
    .map((g) => ({ id: g.id, title: g.title, deadline: g.deadline, priority: g.priority, ...goalStats(g.id) }));
  const ex = {
    upcoming: db.prepare("SELECT COUNT(*) AS n FROM activities WHERE user_id = ? AND event_date >= ? AND status NOT IN ('cancelled','completed')").get(uid, today).n,
    completed: db.prepare("SELECT COUNT(*) AS n FROM activities WHERE user_id = ? AND status = 'completed'").get(uid).n,
    registrations: db.prepare("SELECT COUNT(*) AS n FROM activities WHERE user_id = ? AND registration_deadline >= ? AND status IN ('interested','upcoming')").get(uid, today).n,
    next: db.prepare("SELECT * FROM activities WHERE user_id = ? AND event_date >= ? AND status NOT IN ('cancelled','completed') ORDER BY event_date, start_time LIMIT 3").all(uid, today),
  };
  const eventsThisWeek = db.prepare("SELECT COUNT(*) AS n FROM activities WHERE user_id = ? AND event_date BETWEEN ? AND ? AND status NOT IN ('cancelled','completed')").get(uid, today, T.addDays(today, 6)).n;

  const focus = [
    ...deadlines.filter((d) => d.kind === 'task').slice(0, 2).map((d) => ({ kind: 'task', id: d.id, title: `Complete ${d.title}`, due: d.due })),
    ...items.filter((i) => i.kind === 'class').slice(0, 1).map((c) => ({ kind: 'class', id: c.id, title: `Attend ${c.title.split(' · ')[0]}` })),
    ...deadlines.filter((d) => d.kind === 'registration').slice(0, 1).map((d) => ({ kind: 'registration', id: d.id, title: d.title.replace('Register: ', 'Register for '), due: d.due })),
  ].slice(0, 3);

  res.json({
    user: { name: user.name },
    today,
    counts: { tasksToday: todayTasks.length, deadlines: deadlines.length, eventsThisWeek },
    motivation: motivation(week.mood, missed.length),
    schedule: { items, free, done: todayTasks.filter((t) => t.status === 'completed').length, total: todayTasks.length },
    focus,
    missed,
    deadlines,
    goals,
    extracurricular: ex,
    week,
    streak: streakFor(uid),
    conflicts: conflicts(uid, today, T.addDays(today, 13)),
    risks: deadlineRisks(uid).map((r) => ({ ...r, task: hydrate(r.task) })),
    weeklySummary: weeklySummary(uid),
  });
});

// Weekly review: how the given week went (default: the week before this one) and a look at the next.
router.get('/review', (req, res) => {
  const uid = req.userId;
  const ws = db.prepare('SELECT week_start FROM user_preferences WHERE user_id = ?').get(uid)?.week_start || 0;
  const start = req.query.week || T.addDays(T.startOfWeek(T.today(), ws), -7);
  const end = T.addDays(start, 6);
  const range = [`${start} 00:00`, `${end} 23:59:59`];
  const done = db.prepare(
    "SELECT COUNT(*) AS n, COALESCE(SUM(estimated_minutes),0) AS m FROM tasks WHERE user_id = ? AND status = 'completed' AND completed_at BETWEEN ? AND ?"
  ).get(uid, ...range);
  const missed = db.prepare(
    "SELECT COUNT(*) AS n FROM tasks WHERE user_id = ? AND status = 'missed' AND scheduled_start BETWEEN ? AND ?"
  ).get(uid, `${start}T00:00`, `${end}T23:59`).n;
  const activities = db.prepare(
    "SELECT COUNT(*) AS n FROM activities WHERE user_id = ? AND status = 'completed' AND event_date BETWEEN ? AND ?"
  ).get(uid, start, end).n;
  const byDay = db.prepare(
    "SELECT substr(completed_at,1,10) AS d, COUNT(*) AS n FROM tasks WHERE user_id = ? AND status = 'completed' AND completed_at BETWEEN ? AND ? GROUP BY d ORDER BY n DESC LIMIT 1"
  ).get(uid, ...range);
  // Goals that grew this week, with how many points of progress they gained.
  const goals = db.prepare("SELECT id, title FROM goals WHERE user_id = ? AND status IN ('active','completed')").all(uid).map((g) => {
    const total = db.prepare("SELECT COALESCE(SUM(estimated_minutes),0) AS m FROM tasks WHERE goal_id = ? AND status != 'cancelled'").get(g.id).m;
    const gained = db.prepare("SELECT COALESCE(SUM(estimated_minutes),0) AS m FROM tasks WHERE goal_id = ? AND status = 'completed' AND completed_at BETWEEN ? AND ?").get(g.id, ...range).m;
    return { id: g.id, title: g.title, gained: total ? Math.round((gained / total) * 100) : 0, progress: goalStats(g.id).progress };
  }).filter((g) => g.gained > 0).sort((a, b) => b.gained - a.gained);
  const nextStart = T.addDays(start, 7) > T.today() ? T.addDays(start, 7) : T.startOfWeek(T.today(), ws);
  const next = workload(uid, nextStart, T.addDays(nextStart, 6));
  const busiest = [...next.days].sort((a, b) => b.minutes - a.minutes)[0];
  res.json({
    week: { start, end },
    tasksDone: done.n, focusedMinutes: done.m, missed, activities,
    bestDay: byDay ? { date: byDay.d, count: byDay.n } : null,
    goals,
    next: { start: nextStart, mood: next.mood, totalMinutes: next.totalMinutes, busiest: busiest?.minutes ? { weekday: busiest.weekday, minutes: busiest.minutes } : null },
  });
});

router.get('/timeline', (req, res) => {
  const uid = req.userId;
  sweepMissed(uid);
  const from = req.query.from || T.today();
  const to = req.query.to || from;
  if (T.daysBetween(from, to) > 62 || to < from) throw httpError(400, 'Pick a range of up to two months');
  const blocks = busyBlocks(uid, from, to);
  const free = freeSlots(uid, from, to, { nowDt: T.nowDt() });
  const wl = workload(uid, from, to);
  const deadlines = db.prepare(
    `SELECT id, title, deadline, priority, status FROM tasks WHERE user_id = ? AND deadline BETWEEN ? AND ? AND status NOT IN ('cancelled')`
  ).all(uid, from, `${to}T23:59`);
  const regs = db.prepare(
    "SELECT id, title, registration_deadline FROM activities WHERE user_id = ? AND registration_deadline BETWEEN ? AND ? AND status != 'cancelled'"
  ).all(uid, from, to);
  const rems = db.prepare("SELECT * FROM reminders WHERE user_id = ? AND reminder_time BETWEEN ? AND ? AND status != 'dismissed'").all(uid, `${from}T00:00`, `${to}T23:59`);
  const days = [];
  for (let d = from; d <= to; d = T.addDays(d, 1)) {
    days.push({
      date: d,
      weekday: T.DAY_NAMES[T.weekday(d)],
      items: blocks.filter((b) => b.date === d).map((b) => ({ ...b, minutes: T.minutesBetween(b.start, b.end) })),
      free: free[d] || [],
      deadlines: [
        ...deadlines.filter((t) => t.deadline.slice(0, 10) === d).map((t) => ({ kind: 'task', ...t })),
        ...regs.filter((a) => a.registration_deadline === d).map((a) => ({ kind: 'registration', id: a.id, title: `Register: ${a.title}`, deadline: a.registration_deadline, priority: 'medium' })),
      ],
      reminders: rems.filter((r) => r.reminder_time.slice(0, 10) === d),
      load: wl.days.find((x) => x.date === d),
    });
  }
  res.json({ from, to, days, mood: wl.mood, totalMinutes: wl.totalMinutes, conflicts: conflicts(uid, from, to) });
});

router.get('/free', (req, res) => {
  const from = req.query.from || T.today();
  const to = req.query.to || from;
  res.json({ free: freeSlots(req.userId, from, to) });
});

router.get('/conflicts', (req, res) => {
  const from = req.query.from || T.today();
  const to = req.query.to || T.addDays(from, 13);
  res.json({ conflicts: conflicts(req.userId, from, to) });
});

router.post('/conflicts/ignore', (req, res) => {
  if (!req.body?.key) return res.status(400).json({ error: 'Missing conflict' });
  db.prepare('INSERT OR IGNORE INTO conflict_ignores (user_id, conflict_key) VALUES (?,?)').run(req.userId, req.body.key);
  res.json({ ok: true });
});

router.get('/progress', (req, res) => {
  const uid = req.userId;
  sweepMissed(uid);
  const today = T.today();
  const count = (sql, ...a) => db.prepare(sql).get(uid, ...a).n;
  const completed = count("SELECT COUNT(*) AS n FROM tasks WHERE user_id = ? AND status = 'completed'");
  const missed = count("SELECT COUNT(*) AS n FROM tasks WHERE user_id = ? AND status = 'missed'");
  const rescheduled = count('SELECT COUNT(*) AS n FROM tasks WHERE user_id = ? AND reschedule_count > 0');
  const activitiesDone = count("SELECT COUNT(*) AS n FROM activities WHERE user_id = ? AND status = 'completed'");
  const weekStartPref = db.prepare('SELECT week_start FROM user_preferences WHERE user_id = ?').get(uid)?.week_start || 0;
  const thisWeek = T.startOfWeek(today, weekStartPref);

  const weekly = [];
  for (let i = 3; i >= 0; i--) {
    const ws = T.addDays(thisWeek, -7 * i);
    const we = T.addDays(ws, 6);
    const row = db.prepare(
      `SELECT COUNT(*) AS planned, SUM(CASE WHEN status = 'completed' THEN 1 ELSE 0 END) AS done FROM tasks
       WHERE user_id = ? AND status != 'cancelled' AND scheduled_start BETWEEN ? AND ?`
    ).get(uid, `${ws}T00:00`, `${we}T23:59`);
    weekly.push({ weekStart: ws, planned: row.planned, done: row.done || 0 });
  }

  const due = completed + missed;
  const activeDays = new Set(
    db.prepare("SELECT DISTINCT substr(completed_at,1,10) AS d FROM tasks WHERE user_id = ? AND status = 'completed' AND completed_at >= ?")
      .all(uid, T.addDays(today, -13)).map((r) => r.d)
  ).size;

  const wl = busyBlocks(uid, thisWeek, T.addDays(thisWeek, 6));
  const sum = (k) => wl.filter((b) => b.kind === k).reduce((s, b) => s + T.minutesBetween(b.start, b.end), 0);
  const categories = db.prepare(
    "SELECT category, COUNT(*) AS n, SUM(CASE WHEN status = 'completed' THEN 1 ELSE 0 END) AS done FROM activities WHERE user_id = ? AND status != 'cancelled' GROUP BY category ORDER BY n DESC"
  ).all(uid);

  res.json({
    completed, missed, rescheduled, activitiesDone,
    completionRate: due ? Math.round((completed / due) * 100) : 0,
    consistency: { activeDays, window: 14 },
    weekly,
    goals: db.prepare('SELECT * FROM goals WHERE user_id = ? ORDER BY status, deadline').all(uid).map((g) => ({ id: g.id, title: g.title, deadline: g.deadline, status: g.status, ...goalStats(g.id) })),
    hours: { classes: sum('class'), goals: sum('task'), activities: sum('activity') },
    activityBreakdown: categories,
    streak: streakFor(uid),
    weeklySummary: weeklySummary(uid),
  });
});

router.get('/search', (req, res) => {
  const uid = req.userId;
  const { q = '', type, priority, status, from, to, goal_id, category } = req.query;
  const like = `%${q}%`;
  const out = [];
  const want = (t) => !type || type === t;
  if (want('task')) {
    const where = ['t.user_id = ?', 't.title LIKE ?'];
    const args = [uid, like];
    if (priority) { where.push('t.priority = ?'); args.push(priority); }
    if (status) { where.push('t.status = ?'); args.push(status); }
    if (goal_id) { where.push('t.goal_id = ?'); args.push(goal_id); }
    if (from) { where.push('COALESCE(t.scheduled_start, t.deadline) >= ?'); args.push(from); }
    if (to) { where.push('COALESCE(t.scheduled_start, t.deadline) <= ?'); args.push(`${to}T23:59`); }
    db.prepare(`SELECT t.*, g.title AS goal_title FROM tasks t LEFT JOIN goals g ON g.id = t.goal_id WHERE ${where.join(' AND ')} ORDER BY t.scheduled_start DESC LIMIT 25`)
      .all(...args).forEach((t) => out.push({ type: 'task', id: t.id, title: t.title, subtitle: t.goal_title || 'Task', date: t.scheduled_start || t.deadline, priority: t.priority, status: t.status, goal_id: t.goal_id }));
  }
  if (want('goal')) {
    const where = ['user_id = ?', '(title LIKE ? OR description LIKE ?)'];
    const args = [uid, like, like];
    if (priority) { where.push('priority = ?'); args.push(priority); }
    if (status) { where.push('status = ?'); args.push(status); }
    db.prepare(`SELECT * FROM goals WHERE ${where.join(' AND ')} LIMIT 10`).all(...args)
      .forEach((g) => out.push({ type: 'goal', id: g.id, title: g.title, subtitle: `${goalStats(g.id).progress}% done`, date: g.deadline, priority: g.priority, status: g.status }));
  }
  if (want('class') && !priority && !status) {
    db.prepare('SELECT * FROM classes WHERE user_id = ? AND (course_code LIKE ? OR title LIKE ? OR instructor LIKE ?) ORDER BY day, start_time LIMIT 15').all(uid, like, like, like)
      .forEach((c) => out.push({ type: 'class', id: c.id, title: `${c.course_code}${c.title ? ` · ${c.title}` : ''}`, subtitle: `${T.DAY_NAMES[c.day]} ${T.fmtTime(c.start_time)} · Room ${c.room || '—'}` }));
  }
  if (want('activity')) {
    const where = ['user_id = ?', '(title LIKE ? OR description LIKE ? OR location LIKE ?)'];
    const args = [uid, like, like, like];
    if (priority) { where.push('priority = ?'); args.push(priority); }
    if (status) { where.push('status = ?'); args.push(status); }
    if (category) { where.push('category = ?'); args.push(category); }
    if (from) { where.push('event_date >= ?'); args.push(from); }
    if (to) { where.push('event_date <= ?'); args.push(to); }
    db.prepare(`SELECT * FROM activities WHERE ${where.join(' AND ')} ORDER BY event_date LIMIT 15`).all(...args)
      .forEach((a) => out.push({ type: 'activity', id: a.id, title: a.title, subtitle: a.category, date: a.event_date, priority: a.priority, status: a.status }));
  }
  res.json({ results: out });
});

router.get('/assistant/messages', (req, res) => {
  const rows = db.prepare('SELECT * FROM chat_messages WHERE user_id = ? ORDER BY id DESC LIMIT 60').all(req.userId).reverse();
  res.json({ messages: rows.map((m) => ({ ...m, meta: m.meta ? JSON.parse(m.meta) : null })) });
});

router.delete('/assistant/messages', (req, res) => {
  db.prepare('DELETE FROM chat_messages WHERE user_id = ?').run(req.userId);
  res.json({ ok: true });
});

router.post('/assistant/chat', h(async (req, res) => {
  const { message, focus_task_id, slot } = req.body || {};
  if (!String(message || '').trim()) return res.status(400).json({ error: 'Say something first' });
  res.json(await chat(req.userId, { message: String(message).slice(0, 1000), focusTaskId: focus_task_id, slot }));
}));
