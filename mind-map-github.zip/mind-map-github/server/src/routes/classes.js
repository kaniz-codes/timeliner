import { Router } from 'express';
import multer from 'multer';
import { db } from '../db.js';
import { requireAuth, h } from '../auth.js';
import { askVisionJson } from '../lib/ai.js';

export const router = Router();
router.use(requireAuth);

const upload = multer({ storage: multer.memoryStorage(), limits: { fileSize: 8 * 1024 * 1024 } });
const TIME = /^\d{2}:\d{2}$/;
const DAY_ALIASES = { sun: 0, mon: 1, tue: 2, wed: 3, thu: 4, fri: 5, sat: 6 };

function validate(c) {
  if (!String(c.course_code || '').trim()) return 'Course code is required';
  const day = Number(c.day);
  if (!Number.isInteger(day) || day < 0 || day > 6) return 'Pick a day';
  if (!TIME.test(c.start_time || '') || !TIME.test(c.end_time || '')) return 'Start and end time are required';
  if (c.start_time >= c.end_time) return 'Class must end after it starts';
  return null;
}

function clean(c) {
  return {
    course_code: String(c.course_code).trim().toUpperCase(),
    title: c.title?.trim() || null,
    day: Number(c.day),
    start_time: c.start_time,
    end_time: c.end_time,
    room: c.room?.toString().trim() || null,
    instructor: c.instructor?.trim() || null,
    recurring: c.recurring || 'weekly',
  };
}

const insert = (userId, c) =>
  db.prepare('INSERT INTO classes (user_id, course_code, title, day, start_time, end_time, room, instructor, recurring) VALUES (?,?,?,?,?,?,?,?,?)')
    .run(userId, c.course_code, c.title, c.day, c.start_time, c.end_time, c.room, c.instructor, c.recurring).lastInsertRowid;

router.get('/', (req, res) => {
  res.json({ classes: db.prepare('SELECT * FROM classes WHERE user_id = ? ORDER BY day, start_time').all(req.userId) });
});

router.post('/', (req, res) => {
  const err = validate(req.body || {});
  if (err) return res.status(400).json({ error: err });
  const id = insert(req.userId, clean(req.body));
  res.json({ class: db.prepare('SELECT * FROM classes WHERE id = ?').get(id) });
});

router.post('/bulk', (req, res) => {
  const list = req.body?.classes || [];
  const errors = list.map(validate).map((e, i) => (e ? `Row ${i + 1}: ${e}` : null)).filter(Boolean);
  if (errors.length) return res.status(400).json({ error: errors[0], errors });
  // Skip exact duplicates of classes already in the routine (common when re-importing).
  const existing = new Set(db.prepare('SELECT course_code, day, start_time FROM classes WHERE user_id = ?').all(req.userId)
    .map((c) => `${c.course_code}|${c.day}|${c.start_time}`));
  const fresh = list.map(clean).filter((c) => {
    const key = `${c.course_code}|${c.day}|${c.start_time}`;
    if (existing.has(key)) return false;
    existing.add(key);
    return true;
  });
  const ids = db.transaction(() => fresh.map((c) => insert(req.userId, c)))();
  res.json({ added: ids.length, skipped: list.length - ids.length });
});

router.put('/:id', (req, res) => {
  const cur = db.prepare('SELECT * FROM classes WHERE id = ? AND user_id = ?').get(req.params.id, req.userId);
  if (!cur) return res.status(404).json({ error: 'Class not found' });
  const next = { ...cur, ...req.body };
  const err = validate(next);
  if (err) return res.status(400).json({ error: err });
  const c = clean(next);
  db.prepare('UPDATE classes SET course_code=?, title=?, day=?, start_time=?, end_time=?, room=?, instructor=?, recurring=? WHERE id=?')
    .run(c.course_code, c.title, c.day, c.start_time, c.end_time, c.room, c.instructor, c.recurring, cur.id);
  res.json({ class: db.prepare('SELECT * FROM classes WHERE id = ?').get(cur.id) });
});

router.delete('/:id', (req, res) => {
  db.prepare('DELETE FROM classes WHERE id = ? AND user_id = ?').run(req.params.id, req.userId);
  res.json({ ok: true });
});

const VISION_PROMPT = `This image is a university class routine / timetable. Extract every class meeting.
Return JSON: {"classes":[{"course_code":"CSE 327","title":"Software Engineering or null","day":"Sunday",
"start_time":"09:40","end_time":"11:10","room":"301 or null","instructor":"name or null"}]}
Rules: one entry per weekly meeting (a course on two days = two entries). 24-hour HH:MM times.
If a time range is written like "9:40-11:10" in a column header, apply it to the cells below it.
Days: full English day names. Do not guess values that are not in the image; use null.`;

function normalizeTime(t) {
  if (!t) return null;
  const m = String(t).trim().match(/^(\d{1,2})[:.](\d{2})\s*(am|pm)?$/i);
  if (!m) return null;
  let hh = Number(m[1]);
  const mm = m[2];
  const ap = m[3]?.toLowerCase();
  if (ap === 'pm' && hh < 12) hh += 12;
  if (ap === 'am' && hh === 12) hh = 0;
  // Timetables often write afternoon classes as 1:00-2:30 without AM/PM.
  if (!ap && hh >= 1 && hh <= 6) hh += 12;
  return `${String(hh).padStart(2, '0')}:${mm}`;
}

// Extract only. The client shows rows for review; nothing is saved until the student confirms via /bulk.
router.post('/import-image', upload.single('image'), h(async (req, res) => {
  if (!req.file) return res.status(400).json({ error: 'Upload a JPG or PNG of your routine' });
  if (!/^image\/(png|jpe?g|webp|heic)$/.test(req.file.mimetype)) return res.status(400).json({ error: 'Only JPG, PNG or WEBP images work here' });
  const data = await askVisionJson(VISION_PROMPT, req.file.buffer.toString('base64'), req.file.mimetype);
  if (!data) return res.status(502).json({ error: "We couldn't read that image. Try a sharper screenshot, or add classes manually." });
  const rows = (data.classes || []).map((c) => {
    const dayKey = String(c.day || '').slice(0, 3).toLowerCase();
    return {
      course_code: c.course_code || '',
      title: c.title || '',
      day: dayKey in DAY_ALIASES ? DAY_ALIASES[dayKey] : '',
      start_time: normalizeTime(c.start_time) || '',
      end_time: normalizeTime(c.end_time) || '',
      room: String(c.room || '').replace(/^\s*(room|rm\.?)\s*/i, ''),
      instructor: c.instructor || '',
    };
  });
  res.json({ classes: rows });
}));
