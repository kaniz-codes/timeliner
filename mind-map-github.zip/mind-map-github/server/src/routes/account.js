import { Router } from 'express';
import bcrypt from 'bcryptjs';
import crypto from 'node:crypto';
import nodemailer from 'nodemailer';
import { db, prefsFor } from '../db.js';
import { setSession, clearSession, requireAuth, h } from '../auth.js';
import { seedDemo, DEMO_EMAIL } from '../seed.js';

export const publicRouter = Router();
export const router = Router();

const publicUser = (u) => {
  if (!u) return null;
  const { password_hash, ...rest } = u;
  return { ...rest, onboarded: !!rest.onboarded };
};

publicRouter.post('/auth/register', h(async (req, res) => {
  const { name, email, password } = req.body || {};
  if (!name?.trim() || !email?.trim() || !password) return res.status(400).json({ error: 'Name, email and password are required' });
  if (password.length < 6) return res.status(400).json({ error: 'Password needs at least 6 characters' });
  if (!/^\S+@\S+\.\S+$/.test(email)) return res.status(400).json({ error: 'That email does not look right' });
  const exists = db.prepare('SELECT id FROM users WHERE email = ?').get(email.trim().toLowerCase());
  if (exists) return res.status(409).json({ error: 'An account with this email already exists' });
  const id = db.prepare('INSERT INTO users (name, email, password_hash) VALUES (?,?,?)')
    .run(name.trim(), email.trim().toLowerCase(), await bcrypt.hash(password, 10)).lastInsertRowid;
  prefsFor(id);
  const user = db.prepare('SELECT * FROM users WHERE id = ?').get(id);
  setSession(res, user);
  res.json({ user: publicUser(user) });
}));

publicRouter.post('/auth/login', h(async (req, res) => {
  const { email, password } = req.body || {};
  const user = db.prepare('SELECT * FROM users WHERE email = ?').get(String(email || '').trim().toLowerCase());
  if (!user || !(await bcrypt.compare(String(password || ''), user.password_hash))) {
    return res.status(401).json({ error: 'Email or password is incorrect' });
  }
  setSession(res, user);
  res.json({ user: publicUser(user) });
}));

// Demo login resets the demo data so every visit starts from the same, date-relative story.
publicRouter.post('/auth/demo', h(async (req, res) => {
  seedDemo();
  const user = db.prepare('SELECT * FROM users WHERE email = ?').get(DEMO_EMAIL);
  setSession(res, user);
  res.json({ user: publicUser(user) });
}));

publicRouter.post('/auth/logout', (req, res) => {
  clearSession(res);
  res.json({ ok: true });
});

// Forgot password. The reply is the same whether or not the email exists, so it can't be used
// to discover accounts. With SMTP settings the link is emailed; without them (local development)
// it is printed in the server terminal.
const hash = (t) => crypto.createHash('sha256').update(t).digest('hex');
const mailer = process.env.SMTP_HOST ? nodemailer.createTransport({
  host: process.env.SMTP_HOST,
  port: Number(process.env.SMTP_PORT) || 587,
  secure: Number(process.env.SMTP_PORT) === 465,
  auth: process.env.SMTP_USER ? { user: process.env.SMTP_USER, pass: process.env.SMTP_PASS } : undefined,
}) : null;

publicRouter.post('/auth/forgot', h(async (req, res) => {
  const email = String(req.body?.email || '').trim().toLowerCase();
  const user = email && db.prepare('SELECT id, name, email FROM users WHERE email = ?').get(email);
  if (user) {
    const token = crypto.randomBytes(32).toString('hex');
    const expires = new Date(Date.now() + 30 * 60 * 1000).toISOString();
    db.prepare('DELETE FROM password_resets WHERE user_id = ?').run(user.id);
    db.prepare('INSERT INTO password_resets (user_id, token_hash, expires_at) VALUES (?,?,?)').run(user.id, hash(token), expires);
    const base = process.env.APP_URL || `${req.protocol}://${req.get('host')}`;
    const link = `${base}/reset?token=${token}`;
    if (mailer) {
      await mailer.sendMail({
        from: process.env.SMTP_FROM || 'MIND MAP <no-reply@mindmap.local>',
        to: user.email,
        subject: 'Reset your MIND MAP password',
        text: `Hi ${user.name},\n\nUse this link within 30 minutes to choose a new password:\n${link}\n\nIf you didn't ask for this, you can ignore it.`,
      });
    } else {
      console.log(`\n[password reset] ${user.email}: ${link}\n`);
    }
  }
  res.json({ ok: true, delivery: mailer ? 'email' : 'console' });
}));

publicRouter.post('/auth/reset', h(async (req, res) => {
  const { token, password } = req.body || {};
  if (!password || password.length < 6) return res.status(400).json({ error: 'Password needs at least 6 characters' });
  const row = token && db.prepare('SELECT * FROM password_resets WHERE token_hash = ?').get(hash(String(token)));
  if (!row || row.used || row.expires_at < new Date().toISOString()) {
    return res.status(400).json({ error: 'This reset link has expired. Ask for a new one.' });
  }
  db.prepare('UPDATE users SET password_hash = ? WHERE id = ?').run(await bcrypt.hash(password, 10), row.user_id);
  db.prepare('UPDATE password_resets SET used = 1 WHERE user_id = ?').run(row.user_id);
  const user = db.prepare('SELECT * FROM users WHERE id = ?').get(row.user_id);
  setSession(res, user);
  res.json({ user: publicUser(user) });
}));

router.use(requireAuth);

router.get('/me', (req, res) => {
  const user = db.prepare('SELECT * FROM users WHERE id = ?').get(req.userId);
  if (!user) return res.status(401).json({ error: 'Account not found' });
  res.json({ user: publicUser(user), preferences: prefsFor(req.userId) });
});

router.put('/me', (req, res) => {
  const fields = ['name', 'department', 'university', 'year', 'onboarded'];
  const cur = db.prepare('SELECT * FROM users WHERE id = ?').get(req.userId);
  const next = { ...cur };
  for (const f of fields) if (f in (req.body || {})) next[f] = f === 'onboarded' ? (req.body[f] ? 1 : 0) : req.body[f];
  if (!String(next.name || '').trim()) return res.status(400).json({ error: 'Name cannot be empty' });
  db.prepare('UPDATE users SET name=?, department=?, university=?, year=?, onboarded=? WHERE id=?')
    .run(next.name.trim(), next.department, next.university, next.year, next.onboarded, req.userId);
  res.json({ user: publicUser(db.prepare('SELECT * FROM users WHERE id = ?').get(req.userId)) });
});

router.put('/me/preferences', (req, res) => {
  const cur = prefsFor(req.userId);
  const allowed = ['day_start', 'day_end', 'sleep_start', 'sleep_end', 'preferred_study', 'max_daily_minutes', 'theme', 'notify_browser', 'default_reminder', 'week_start', 'semester_start', 'semester_end'];
  const next = { ...cur };
  for (const k of allowed) if (k in (req.body || {})) next[k] = req.body[k];
  const time = /^\d{2}:\d{2}$/;
  for (const k of ['day_start', 'day_end', 'sleep_start', 'sleep_end']) {
    if (!time.test(next[k])) return res.status(400).json({ error: `${k} must be HH:MM` });
  }
  if (next.day_start >= next.day_end) return res.status(400).json({ error: 'Your day has to start before it ends' });
  for (const k of ['semester_start', 'semester_end']) {
    if (next[k] === '') next[k] = null;
    if (next[k] && !/^\d{4}-\d{2}-\d{2}$/.test(next[k])) return res.status(400).json({ error: 'Pick a valid semester date' });
  }
  if (next.semester_start && next.semester_end && next.semester_start > next.semester_end) {
    return res.status(400).json({ error: 'The semester has to start before it ends' });
  }
  db.prepare(`UPDATE user_preferences SET ${allowed.map((k) => `${k}=?`).join(', ')} WHERE user_id=?`)
    .run(...allowed.map((k) => (typeof next[k] === 'boolean' ? Number(next[k]) : next[k])), req.userId);
  res.json({ preferences: prefsFor(req.userId) });
});

router.put('/me/password', h(async (req, res) => {
  const { current, next } = req.body || {};
  const user = db.prepare('SELECT * FROM users WHERE id = ?').get(req.userId);
  if (!(await bcrypt.compare(String(current || ''), user.password_hash))) return res.status(400).json({ error: 'Current password is incorrect' });
  if (!next || next.length < 6) return res.status(400).json({ error: 'New password needs at least 6 characters' });
  db.prepare('UPDATE users SET password_hash = ? WHERE id = ?').run(await bcrypt.hash(next, 10), req.userId);
  res.json({ ok: true });
}));

router.delete('/me/data', (req, res) => {
  for (const t of ['tasks', 'goals', 'classes', 'activities', 'reminders', 'chat_messages', 'notifications', 'task_history', 'conflict_ignores']) {
    db.prepare(`DELETE FROM ${t} WHERE user_id = ?`).run(req.userId);
  }
  res.json({ ok: true });
});

router.get('/notifications', (req, res) => {
  res.json({ notifications: db.prepare('SELECT * FROM notifications WHERE user_id = ? ORDER BY id DESC LIMIT 30').all(req.userId) });
});

router.post('/notifications/read-all', (req, res) => {
  db.prepare('UPDATE notifications SET read = 1 WHERE user_id = ?').run(req.userId);
  res.json({ ok: true });
});
