import { Router } from 'express';
import { db } from '../db.js';
import { requireAuth } from '../auth.js';
import * as T from '../lib/time.js';
import { busyBlocks, httpError } from '../lib/scheduler.js';

export const activities = Router();
export const reminders = Router();
activities.use(requireAuth);
reminders.use(requireAuth);

export const CATEGORIES = ['Club activity', 'Competition', 'Workshop', 'Seminar', 'Hackathon', 'Volunteer work', 'Sports', 'Cultural event', 'Career fair', 'Other'];
const STATUSES = ['interested', 'registered', 'upcoming', 'completed', 'cancelled'];
const FIELDS = ['title', 'category', 'description', 'registration_deadline', 'event_date', 'start_time', 'end_time', 'location', 'priority', 'status', 'notes'];

function validate(a) {
  if (!String(a.title || '').trim()) return 'Give the activity a title';
  if (a.category && !CATEGORIES.includes(a.category)) return 'Unknown category';
  if (a.status && !STATUSES.includes(a.status)) return 'Unknown status';
  if ((a.start_time && !a.end_time) || (!a.start_time && a.end_time)) return 'Add both a start and an end time';
  if (a.start_time && a.end_time && a.start_time >= a.end_time) return 'The activity must end after it starts';
  if ((a.start_time || a.end_time) && !a.event_date) return 'Add the event date';
  return null;
}

// Report overlaps so the UI can warn right after saving.
function clashesFor(userId, a) {
  if (!a.event_date || !a.start_time || a.status === 'cancelled') return [];
  const start = T.dt(a.event_date, a.start_time);
  const end = T.dt(a.event_date, a.end_time);
  return busyBlocks(userId, a.event_date, a.event_date, { includeCompleted: false })
    .filter((b) => !(b.kind === 'activity' && b.id === a.id) && b.start < end && b.end > start)
    .map((b) => ({ ...b, overlapMinutes: T.minutesBetween(b.start > start ? b.start : start, b.end < end ? b.end : end) }));
}

activities.get('/', (req, res) => {
  const rows = db.prepare('SELECT * FROM activities WHERE user_id = ? ORDER BY COALESCE(event_date, registration_deadline, \'9999\')').all(req.userId);
  res.json({ activities: rows, categories: CATEGORIES });
});

activities.post('/', (req, res) => {
  const b = { category: 'Other', priority: 'medium', status: 'interested', ...req.body };
  const err = validate(b);
  if (err) return res.status(400).json({ error: err });
  const id = db.prepare(`INSERT INTO activities (user_id, ${FIELDS.join(', ')}) VALUES (?, ${FIELDS.map(() => '?').join(', ')})`)
    .run(req.userId, ...FIELDS.map((f) => (f === 'title' ? b.title.trim() : b[f] || null))).lastInsertRowid;
  const a = db.prepare('SELECT * FROM activities WHERE id = ?').get(id);
  res.json({ activity: a, conflicts: clashesFor(req.userId, a) });
});

activities.put('/:id', (req, res) => {
  const cur = db.prepare('SELECT * FROM activities WHERE id = ? AND user_id = ?').get(req.params.id, req.userId);
  if (!cur) throw httpError(404, 'Activity not found');
  const next = { ...cur, ...req.body };
  const err = validate(next);
  if (err) return res.status(400).json({ error: err });
  const completedAt = next.status === 'completed' ? cur.completed_at || T.today() : null;
  db.prepare(`UPDATE activities SET ${FIELDS.map((f) => `${f}=?`).join(', ')}, completed_at=? WHERE id=?`)
    .run(...FIELDS.map((f) => next[f] ?? null), completedAt, cur.id);
  const a = db.prepare('SELECT * FROM activities WHERE id = ?').get(cur.id);
  res.json({ activity: a, conflicts: clashesFor(req.userId, a) });
});

activities.delete('/:id', (req, res) => {
  db.prepare('DELETE FROM activities WHERE id = ? AND user_id = ?').run(req.params.id, req.userId);
  res.json({ ok: true });
});

// Reminders: an absolute time, or an offset from a class/task/activity/deadline.
const OFFSETS = { '1h': [60, '1 hour before'], '1d': [1440, '1 day before'], '3d': [4320, '3 days before'], '7d': [10080, '7 days before'] };

function referenceTime(userId, type, id) {
  if (type === 'task') {
    const t = db.prepare('SELECT title, scheduled_start, deadline FROM tasks WHERE id = ? AND user_id = ?').get(id, userId);
    return t && { title: t.title, at: t.scheduled_start || T.deadlineDt(t.deadline) };
  }
  if (type === 'deadline') {
    const t = db.prepare('SELECT title, deadline FROM tasks WHERE id = ? AND user_id = ?').get(id, userId);
    return t?.deadline && { title: `${t.title} due`, at: T.deadlineDt(t.deadline).replace('T23:59', 'T09:00') };
  }
  if (type === 'goal') {
    const g = db.prepare('SELECT title, deadline FROM goals WHERE id = ? AND user_id = ?').get(id, userId);
    return g?.deadline && { title: `${g.title} deadline`, at: `${g.deadline}T09:00` };
  }
  if (type === 'activity' || type === 'registration') {
    const a = db.prepare('SELECT * FROM activities WHERE id = ? AND user_id = ?').get(id, userId);
    if (!a) return null;
    if (type === 'registration') return a.registration_deadline && { title: `${a.title} registration`, at: `${a.registration_deadline}T09:00` };
    return a.event_date && { title: a.title, at: T.dt(a.event_date, a.start_time || '09:00') };
  }
  if (type === 'class') {
    const c = db.prepare('SELECT * FROM classes WHERE id = ? AND user_id = ?').get(id, userId);
    if (!c) return null;
    let d = T.today();
    while (T.weekday(d) !== c.day || T.dt(d, c.start_time) <= T.nowDt()) d = T.addDays(d, 1);
    return { title: `${c.course_code} class`, at: T.dt(d, c.start_time) };
  }
  return null;
}

reminders.get('/', (req, res) => {
  const rows = db.prepare("SELECT * FROM reminders WHERE user_id = ? AND status != 'dismissed' ORDER BY reminder_time").all(req.userId);
  res.json({ reminders: rows });
});

reminders.post('/', (req, res) => {
  const b = req.body || {};
  let title = String(b.title || '').trim();
  let time = b.reminder_time || null;
  let label = 'Custom';
  if (b.reference_type && b.reference_type !== 'custom' && b.reference_id) {
    const ref = referenceTime(req.userId, b.reference_type, b.reference_id);
    if (!ref?.at) return res.status(400).json({ error: 'That item has no date to remind you about' });
    title = title || ref.title;
    if (b.offset && OFFSETS[b.offset]) {
      time = T.addMinutesDt(ref.at, -OFFSETS[b.offset][0]);
      label = OFFSETS[b.offset][1];
    } else if (!time) {
      time = ref.at;
      label = 'At the time';
    }
  }
  if (!title) return res.status(400).json({ error: 'What should we remind you about?' });
  if (!time) return res.status(400).json({ error: 'Pick when to be reminded' });
  const id = db.prepare('INSERT INTO reminders (user_id, reference_type, reference_id, title, reminder_time, offset_label) VALUES (?,?,?,?,?,?)')
    .run(req.userId, b.reference_type || 'custom', b.reference_id || null, title, time, label).lastInsertRowid;
  res.json({ reminder: db.prepare('SELECT * FROM reminders WHERE id = ?').get(id) });
});

reminders.put('/:id', (req, res) => {
  const cur = db.prepare('SELECT * FROM reminders WHERE id = ? AND user_id = ?').get(req.params.id, req.userId);
  if (!cur) throw httpError(404, 'Reminder not found');
  const next = { ...cur, ...req.body };
  db.prepare('UPDATE reminders SET title=?, reminder_time=?, status=? WHERE id=?').run(next.title, next.reminder_time, next.status, cur.id);
  res.json({ reminder: db.prepare('SELECT * FROM reminders WHERE id = ?').get(cur.id) });
});

reminders.delete('/:id', (req, res) => {
  db.prepare('DELETE FROM reminders WHERE id = ? AND user_id = ?').run(req.params.id, req.userId);
  res.json({ ok: true });
});

// Polled by the client; returns reminders that just came due and marks them sent.
reminders.get('/due', (req, res) => {
  const now = T.nowDt();
  const due = db.prepare("SELECT * FROM reminders WHERE user_id = ? AND status = 'pending' AND reminder_time <= ?").all(req.userId, now);
  const mark = db.prepare("UPDATE reminders SET status = 'sent' WHERE id = ?");
  due.forEach((r) => mark.run(r.id));
  res.json({ due });
});
