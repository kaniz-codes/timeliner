import { Router } from 'express';
import { db, logHistory } from '../db.js';
import { requireAuth, h } from '../auth.js';
import * as T from '../lib/time.js';
import { goalStats, goalFeasibility, simulatePlacement, httpError } from '../lib/scheduler.js';
import { generateRoadmap, summaryLine } from '../lib/planner.js';
import { hydrate } from './tasks.js';

export const router = Router();
router.use(requireAuth);

const FIELDS = ['title', 'description', 'start_date', 'deadline', 'current_level', 'weekly_hours', 'priority', 'preferred_time', 'existing_knowledge', 'budget', 'notes', 'status'];

function getGoal(userId, id) {
  const g = db.prepare('SELECT * FROM goals WHERE id = ? AND user_id = ?').get(id, userId);
  if (!g) throw httpError(404, 'Goal not found');
  return g;
}

function withStats(userId, g) {
  const next = db.prepare(
    `SELECT id, title, scheduled_start, scheduled_end FROM tasks WHERE goal_id = ? AND status IN ('pending','in_progress','rescheduled')
     AND scheduled_start >= ? ORDER BY scheduled_start LIMIT 1`
  ).get(g.id, T.nowDt());
  const hasRoadmap = !!db.prepare('SELECT 1 FROM milestones WHERE goal_id = ? LIMIT 1').get(g.id);
  const draft = db.prepare("SELECT id FROM roadmaps WHERE goal_id = ? AND status = 'draft' ORDER BY id DESC LIMIT 1").get(g.id);
  return { ...g, ...goalStats(g.id), feasibility: goalFeasibility(userId, g), next_task: next || null, has_roadmap: hasRoadmap, draft_id: draft?.id || null };
}

router.get('/', (req, res) => {
  const goals = db.prepare("SELECT * FROM goals WHERE user_id = ? ORDER BY CASE status WHEN 'active' THEN 0 ELSE 1 END, deadline").all(req.userId);
  res.json({ goals: goals.map((g) => withStats(req.userId, g)) });
});

router.post('/', (req, res) => {
  const b = req.body || {};
  if (!String(b.title || '').trim()) return res.status(400).json({ error: 'What is the goal? Add a title.' });
  if (b.deadline && b.deadline <= T.today()) return res.status(400).json({ error: 'Pick a deadline in the future' });
  const id = db.prepare(
    `INSERT INTO goals (user_id, title, description, start_date, deadline, current_level, weekly_hours, priority, preferred_time, existing_knowledge, budget, notes)
     VALUES (?,?,?,?,?,?,?,?,?,?,?,?)`
  ).run(req.userId, b.title.trim(), b.description || null, b.start_date || T.today(), b.deadline || null, b.current_level || 'Beginner',
    Math.max(1, Math.min(40, Number(b.weekly_hours) || 6)), b.priority || 'medium', b.preferred_time || null, b.existing_knowledge || null,
    b.budget || null, b.notes || null).lastInsertRowid;
  res.json({ goal: withStats(req.userId, getGoal(req.userId, id)) });
});

router.get('/:id', (req, res) => {
  const g = getGoal(req.userId, req.params.id);
  const milestones = db.prepare('SELECT * FROM milestones WHERE goal_id = ? ORDER BY position').all(g.id);
  const tasks = db.prepare("SELECT * FROM tasks WHERE goal_id = ? AND status != 'cancelled' ORDER BY COALESCE(scheduled_start, '9999'), id").all(g.id).map(hydrate);
  const loose = tasks.filter((t) => !t.milestone_id);
  res.json({
    goal: withStats(req.userId, g),
    milestones: milestones.map((m) => {
      const mt = tasks.filter((t) => t.milestone_id === m.id);
      const total = mt.reduce((s, t) => s + t.estimated_minutes, 0);
      const done = mt.filter((t) => t.status === 'completed').reduce((s, t) => s + t.estimated_minutes, 0);
      return { ...m, tasks: mt, progress: total ? Math.round((done / total) * 100) : 0 };
    }),
    other_tasks: loose,
  });
});

router.put('/:id', (req, res) => {
  const g = getGoal(req.userId, req.params.id);
  const next = { ...g };
  for (const f of FIELDS) if (f in (req.body || {})) next[f] = req.body[f];
  if (!String(next.title || '').trim()) return res.status(400).json({ error: 'Title cannot be empty' });
  db.prepare(`UPDATE goals SET ${FIELDS.map((f) => `${f}=?`).join(', ')} WHERE id=?`).run(...FIELDS.map((f) => next[f]), g.id);
  res.json({ goal: withStats(req.userId, getGoal(req.userId, g.id)) });
});

router.delete('/:id', (req, res) => {
  db.prepare('DELETE FROM goals WHERE id = ? AND user_id = ?').run(req.params.id, req.userId);
  res.json({ ok: true });
});

router.post('/:id/roadmap', h(async (req, res) => {
  const g = getGoal(req.userId, req.params.id);
  const draft = await generateRoadmap(req.userId, g);
  db.prepare("UPDATE roadmaps SET status = 'discarded' WHERE goal_id = ? AND status = 'draft'").run(g.id);
  const id = db.prepare('INSERT INTO roadmaps (goal_id, status, source, summary, payload) VALUES (?,?,?,?,?)')
    .run(g.id, 'draft', draft.source, draft.summary, JSON.stringify(draft)).lastInsertRowid;
  res.json({ roadmap: { id, goal_id: g.id, status: 'draft', ...draft }, goal: g });
}));

function getRoadmap(userId, id) {
  const r = db.prepare('SELECT r.*, g.user_id FROM roadmaps r JOIN goals g ON g.id = r.goal_id WHERE r.id = ?').get(id);
  if (!r || r.user_id !== userId) throw httpError(404, 'Roadmap not found');
  return { ...r, ...JSON.parse(r.payload) };
}

router.get('/roadmaps/:rid', (req, res) => {
  const r = getRoadmap(req.userId, req.params.rid);
  const { payload, user_id, ...rest } = r;
  res.json({ roadmap: rest, goal: getGoal(req.userId, r.goal_id) });
});

function normalizeEdited(milestones) {
  return (milestones || []).map((m) => ({
    title: String(m.title || 'Milestone'),
    description: m.description || '',
    duration_weeks: Math.max(0.5, Number(m.duration_weeks) || 1),
    tasks: (m.tasks || []).filter((t) => String(t.title || '').trim()).map((t) => ({
      title: String(t.title).trim(),
      description: t.description || '',
      estimated_minutes: Math.max(15, Math.min(480, Number(t.estimated_minutes) || 60)),
      difficulty: t.difficulty || 'moderate',
      priority: t.priority || 'medium',
      resources: t.resources || [],
      deadline: t.deadline || null,
    })),
  })).filter((m) => m.tasks.length);
}

// Save edits and re-run placement so the "aim for" dates stay honest.
router.put('/roadmaps/:rid', (req, res) => {
  const r = getRoadmap(req.userId, req.params.rid);
  if (r.status !== 'draft') return res.status(400).json({ error: 'This roadmap was already accepted' });
  const g = getGoal(req.userId, r.goal_id);
  const sim = simulatePlacement(req.userId, g, normalizeEdited(req.body?.milestones));
  const totalMinutes = sim.milestones.flatMap((m) => m.tasks).reduce((s, t) => s + t.estimated_minutes, 0);
  const aiSummary = r.aiSummary || null;
  const draft = {
    source: r.source,
    aiSummary,
    summary: summaryLine({ goal: g, sim, totalMinutes, aiSummary }),
    stats: {
      milestones: sim.milestones.length, tasks: sim.milestones.reduce((s, m) => s + m.tasks.length, 0), totalMinutes,
      weeklyMinutes: sim.weeklyMinutes, finishDate: sim.finishDate, unplaced: sim.unplaced,
    },
    milestones: sim.milestones,
  };
  db.prepare('UPDATE roadmaps SET summary = ?, payload = ? WHERE id = ?').run(draft.summary, JSON.stringify(draft), r.id);
  res.json({ roadmap: { id: r.id, goal_id: g.id, status: 'draft', ...draft } });
});

router.post('/roadmaps/:rid/accept', (req, res) => {
  const r = getRoadmap(req.userId, req.params.rid);
  if (r.status !== 'draft') return res.status(400).json({ error: 'This roadmap was already accepted' });
  const g = getGoal(req.userId, r.goal_id);
  const edited = req.body?.milestones ? normalizeEdited(req.body.milestones) : r.milestones;
  // Replace unfinished work from any previous roadmap; completed history stays.
  db.prepare("DELETE FROM tasks WHERE goal_id = ? AND milestone_id IS NOT NULL AND status NOT IN ('completed')").run(g.id);
  db.prepare('DELETE FROM milestones WHERE goal_id = ? AND id NOT IN (SELECT DISTINCT milestone_id FROM tasks WHERE goal_id = ? AND milestone_id IS NOT NULL)').run(g.id, g.id);
  const offset = db.prepare('SELECT COALESCE(MAX(position), -1) + 1 AS p FROM milestones WHERE goal_id = ?').get(g.id).p;
  const sim = simulatePlacement(req.userId, g, edited);
  let placed = 0;
  let unplaced = 0;
  db.transaction(() => {
    sim.milestones.forEach((m, i) => {
      const mid = db.prepare('INSERT INTO milestones (goal_id, roadmap_id, position, title, description, duration_weeks) VALUES (?,?,?,?,?,?)')
        .run(g.id, r.id, offset + i, m.title, m.description, m.duration_weeks).lastInsertRowid;
      for (const t of m.tasks) {
        const id = db.prepare(
          `INSERT INTO tasks (user_id, goal_id, milestone_id, title, description, estimated_minutes, scheduled_start, scheduled_end, deadline, priority, status, difficulty, resources)
           VALUES (?,?,?,?,?,?,?,?,?,?, 'pending', ?, ?)`
        ).run(req.userId, g.id, mid, t.title, t.description, t.estimated_minutes, t.scheduled_start, t.scheduled_end,
          t.suggested_deadline || g.deadline, t.priority, t.difficulty, JSON.stringify(t.resources || [])).lastInsertRowid;
        logHistory(req.userId, id, 'created', { to: t.scheduled_start, note: 'roadmap' });
        if (t.scheduled_start) placed++;
        else unplaced++;
      }
    });
    db.prepare("UPDATE roadmaps SET status = 'accepted' WHERE id = ?").run(r.id);
  })();
  res.json({ ok: true, placed, unplaced, finishDate: sim.finishDate });
});
