import { Router } from 'express';
import { db, logHistory } from '../db.js';
import { requireAuth } from '../auth.js';
import * as T from '../lib/time.js';
import { parseQuickAdd } from '../lib/quickadd.js';
import {
  busyBlocks, suggestSlots, splitPlan, streakFor, moveTask, freeMinutesUntil, goalStats, httpError, sweepMissed,
} from '../lib/scheduler.js';

export const router = Router();
router.use(requireAuth);

const STATUSES = ['pending', 'in_progress', 'completed', 'missed', 'rescheduled', 'cancelled'];
const PRIORITIES = ['high', 'medium', 'low'];

export function hydrate(t) {
  if (!t) return t;
  return { ...t, resources: t.resources ? JSON.parse(t.resources) : [] };
}

function getTask(userId, id) {
  const t = db.prepare(
    `SELECT t.*, g.title AS goal_title, m.title AS milestone_title FROM tasks t
     LEFT JOIN goals g ON g.id = t.goal_id LEFT JOIN milestones m ON m.id = t.milestone_id
     WHERE t.id = ? AND t.user_id = ?`
  ).get(id, userId);
  if (!t) throw httpError(404, 'Task not found');
  return hydrate(t);
}

router.get('/', (req, res) => {
  sweepMissed(req.userId);
  const { status, goal_id, from, to, priority, q } = req.query;
  const where = ['t.user_id = ?'];
  const args = [req.userId];
  if (status) { where.push(`t.status IN (${status.split(',').map(() => '?').join(',')})`); args.push(...status.split(',')); }
  if (goal_id) { where.push('t.goal_id = ?'); args.push(goal_id); }
  if (priority) { where.push('t.priority = ?'); args.push(priority); }
  if (from) { where.push('COALESCE(t.scheduled_start, t.deadline) >= ?'); args.push(from); }
  if (to) { where.push('COALESCE(t.scheduled_start, t.deadline) <= ?'); args.push(`${to}T23:59`); }
  if (q) { where.push('t.title LIKE ?'); args.push(`%${q}%`); }
  const rows = db.prepare(
    `SELECT t.*, g.title AS goal_title FROM tasks t LEFT JOIN goals g ON g.id = t.goal_id
     WHERE ${where.join(' AND ')} ORDER BY COALESCE(t.scheduled_start, t.deadline || 'T23:59', '9999')`
  ).all(...args);
  res.json({ tasks: rows.map(hydrate) });
});

router.post('/', (req, res) => {
  const b = req.body || {};
  if (!String(b.title || '').trim()) return res.status(400).json({ error: 'Give the task a title' });
  const minutes = Math.max(15, Math.min(600, Number(b.estimated_minutes) || 60));
  const priority = PRIORITIES.includes(b.priority) ? b.priority : 'medium';
  let start = b.scheduled_start || null;
  let end = start ? b.scheduled_end || T.addMinutesDt(start, minutes) : null;
  let placement = null;
  if (!start && b.auto_schedule) {
    const [slot] = suggestSlots(req.userId, { minutes, deadline: b.deadline, priority, limit: 1 });
    if (slot) { start = slot.start; end = slot.end; placement = slot; }
  }
  const id = db.prepare(
    `INSERT INTO tasks (user_id, goal_id, milestone_id, title, description, estimated_minutes, scheduled_start, scheduled_end, deadline, priority, status)
     VALUES (?,?,?,?,?,?,?,?,?,?, 'pending')`
  ).run(req.userId, b.goal_id || null, b.milestone_id || null, b.title.trim(), b.description || null, minutes, start, end, b.deadline || null, priority).lastInsertRowid;
  logHistory(req.userId, id, 'created', { to: start });
  res.json({ task: getTask(req.userId, id), placement, unplaced: b.auto_schedule && !start });
});

// Smart add: one line of text -> a task placed in real free time.
router.post('/quick', (req, res) => {
  const p = parseQuickAdd(req.body?.text);
  if (!p.title) return res.status(400).json({ error: 'Type what you need to do' });
  let start = null;
  let end = null;
  let placement = null;
  if (p.time) {
    start = T.dt(p.date, p.time);
    end = T.addMinutesDt(start, p.minutes);
    const clash = busyBlocks(req.userId, p.date, p.date, { includeCompleted: false }).find((b) => b.start < end && b.end > start);
    if (clash) {
      // Keep the student's day but move off the clash to the nearest free time that day.
      const [alt] = suggestSlots(req.userId, { minutes: p.minutes, onlyDate: p.date, priority: p.priority, limit: 1, distinctDays: false });
      if (alt) { start = alt.start; end = alt.end; placement = { ...alt, moved: `${clash.title.split(' · ')[0]} is at that time` }; }
    }
  } else {
    const [slot] = p.date
      ? suggestSlots(req.userId, { minutes: p.minutes, onlyDate: p.date, priority: p.priority, limit: 1, distinctDays: false })
      : suggestSlots(req.userId, { minutes: p.minutes, deadline: p.deadline, priority: p.priority, limit: 1 });
    if (slot) { start = slot.start; end = slot.end; placement = slot; }
  }
  const id = db.prepare(
    `INSERT INTO tasks (user_id, title, estimated_minutes, scheduled_start, scheduled_end, deadline, priority, status)
     VALUES (?,?,?,?,?,?,?, 'pending')`
  ).run(req.userId, p.title, p.minutes, start, end, p.deadline || p.date || null, p.priority).lastInsertRowid;
  logHistory(req.userId, id, 'created', { to: start, note: 'quick add' });
  res.json({ task: getTask(req.userId, id), parsed: p, placement });
});

// Hard-day helper: push today's remaining non-urgent tasks to the best free time later this week.
router.post('/lighten', (req, res) => {
  const date = req.body?.date || T.today();
  const rows = db.prepare(
    `SELECT * FROM tasks WHERE user_id = ? AND status IN ('pending','in_progress','rescheduled') AND priority != 'high'
     AND substr(scheduled_start, 1, 10) = ? AND scheduled_start > ? ORDER BY scheduled_start`
  ).all(req.userId, date, T.nowDt());
  const moved = [];
  for (const t of rows) {
    const deadline = t.deadline && t.deadline.slice(0, 10) > date ? t.deadline : null;
    const [slot] = suggestSlots(req.userId, {
      minutes: t.estimated_minutes, deadline, priority: t.priority, excludeTaskId: t.id,
      notBefore: T.dt(T.addDays(date, 1), '00:00'), limit: 1, horizonDays: 7,
    });
    if (!slot) continue;
    moveTask(req.userId, t.id, slot.start, slot.end);
    moved.push({ id: t.id, title: t.title, from: t.scheduled_start, fromEnd: t.scheduled_end, to: slot.start, label: slot.label });
  }
  res.json({ moved, skipped: rows.length - moved.length });
});

router.get('/:id', (req, res) => res.json({ task: getTask(req.userId, req.params.id) }));

router.put('/:id', (req, res) => {
  const cur = getTask(req.userId, req.params.id);
  const b = req.body || {};
  const next = {
    title: b.title ?? cur.title,
    description: b.description ?? cur.description,
    estimated_minutes: b.estimated_minutes != null ? Math.max(15, Number(b.estimated_minutes)) : cur.estimated_minutes,
    deadline: 'deadline' in b ? b.deadline || null : cur.deadline,
    priority: PRIORITIES.includes(b.priority) ? b.priority : cur.priority,
    status: STATUSES.includes(b.status) ? b.status : cur.status,
    scheduled_start: 'scheduled_start' in b ? b.scheduled_start || null : cur.scheduled_start,
    scheduled_end: 'scheduled_end' in b ? b.scheduled_end || null : cur.scheduled_end,
  };
  if (next.scheduled_start && !next.scheduled_end) next.scheduled_end = T.addMinutesDt(next.scheduled_start, next.estimated_minutes);
  if (next.scheduled_start && next.estimated_minutes !== cur.estimated_minutes && !('scheduled_end' in b)) {
    next.scheduled_end = T.addMinutesDt(next.scheduled_start, next.estimated_minutes);
  }
  db.prepare(
    'UPDATE tasks SET title=?, description=?, estimated_minutes=?, deadline=?, priority=?, status=?, scheduled_start=?, scheduled_end=? WHERE id=?'
  ).run(next.title, next.description, next.estimated_minutes, next.deadline, next.priority, next.status, next.scheduled_start, next.scheduled_end, cur.id);
  logHistory(req.userId, cur.id, 'edited');
  res.json({ task: getTask(req.userId, cur.id) });
});

router.delete('/:id', (req, res) => {
  db.prepare('DELETE FROM tasks WHERE id = ? AND user_id = ?').run(req.params.id, req.userId);
  res.json({ ok: true });
});

const THRESHOLDS = [[100, 'Goal complete!'], [75, 'Three quarters done'], [50, 'Halfway there!'], [25, 'A quarter of the way']];

router.post('/:id/complete', (req, res) => {
  const t = getTask(req.userId, req.params.id);
  const before = t.goal_id ? goalStats(t.goal_id).progress : null;
  const doneToday = db.prepare("SELECT COUNT(*) AS n FROM tasks WHERE user_id = ? AND status = 'completed' AND substr(completed_at, 1, 10) = ?").get(req.userId, T.today()).n;
  db.prepare("UPDATE tasks SET status = 'completed', completed_at = datetime('now','localtime') WHERE id = ?").run(t.id);
  logHistory(req.userId, t.id, 'completed');
  let celebration = null;
  let goalProgress = null;
  if (t.goal_id) {
    goalProgress = goalStats(t.goal_id).progress;
    const crossed = THRESHOLDS.find(([p]) => before < p && goalProgress >= p);
    if (crossed) celebration = { kind: crossed[0] === 100 ? 'goal' : 'threshold', percent: crossed[0], message: crossed[1], confetti: crossed[0] >= 50 };
    if (goalProgress >= 100) db.prepare("UPDATE goals SET status = 'completed' WHERE id = ?").run(t.goal_id);
    if (t.milestone_id && !celebration) {
      const left = db.prepare("SELECT COUNT(*) AS n FROM tasks WHERE milestone_id = ? AND status NOT IN ('completed','cancelled')").get(t.milestone_id).n;
      if (left === 0) celebration = { kind: 'milestone', message: `Milestone done: ${t.milestone_title}`, confetti: true };
    }
  }
  const goal = t.goal_id ? { id: t.goal_id, title: t.goal_title, before, progress: goalProgress } : null;
  res.json({ task: getTask(req.userId, t.id), goalProgress, celebration, goal, firstToday: doneToday === 0, streak: streakFor(req.userId) });
});

router.post('/:id/uncomplete', (req, res) => {
  const t = getTask(req.userId, req.params.id);
  const past = t.scheduled_start && t.scheduled_start.slice(0, 10) < T.today();
  db.prepare('UPDATE tasks SET status = ?, completed_at = NULL WHERE id = ?').run(past ? 'missed' : 'pending', t.id);
  logHistory(req.userId, t.id, 'reopened');
  // A goal that was finished becomes active again once one of its tasks is reopened.
  if (t.goal_id) db.prepare("UPDATE goals SET status = 'active' WHERE id = ? AND status = 'completed'").run(t.goal_id);
  res.json({ task: getTask(req.userId, t.id) });
});

router.post('/:id/missed', (req, res) => {
  const t = getTask(req.userId, req.params.id);
  db.prepare("UPDATE tasks SET status = 'missed' WHERE id = ?").run(t.id);
  logHistory(req.userId, t.id, 'missed', { from: t.scheduled_start });
  res.json({ task: getTask(req.userId, t.id) });
});

router.post('/:id/status', (req, res) => {
  const t = getTask(req.userId, req.params.id);
  if (!STATUSES.includes(req.body?.status)) return res.status(400).json({ error: 'Unknown status' });
  db.prepare('UPDATE tasks SET status = ? WHERE id = ?').run(req.body.status, t.id);
  logHistory(req.userId, t.id, req.body.status);
  res.json({ task: getTask(req.userId, t.id) });
});

// Everything the reschedule dialog needs: ranked slots, a split plan if nothing fits, and deadline risk.
router.get('/:id/suggestions', (req, res) => {
  const t = getTask(req.userId, req.params.id);
  const base = { minutes: t.estimated_minutes, deadline: t.deadline, priority: t.priority, excludeTaskId: t.id };
  // ?after=<datetime> only offers times after that point (used by one-tap "Later").
  const suggestions = suggestSlots(req.userId, { ...base, limit: 4, notBefore: req.query.after || null });
  const available = t.deadline ? freeMinutesUntil(req.userId, t.deadline, { excludeTaskId: t.id }) : null;
  const split = suggestions.length ? null : splitPlan(req.userId, { ...base });
  const risk = t.deadline && available < t.estimated_minutes
    ? { requiredMinutes: t.estimated_minutes, availableMinutes: available }
    : null;
  res.json({ task: t, suggestions, split, risk, availableMinutes: available });
});

router.post('/:id/move', (req, res) => {
  const { start, end } = req.body || {};
  if (!start) return res.status(400).json({ error: 'Pick a time' });
  const t = getTask(req.userId, req.params.id);
  moveTask(req.userId, t.id, start, end || T.addMinutesDt(start, t.estimated_minutes));
  res.json({ task: getTask(req.userId, t.id) });
});

router.post('/:id/split', (req, res) => {
  const t = getTask(req.userId, req.params.id);
  const chunks = req.body?.chunks || [];
  if (chunks.length < 2) return res.status(400).json({ error: 'A split needs at least two parts' });
  for (const c of chunks) {
    const date = c.start.slice(0, 10);
    const clash = busyBlocks(req.userId, date, date, { excludeTaskId: t.id, includeCompleted: false }).find((b) => b.start < c.end && b.end > c.start);
    if (clash) return res.status(409).json({ error: `${T.fmtSlot(c.start, c.end)} overlaps ${clash.title}` });
  }
  const ids = db.transaction(() => {
    const out = [];
    chunks.forEach((c, i) => {
      const title = `${t.title.replace(/ \(part \d+\/\d+\)$/, '')} (part ${i + 1}/${chunks.length})`;
      if (i === 0) {
        db.prepare("UPDATE tasks SET title=?, estimated_minutes=?, scheduled_start=?, scheduled_end=?, status='rescheduled', reschedule_count = reschedule_count + 1 WHERE id=?")
          .run(title, c.minutes, c.start, c.end, t.id);
        out.push(t.id);
      } else {
        out.push(db.prepare(
          `INSERT INTO tasks (user_id, goal_id, milestone_id, parent_task_id, title, description, estimated_minutes, scheduled_start, scheduled_end, deadline, priority, status, difficulty, resources)
           VALUES (?,?,?,?,?,?,?,?,?,?,?, 'pending', ?, ?)`
        ).run(req.userId, t.goal_id, t.milestone_id, t.id, title, t.description, c.minutes, c.start, c.end, t.deadline, t.priority, t.difficulty,
          t.resources?.length ? JSON.stringify(t.resources) : null).lastInsertRowid);
      }
    });
    logHistory(req.userId, t.id, 'split', { note: `${chunks.length} parts` });
    return out;
  })();
  res.json({ tasks: ids.map((id) => getTask(req.userId, id)) });
});
