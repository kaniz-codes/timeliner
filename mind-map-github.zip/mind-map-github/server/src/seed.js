// Demo account with a realistic, date-relative semester so every screen has something to show.
import bcrypt from 'bcryptjs';
import { fileURLToPath } from 'node:url';
import { db, prefsFor } from './db.js';
import * as T from './lib/time.js';
import { suggestSlots } from './lib/scheduler.js';

export const DEMO_EMAIL = 'demo@mindmap.app';

export function seedDemo() {
  const existing = db.prepare('SELECT id FROM users WHERE email = ?').get(DEMO_EMAIL);
  if (existing) db.prepare('DELETE FROM users WHERE id = ?').run(existing.id);

  const today = T.today();
  const d = (n) => T.addDays(today, n);
  const uid = db.prepare(
    'INSERT INTO users (name, email, password_hash, department, university, year, onboarded) VALUES (?,?,?,?,?,?,1)'
  ).run('Kaniz Fatema', DEMO_EMAIL, bcrypt.hashSync('demo1234', 8), 'Computer Science & Engineering', 'BUBT', '3rd year').lastInsertRowid;
  prefsFor(uid);

  const cls = db.prepare('INSERT INTO classes (user_id, course_code, title, day, start_time, end_time, room, instructor) VALUES (?,?,?,?,?,?,?,?)');
  [
    ['CSE 327', 'Software Engineering', [0, 2], '09:40', '11:10', '301', 'Dr. Rahman'],
    ['CSE 331', 'Microprocessor Interfacing', [1, 3], '11:20', '12:50', '405', 'Dr. Karim'],
    ['MAT 361', 'Discrete Mathematics', [1, 3], '14:00', '15:30', '212', 'Prof. Sultana'],
    ['CSE 373', 'Design & Analysis of Algorithms', [2], '13:00', '14:30', '118', 'Dr. Hasan'],
    ['ENG 105', 'Advanced Writing', [4], '10:00', '11:30', '208', 'Ms. Chowdhury'],
  ].forEach(([code, title, days, s, e, room, who]) => days.forEach((day) => cls.run(uid, code, title, day, s, e, room, who)));

  const goal = db.prepare(
    `INSERT INTO goals (user_id, title, description, start_date, deadline, current_level, weekly_hours, priority, preferred_time, existing_knowledge, status)
     VALUES (?,?,?,?,?,?,?,?,?,?, 'active')`
  );
  const g1 = goal.run(uid, 'Become a Frontend Developer', 'Land a frontend internship by the end of the semester.', d(-28), d(118), 'Beginner', 6, 'high', 'evening', 'Basic HTML').lastInsertRowid;
  const g2 = goal.run(uid, 'IELTS Preparation', 'Score band 7.5 for grad school applications.', d(-28), d(72), 'Intermediate', 4, 'medium', 'morning', 'Took a practice test last year').lastInsertRowid;
  const g3 = goal.run(uid, 'Research Paper on Graph Neural Networks', 'Submit a workshop paper with my supervisor.', d(-21), d(92), 'Intermediate', 5, 'medium', 'afternoon', 'Know PyTorch basics').lastInsertRowid;

  const ms = db.prepare('INSERT INTO milestones (goal_id, position, title, description, duration_weeks) VALUES (?,?,?,?,?)');
  const m11 = ms.run(g1, 0, 'HTML & CSS Foundations', 'Pages that are structured properly and look right on any screen.', 3).lastInsertRowid;
  const m12 = ms.run(g1, 1, 'JavaScript Fundamentals', 'The language itself, before any framework.', 4).lastInsertRowid;
  const m13 = ms.run(g1, 2, 'React Essentials', 'Components, state and hooks.', 4).lastInsertRowid;
  const m21 = ms.run(g2, 0, 'Listening & Reading', 'Speed and accuracy on the objective sections.', 4).lastInsertRowid;
  const m22 = ms.run(g2, 1, 'Writing & Speaking', 'Structure first, then fluency.', 4).lastInsertRowid;
  const m31 = ms.run(g3, 0, 'Literature Review', 'Know what has been done and where the gap is.', 3).lastInsertRowid;
  const m32 = ms.run(g3, 1, 'Experiments', 'Build it, run it, record everything.', 5).lastInsertRowid;

  const task = db.prepare(
    `INSERT INTO tasks (user_id, goal_id, milestone_id, title, estimated_minutes, scheduled_start, scheduled_end, deadline, priority, status, difficulty, resources, completed_at, reschedule_count)
     VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?)`
  );
  const hist = db.prepare('INSERT INTO task_history (user_id, task_id, action, from_start, to_start, created_at) VALUES (?,?,?,?,?,?)');
  const past = (goalId, msId, title, day, time, minutes, status, deadline = null, priority = 'medium', res = null) => {
    const start = T.dt(d(day), time);
    const end = T.addMinutesDt(start, minutes);
    const id = task.run(uid, goalId, msId, title, minutes, start, end, deadline, priority, status, 'moderate',
      res ? JSON.stringify(res) : null, status === 'completed' ? end.replace('T', ' ') : null, 0).lastInsertRowid;
    hist.run(uid, id, status, start, null, `${end.replace('T', ' ')}:00`);
    return id;
  };

  // Four weeks of history: mostly done, a few missed recently.
  past(g1, m11, 'Learn semantic HTML', -27, '19:00', 90, 'completed', null, 'high', [{ title: 'MDN HTML elements', url: 'https://developer.mozilla.org/en-US/docs/Web/HTML/Element' }]);
  past(g2, m21, 'Full diagnostic test', -26, '08:00', 150, 'completed');
  past(g1, m11, 'Learn Flexbox', -24, '19:00', 90, 'completed', null, 'high');
  past(g3, m31, 'Collect 20 key papers', -23, '16:00', 120, 'completed');
  past(g1, m11, 'Learn CSS Grid', -20, '19:00', 90, 'completed', null, 'high');
  past(g2, m21, 'Reading: skimming and scanning', -19, '08:00', 90, 'completed');
  past(g1, m11, 'Build a landing page', -18, '19:30', 120, 'completed');
  past(g3, m31, 'Summarize GNN survey', -17, '16:00', 120, 'missed', d(20));
  past(g1, m12, 'Variables, types and functions', -14, '19:00', 90, 'completed');
  past(g2, m21, 'True/False/Not Given practice', -13, '08:00', 90, 'completed');
  past(g3, m31, 'Compare message-passing methods', -12, '16:00', 120, 'completed');
  past(g1, m12, 'Arrays, objects and loops', -11, '19:00', 120, 'completed');
  past(g1, m12, 'DOM and events', -10, '19:00', 120, 'completed');
  past(g2, m21, 'Listening: maps and diagrams', -9, '08:00', 60, 'completed');
  past(g3, m31, 'Write the problem statement', -8, '16:00', 90, 'completed');
  past(g1, m12, 'Async JS and fetch', -7, '19:00', 120, 'completed');
  past(g2, m22, 'Task 1 report structures', -6, '08:00', 90, 'completed');
  past(g1, m12, 'Build a to-do app in vanilla JS', -5, '19:00', 150, 'completed');
  past(g3, m32, 'Set up baseline experiments', -15, '16:00', 150, 'completed');
  past(g1, m13, 'Components and props', -3, '19:00', 90, 'completed');
  past(g2, m22, 'Speaking part 2 cue cards', -2, '08:00', 60, 'completed');
  past(g1, m13, 'React Hooks practice', -1, '20:00', 60, 'missed', d(3), 'high');
  past(g2, m21, 'Listening section drills', -2, '19:00', 120, 'missed', d(18));
  past(g3, m31, 'Read 3 recent GNN papers', -3, '16:00', 90, 'missed', d(10));
  past(g1, m13, 'Daily practice', -1, '08:30', 30, 'completed');

  // Activities, including one that overlaps a class next Monday.
  const act = db.prepare(
    `INSERT INTO activities (user_id, title, category, description, registration_deadline, event_date, start_time, end_time, location, priority, status, notes, completed_at)
     VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?)`
  );
  const nextWd = (wd) => d(((wd - T.weekday(today) + 7) % 7) || 7);
  act.run(uid, 'Programming Club meetup', 'Club activity', 'Weekly problem-solving session.', null, d(-7), '17:00', '18:30', 'Lab 4', 'medium', 'completed', null, d(-7));
  act.run(uid, 'Blood donation drive', 'Volunteer work', 'Helped at the registration desk.', null, d(-10), '10:00', '13:00', 'Student Center', 'medium', 'completed', null, d(-10));
  act.run(uid, 'Research methods seminar', 'Seminar', 'Talk on reproducible ML research.', null, d(-5), '15:00', '16:30', 'Auditorium', 'low', 'completed', null, d(-5));
  act.run(uid, 'Programming Club meetup', 'Club activity', 'Weekly problem-solving session.', null, nextWd(4), '17:00', '18:30', 'Lab 4', 'medium', 'registered', null, null);
  act.run(uid, 'Friday football', 'Sports', 'Friendly match with the CSE team.', null, nextWd(5), '16:00', '17:30', 'Main field', 'low', 'registered', null, null);
  act.run(uid, 'UI/UX Workshop', 'Workshop', 'Hands-on Figma workshop by the design club.', d(1), d(6), '15:00', '17:00', 'Room 501', 'medium', 'interested', 'Bring a laptop.', null);
  act.run(uid, 'Programming Workshop: Rust basics', 'Workshop', 'Intro to Rust by the systems group.', null, nextWd(1), '15:00', '17:00', 'Lab 2', 'medium', 'registered', null, null);
  act.run(uid, 'Inter-University Programming Contest', 'Competition', 'Team of three, ICPC style.', d(5), d(10), '09:00', '14:00', 'Main campus', 'high', 'interested', 'Ask Tanvir and Mitu to team up.', null);
  act.run(uid, 'Hack the Campus', 'Hackathon', '24-hour student hackathon.', d(6), d(16), '10:00', '20:00', 'Innovation Hub', 'high', 'interested', null, null);
  act.run(uid, 'Career Fair', 'Career fair', 'Tech companies hiring interns.', d(8), d(14), '10:00', '14:00', 'Convention Hall', 'medium', 'upcoming', 'Print resume.', null);

  // A standalone assignment tonight, then future goal work placed into real free time.
  task.run(uid, g1, m13, 'React assignment submission', 60, T.dt(today, '19:00'), T.dt(today, '20:00'), d(1), 'high', 'pending', 'moderate', null, null, 0);
  const future = [
    [g1, m13, 'State and hooks', 120, 'high', 'evening'],
    [g2, m22, 'Task 2 essay practice', 90, 'medium', 'morning'],
    [g3, m32, 'Run main experiments', 150, 'medium', 'afternoon'],
    [g1, m13, 'Effects and data fetching', 120, 'medium', 'evening'],
    [g2, m22, 'Speaking mock interview', 60, 'medium', 'morning'],
    [g3, m32, 'Analyze results', 120, 'medium', 'afternoon'],
    [g1, m13, 'Build a React weather app', 180, 'medium', 'evening'],
    [g2, m22, 'Full timed mock test', 170, 'medium', 'morning'],
    [g3, m32, 'Ablation study', 150, 'medium', 'afternoon'],
    [g1, m13, 'Context and reducers', 120, 'medium', 'evening'],
    [g2, m22, 'Review mistakes and weak areas', 90, 'low', 'morning'],
    [g3, m32, 'Draft introduction and related work', 150, 'medium', 'afternoon'],
    [g1, m13, 'Testing React components', 120, 'low', 'evening'],
    [g3, m32, 'Draft method and results', 180, 'medium', 'afternoon'],
    [g1, m13, 'Build a portfolio site', 180, 'medium', 'evening'],
  ];
  let cursor = T.dt(d(1), '00:00');
  for (const [goalId, msId, title, minutes, priority, preferred] of future) {
    const [slot] = suggestSlots(uid, { minutes, priority, preferred, notBefore: cursor, limit: 1, horizonDays: 45, distinctDays: false });
    if (!slot) continue;
    task.run(uid, goalId, msId, title, minutes, slot.start, slot.end, T.addDays(slot.date, 4), priority, 'pending', 'moderate', null, null, 0);
    cursor = T.addMinutesDt(slot.end, 20 * 60);
  }

  // Reminders already in the past are stored as sent, so the demo doesn't ring on login.
  const remIns = db.prepare('INSERT INTO reminders (user_id, reference_type, reference_id, title, reminder_time, offset_label, status) VALUES (?,?,?,?,?,?,?)');
  const rem = { run: (u, type, ref, title, at, label) => remIns.run(u, type, ref, title, at, label, at <= T.nowDt() ? 'sent' : 'pending') };
  rem.run(uid, 'registration', null, 'UI/UX Workshop registration closes', T.dt(d(1), '10:00'), '1 day before');
  rem.run(uid, 'registration', null, 'Programming Contest registration', T.dt(d(4), '10:00'), '1 day before');
  rem.run(uid, 'task', null, 'React assignment submission', T.dt(today, '18:00'), '1 hour before');
  rem.run(uid, 'activity', null, 'Career Fair: print resume', T.dt(d(11), '09:00'), '3 days before');
  rem.run(uid, 'class', null, 'CSE 327 quiz prep', T.dt(nextWd(0), '08:40'), '1 hour before');

  return uid;
}

if (process.argv[1] === fileURLToPath(import.meta.url)) {
  seedDemo();
  console.log(`Seeded ${DEMO_EMAIL} / demo1234`);
}
