import jwt from 'jsonwebtoken';

const SECRET = () => process.env.JWT_SECRET || 'dev-secret';
const COOKIE = 'mm_session';
const MAX_AGE = 30 * 24 * 60 * 60 * 1000;

export function sign(user) {
  return jwt.sign({ uid: user.id }, SECRET(), { expiresIn: '30d' });
}

// The session lives in an httpOnly cookie, so page scripts can never read the token.
export function setSession(res, user) {
  res.cookie(COOKIE, sign(user), {
    httpOnly: true,
    sameSite: 'lax',
    secure: process.env.NODE_ENV === 'production' && process.env.COOKIE_SECURE !== 'false',
    maxAge: MAX_AGE,
    path: '/',
  });
}

export function clearSession(res) {
  res.clearCookie(COOKIE, { path: '/' });
}

function readCookie(req, name) {
  const header = req.headers.cookie || '';
  for (const part of header.split(';')) {
    const [k, ...v] = part.trim().split('=');
    if (k === name) return decodeURIComponent(v.join('='));
  }
  return null;
}

export function requireAuth(req, res, next) {
  // Cookie first; a Bearer header still works for scripts and tests.
  const header = req.headers.authorization || '';
  const token = readCookie(req, COOKIE) || (header.startsWith('Bearer ') ? header.slice(7) : null);
  if (!token) return res.status(401).json({ error: 'Not signed in' });
  try {
    req.userId = jwt.verify(token, SECRET()).uid;
    next();
  } catch {
    res.status(401).json({ error: 'Session expired, please sign in again' });
  }
}

// Wrap async handlers so thrown errors reach the error middleware.
export const h = (fn) => (req, res, next) => Promise.resolve(fn(req, res, next)).catch(next);
