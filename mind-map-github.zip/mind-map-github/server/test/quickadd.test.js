import { test } from 'node:test';
import assert from 'node:assert/strict';
import { parseQuickAdd } from '../src/lib/quickadd.js';

const REF = '2026-09-23'; // a Wednesday

test('duration and deadline', () => {
  const p = parseQuickAdd('Lab report 2h by Friday', REF);
  assert.equal(p.title, 'Lab report');
  assert.equal(p.minutes, 120);
  assert.equal(p.deadline, '2026-09-25');
});

test('day and time', () => {
  const p = parseQuickAdd('call mom tomorrow 5pm', REF);
  assert.deepEqual([p.title, p.date, p.time], ['Call mom', '2026-09-24', '17:00']);
});

test('minutes, urgency, bare "at 5"', () => {
  const p = parseQuickAdd('urgent Gym 45m at 5', REF);
  assert.deepEqual([p.title, p.minutes, p.priority, p.time, p.date], ['Gym', 45, 'high', '17:00', REF]);
});

test('plain text keeps defaults', () => {
  const p = parseQuickAdd('Read chapter 4', REF);
  assert.deepEqual([p.title, p.minutes, p.date, p.deadline], ['Read chapter 4', 60, null, null]);
});
