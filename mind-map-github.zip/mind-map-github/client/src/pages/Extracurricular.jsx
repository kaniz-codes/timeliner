import { useMemo, useState } from 'react';
import {
  Plus, Users, Trophy, Wrench, Presentation, CodeXml, HeartHandshake, Dumbbell, Music, Briefcase, Sparkles, Tent,
  CalendarDays, Clock, MapPin, Hourglass, AlertTriangle, Star, Ticket, CircleCheck, Ban, Pencil, Trash2, Undo2, CalendarCheck,
} from 'lucide-react';
import { api } from '../lib/api.js';
import { useApp, useApi } from '../lib/app.jsx';
import { EmptyState, PageSkeleton, PriorityBadge, Tabs, Menu } from '../components/ui.jsx';
import { addDays, cap, daysBetween, fmtDate, fmtDayLabel, fmtDuration, fmtTime, today } from '../lib/format.js';
import './extracurricular.css';

const CATEGORY_ICON = {
  'Club activity': Users, Competition: Trophy, Workshop: Wrench, Seminar: Presentation, Hackathon: CodeXml,
  'Volunteer work': HeartHandshake, Sports: Dumbbell, 'Cultural event': Music, 'Career fair': Briefcase, Other: Sparkles,
};
const STATUS_ICON = { interested: Star, registered: Ticket, upcoming: Clock, completed: CircleCheck, cancelled: Ban };
const STATUS_LABEL = { interested: 'Interested', registered: 'Registered', upcoming: 'Upcoming', completed: 'Attended', cancelled: 'Cancelled' };

const isActive = (a) => a.status !== 'completed' && a.status !== 'cancelled';
const shortTitle = (s) => (s || '').split(' · ')[0];
const byDate = (dir = 1) => (x, y) => {
  const a = x.event_date || '9999';
  const b = y.event_date || '9999';
  return a === b ? (x.start_time || '').localeCompare(y.start_time || '') * dir : a.localeCompare(b) * dir;
};

function timeRange(a) {
  if (!a.start_time) return null;
  const [s, sp] = fmtTime(a.start_time).split(' ');
  const [e, ep] = fmtTime(a.end_time).split(' ');
  return sp === ep ? `${s} – ${e} ${ep}` : `${s} ${sp} – ${e} ${ep}`;
}

function daysLeftText(n) {
  if (n === 0) return 'closes today';
  if (n === 1) return '1 day left';
  return `${n} days left`;
}

function StatusPill({ status }) {
  const I = STATUS_ICON[status] || Star;
  return <span className={`ex-status s-${status}`}><I size={13} />{STATUS_LABEL[status] || cap(status)}</span>;
}

function ActivityCard({ a, t, clashes, onOpen, onStatus, onDelete }) {
  const Icon = CATEGORY_ICON[a.category] || Sparkles;
  const past = a.event_date && a.event_date < t;
  const regDays = a.registration_deadline ? daysBetween(t, a.registration_deadline) : null;
  const showReg = a.registration_deadline && a.status === 'interested';
  const range = timeRange(a);
  const dayRel = a.event_date ? fmtDayLabel(a.event_date) : null;
  const dateText = a.event_date
    ? `${fmtDate(a.event_date, { weekday: 'short', month: 'short', day: 'numeric' })}${['Today', 'Tomorrow'].includes(dayRel) ? ` · ${dayRel}` : ''}`
    : 'Date not set';

  let quick = null;
  if (isActive(a) && past) quick = { label: 'Mark attended', icon: CalendarCheck, status: 'completed', primary: true };
  else if (a.status === 'interested') quick = { label: 'Mark registered', icon: Ticket, status: 'registered', primary: true };
  else if (a.status === 'cancelled') quick = { label: 'Restore', icon: Undo2, status: 'interested' };

  const menu = [
    { label: 'Edit', icon: Pencil, onClick: () => onOpen(a) },
    isActive(a) && { label: past ? "Didn't go" : 'Cancel', icon: Ban, onClick: () => onStatus(a, 'cancelled') },
    a.status === 'completed' && { label: 'Not attended after all', icon: Undo2, onClick: () => onStatus(a, 'registered') },
    { label: 'Delete', icon: Trash2, danger: true, onClick: () => onDelete(a) },
  ].filter(Boolean);

  return (
    <article className={`ex-card s-${a.status} ${past && isActive(a) ? 'past' : ''}`} tabIndex={0} role="button"
      aria-label={`${a.title}, ${STATUS_LABEL[a.status]}. Open details`}
      onClick={() => onOpen(a)} onKeyDown={(e) => e.target === e.currentTarget && (e.key === 'Enter' || e.key === ' ') && (e.preventDefault(), onOpen(a))}>
      <div className="ex-card-top">
        <span className="ex-cat"><span className="ex-cat-ic"><Icon size={15} /></span>{a.category}</span>
        <StatusPill status={a.status} />
      </div>
      <h3 className="ex-title">{a.title}</h3>
      <div className="ex-meta">
        <div><CalendarDays size={15} />{dateText}{range && <span className="muted"> · {range}</span>}</div>
        {a.location && <div><MapPin size={15} /><span className="truncate">{a.location}</span></div>}
        {showReg && (regDays >= 0
          ? <div className={`ex-reg ${regDays <= 3 ? 'soon' : ''}`}><Hourglass size={15} />Register by {fmtDate(a.registration_deadline)} · {daysLeftText(regDays)}</div>
          : <div className="ex-reg closed"><Hourglass size={15} />Registration closed {fmtDate(a.registration_deadline)}</div>)}
      </div>
      {clashes?.length > 0 && (
        <div className="conflict ex-clash" title={clashes.map((c) => `${c.title} (${fmtDuration(c.minutes)})`).join(', ')}>
          <AlertTriangle size={14} />
          <span>Overlaps {clashes[0].title} by {fmtDuration(clashes[0].minutes)}{clashes.length > 1 && ` +${clashes.length - 1} more`}</span>
        </div>
      )}
      <div className="ex-foot">
        <PriorityBadge priority={a.priority} />
        <span className="grow" />
        {quick && (
          <button type="button" className={`btn xs ${quick.primary ? 'soft ex-quick' : 'ghost'}`} onClick={(e) => { e.stopPropagation(); onStatus(a, quick.status); }}>
            <quick.icon size={14} />{quick.label}
          </button>
        )}
        <Menu label={`More actions for ${a.title}`} items={menu} />
      </div>
    </article>
  );
}

function StatTile({ icon: I, value, label, hint, kind, onClick, active }) {
  return (
    <button type="button" className={`ex-stat k-${kind} ${active ? 'active' : ''}`} onClick={onClick}>
      <span className="ex-stat-ic"><I size={18} /></span>
      <span className="ex-stat-body">
        <b>{value}</b>
        <span>{label}</span>
        {hint && <em>{hint}</em>}
      </span>
    </button>
  );
}

const TAB_EMPTY = {
  upcoming: { title: 'Nothing coming up', text: 'Clubs, workshops and competitions you add will show here.' },
  registered: { title: "You haven't registered for anything yet", text: 'Mark an activity as registered once you sign up.' },
  completed: { title: 'No attended activities yet', text: 'After an event, mark it attended to keep track of what you did.' },
  all: { title: 'Nothing here yet', text: '' },
};

export default function Extracurricular() {
  const { openDialog, refresh, toast } = useApp();
  const [tab, setTab] = useState('upcoming');
  const t = today();
  const { data, error } = useApi('/activities');
  const { data: cf } = useApi(`/conflicts?from=${t}&to=${addDays(t, 62)}`);

  // activity id → [{ title, minutes }] of everything it overlaps.
  const clashMap = useMemo(() => {
    const m = new Map();
    const add = (x, other, minutes) => {
      if (x.kind !== 'activity') return;
      if (!m.has(x.id)) m.set(x.id, []);
      m.get(x.id).push({ title: shortTitle(other.title), minutes });
    };
    for (const c of cf?.conflicts || []) {
      add(c.a, c.b, c.overlapMinutes);
      add(c.b, c.a, c.overlapMinutes);
    }
    return m;
  }, [cf]);

  if (error) return <div className="page"><div className="form-error">{error.message}</div></div>;
  if (!data) return <PageSkeleton />;

  const all = data.activities;
  const upcoming = all.filter((a) => isActive(a) && !(a.event_date && a.event_date < t)).sort(byDate());
  const registered = all.filter((a) => a.status === 'registered').sort(byDate());
  const completed = all.filter((a) => a.status === 'completed').sort(byDate(-1));
  const everything = [...all].sort(byDate());
  const regOpen = all.filter((a) => a.status === 'interested' && a.registration_deadline && a.registration_deadline >= t)
    .sort((x, y) => x.registration_deadline.localeCompare(y.registration_deadline));
  const waiting = all.filter((a) => (a.status === 'registered' || a.status === 'upcoming') && a.event_date && a.event_date < t);
  const lists = { upcoming, registered, completed, all: everything };
  const shown = lists[tab];

  const setStatus = async (a, status) => {
    try {
      const r = await api.put(`/activities/${a.id}`, { status });
      refresh();
      const clash = r.conflicts?.[0];
      if (status === 'registered' && clash) toast(`Registered. Heads up: it overlaps ${shortTitle(clash.title)} by ${fmtDuration(clash.overlapMinutes)}`, 'info', 4500);
      else if (status === 'registered') toast(`You're registered for ${a.title}`);
      else if (status === 'completed') toast(`Nice. ${a.title} is marked as attended.`);
      else if (status === 'cancelled') toast(`${a.title} cancelled`, 'info');
      else toast(`${a.title} moved back to ${STATUS_LABEL[status].toLowerCase()}`, 'info');
    } catch (e) {
      toast(e.message, 'error');
    }
  };
  const remove = async (a) => {
    try {
      await api.del(`/activities/${a.id}`);
      refresh();
      toast('Activity removed', 'info');
    } catch (e) {
      toast(e.message, 'error');
    }
  };
  const open = (a) => openDialog('activity', { initial: a });
  const nextReg = regOpen[0];

  return (
    <div className="page extracurricular">
      <div className="page-head">
        <div>
          <h1>Extracurricular</h1>
          <p>Clubs, workshops and competitions, planned around your classes.</p>
        </div>
        <div className="page-actions" data-tour="act-add">
          <button className="btn primary" onClick={() => openDialog('activity')}><Plus size={17} />Add activity</button>
        </div>
      </div>

      {all.length === 0 ? (
        <div className="card">
          <EmptyState cat="wave" icon={Tent} title="Nothing planned yet." text="Add your first extracurricular activity."
            action={<button className="btn primary" onClick={() => openDialog('activity')}><Plus size={17} />Add activity</button>} />
        </div>
      ) : (
        <>
          <div className="ex-stats">
            <StatTile icon={CalendarDays} kind="activity" value={upcoming.length} label="Upcoming" active={tab === 'upcoming'} onClick={() => setTab('upcoming')}
              hint={upcoming[0] ? `Next: ${fmtDayLabel(upcoming[0].event_date || t)}` : null} />
            <StatTile icon={Ticket} kind="activity" value={registered.length} label="Registered" active={tab === 'registered'} onClick={() => setTab('registered')} />
            <StatTile icon={CircleCheck} kind="done" value={completed.length} label="Attended" active={tab === 'completed'} onClick={() => setTab('completed')} />
            <StatTile icon={Hourglass} kind="deadline" value={regOpen.length} label={regOpen.length === 1 ? 'Registration open' : 'Registrations open'}
              hint={nextReg ? `Soonest closes ${fmtDayLabel(nextReg.registration_deadline).replace(/^(Today|Tomorrow)$/, (m) => m.toLowerCase())}` : 'None closing soon'}
              onClick={() => setTab('upcoming')} />
          </div>

          {waiting.length > 0 && (
            <section className="card ex-waiting">
              <div className="grow">
                <h3>How did it go?</h3>
                <p className="small muted">{waiting.length === 1 ? 'This one has passed.' : `${waiting.length} activities have passed.`} Mark them so your progress stays accurate.</p>
              </div>
              <div className="stack tight ex-waiting-list">
                {waiting.slice(0, 3).map((a) => (
                  <div key={a.id} className="row wrap ex-waiting-row">
                    <span className="dot activity" />
                    <span className="strong grow truncate">{a.title}</span>
                    <span className="small muted">{fmtDayLabel(a.event_date)}</span>
                    <button className="btn xs soft" onClick={() => setStatus(a, 'completed')}><CalendarCheck size={14} />Attended</button>
                    <button className="btn xs ghost" onClick={() => setStatus(a, 'cancelled')}>Didn't go</button>
                  </div>
                ))}
              </div>
            </section>
          )}

          <div className="ex-toolbar" data-tour="act-tabs">
            <Tabs value={tab} onChange={setTab} options={[
              { value: 'upcoming', label: 'Upcoming', count: upcoming.length },
              { value: 'registered', label: 'Registered', count: registered.length },
              { value: 'completed', label: 'Completed', count: completed.length },
              { value: 'all', label: 'All', count: all.length },
            ]} />
            {clashMap.size > 0 && tab !== 'completed' && (
              <span className="small ex-clash-note"><AlertTriangle size={14} />{clashMap.size} {clashMap.size === 1 ? 'activity overlaps' : 'activities overlap'} something else</span>
            )}
          </div>

          {shown.length === 0 ? (
            <div className="card flat">
              <EmptyState cat="wave" icon={Tent} title={TAB_EMPTY[tab].title} text={TAB_EMPTY[tab].text}
                action={tab !== 'completed' && <button className="btn sm primary" onClick={() => openDialog('activity')}><Plus size={15} />Add activity</button>} />
            </div>
          ) : (
            <div className="ex-grid" key={tab}>
              {shown.map((a) => (
                <ActivityCard key={a.id} a={a} t={t} clashes={a.status === 'completed' || a.status === 'cancelled' ? null : clashMap.get(a.id)}
                  onOpen={open} onStatus={setStatus} onDelete={remove} />
              ))}
            </div>
          )}
        </>
      )}
    </div>
  );
}
