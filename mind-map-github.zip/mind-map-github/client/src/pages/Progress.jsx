import { useState } from 'react';
import { Link } from 'react-router-dom';
import { Flame, Sparkles, CheckCircle2, CircleSlash, CalendarClock, Tent, Target, BookOpen } from 'lucide-react';
import { useApp, useApi } from '../lib/app.jsx';
import { ProgressBar, Ring, EmptyState, CountUp } from '../components/ui.jsx';
import { fmtDate, fmtDuration, today, startOfWeek } from '../lib/format.js';
import { openWeeklyReview } from '../components/WeeklyReview.jsx';
import './progress.css';

const plural = (n, word) => `${n} ${word}${n === 1 ? '' : 's'}`;

function StreakPill({ streak }) {
  if (streak > 0) {
    return <span className="pill streak"><Flame size={15} />{plural(streak, 'productive day')} in a row</span>;
  }
  return <span className="pill streak pg-streak-new"><Sparkles size={15} />Start a new streak today</span>;
}

function StatCard({ icon: Icon, value, label, tone }) {
  return (
    <div className={`card stat pg-stat ${tone}`}>
      <span className="pg-stat-icon"><Icon size={18} /></span>
      <div>
        <div className="value">{typeof value === 'number' ? <CountUp value={value} /> : value}</div>
        <div className="label">{label}</div>
      </div>
    </div>
  );
}

function WeeklyBars({ weekly, weekStart }) {
  const max = Math.max(1, ...weekly.map((w) => w.planned));
  const thisWeek = startOfWeek(today(), weekStart);
  const total = weekly.reduce((s, w) => s + w.planned, 0);
  return (
    <section className="card pg-weekly">
      <div className="card-head">
        <div>
          <h2>Weekly task completion</h2>
          <span className="sub">Last four weeks</span>
        </div>
        <div className="pg-legend">
          <span><i className="pg-key done" />Done</span>
          <span><i className="pg-key planned" />Planned</span>
        </div>
      </div>
      {total === 0 ? (
        <EmptyState icon={CalendarClock} title="No tasks planned yet" text="Once tasks land on your calendar, you'll see how each week went." />
      ) : (
        <div className="pg-bars">
          {weekly.map((w, i) => {
            const current = w.weekStart === thisWeek;
            return (
              <div key={w.weekStart} className={`pg-bar ${current ? 'current' : ''}`}>
                <div className="pg-bar-area">
                  <div className="pg-bar-track" style={{ height: `${(w.planned / max) * 100}%`, animationDelay: `${i * 70}ms` }}
                    title={`${w.done} of ${w.planned} planned tasks done`}>
                    <i style={{ height: w.planned ? `${(w.done / w.planned) * 100}%` : 0, animationDelay: `${120 + i * 70}ms` }} />
                  </div>
                </div>
                <b>{w.planned ? `${w.done} of ${w.planned}` : 'Nothing planned'}</b>
                <span>{current ? 'This week' : <><em className="pg-wk">Week of </em>{fmtDate(w.weekStart)}</>}</span>
              </div>
            );
          })}
        </div>
      )}
    </section>
  );
}

function consistencyLine(consistency) {
  const { activeDays, window } = consistency;
  if (activeDays === 0) return 'Start small today';
  return `Active ${activeDays} of the last ${window} days`;
}

function CompletionRate({ data }) {
  const due = data.completed + data.missed;
  return (
    <section className="card pg-rate">
      <div className="card-head"><h2>Completion rate</h2></div>
      {due === 0 ? (
        <EmptyState icon={CheckCircle2} title="Nothing due yet" text="Your rate shows up once tasks start coming due." />
      ) : (
        <>
          <div className="pg-ring-wrap">
            <Ring value={data.completionRate} size={148} stroke={13} label={`${data.completionRate}% of tasks that were due`}>
              <div>
                <div className="pg-ring-value">{data.completionRate}%</div>
                <div className="tiny muted">of tasks that<br />were due</div>
              </div>
            </Ring>
          </div>
          <p className="small muted pg-center">{data.completed} done · {data.missed} missed</p>
        </>
      )}
      <div className="pg-consistency">
        <Flame size={16} />
        <span>{consistencyLine(data.consistency)}</span>
      </div>
    </section>
  );
}

function Hours({ hours }) {
  const rows = [
    { key: 'classes', label: 'Classes', icon: BookOpen, kind: 'class' },
    { key: 'goals', label: 'Goal work', icon: Target, kind: '' },
    { key: 'activities', label: 'Activities', icon: Tent, kind: 'activity' },
  ];
  const total = rows.reduce((s, r) => s + (hours[r.key] || 0), 0);
  const top = [...rows].sort((a, b) => (hours[b.key] || 0) - (hours[a.key] || 0))[0];
  const topPct = total ? Math.round(((hours[top.key] || 0) / total) * 100) : 0;
  return (
    <section className="card pg-hours">
      <div className="card-head">
        <h2>Where the hours go</h2>
        <span className="sub">{total ? `${fmtDuration(total)} this week` : 'this week'}</span>
      </div>
      {total === 0 ? (
        <p className="small muted">Nothing on the calendar this week yet.</p>
      ) : (
        <div className="stack">
          {rows.map((r) => (
            <div key={r.key} className="pg-hours-row">
              <div className="row between">
                <span className={`row pg-hours-label ${r.kind || 'goal'}`}><r.icon size={15} />{r.label}</span>
                <span className="small strong">{fmtDuration(hours[r.key] || 0)}</span>
              </div>
              <ProgressBar value={((hours[r.key] || 0) / total) * 100} kind={r.kind} label={`${r.label}: ${fmtDuration(hours[r.key] || 0)}`} />
            </div>
          ))}
          <p className="small muted pg-hours-note">
            {top.label} {top.key === 'goals' ? 'takes' : 'take'} the biggest share this week, about {topPct}% of your scheduled time.
          </p>
        </div>
      )}
    </section>
  );
}

function ActivityBreakdown({ list }) {
  return (
    <section className="card">
      <div className="card-head"><h2>Activity breakdown</h2><Link to="/extracurricular" className="small strong">Open</Link></div>
      {list.length === 0 ? (
        <EmptyState icon={Tent} title="No activities yet" text="Clubs, workshops and events you add will show up here." />
      ) : (
        <div className="pg-cats">
          {list.map((c) => (
            <div key={c.category} className="pg-cat">
              <span className="dot activity" />
              <span className="grow truncate">{c.category}</span>
              <span className={`tiny pg-nowrap ${c.done ? 'pg-cat-done' : 'muted'}`}>{c.done} of {c.n} done</span>
            </div>
          ))}
        </div>
      )}
    </section>
  );
}

// Progress lives at the bottom of the Dashboard. Goal bars are left out there
// because the garden already shows each goal's progress.
export function ProgressSection({ compact = false }) {
  const { prefs } = useApp();
  const { data, error } = useApi('/progress');
  const [open, setOpen] = useState(!compact);
  if (error) return <div className="form-error">{error.message}</div>;
  if (!data) return null;
  const weekStart = prefs?.week_start ?? 0;
  return (
    <section id="progress" className="dash-progress">
      <div className="dash-section-head">
        <h2>Progress</h2>
        <div className="row">
          <button className="btn ghost sm" onClick={openWeeklyReview}>Last week's review</button>
          <StreakPill streak={data.streak} />
        </div>
      </div>
      <div className="grid cols-4 pg-stats">
        <StatCard icon={CheckCircle2} value={data.completed} label="tasks completed" tone="done" />
        <StatCard icon={CircleSlash} value={data.missed} label="missed" tone="danger" />
        <StatCard icon={CalendarClock} value={data.rescheduled} label="rescheduled" tone="primary" />
        <StatCard icon={Tent} value={data.activitiesDone} label="activities done" tone="activity" />
      </div>
      {open ? (
        <>
          <div className="grid main-side pg-row">
            <WeeklyBars weekly={data.weekly} weekStart={weekStart} />
            <CompletionRate data={data} />
          </div>
          <div className="grid main-side pg-row">
            <ActivityBreakdown list={data.activityBreakdown} />
            <Hours hours={data.hours} />
          </div>
          {compact && <button className="btn ghost sm pg-more" onClick={() => setOpen(false)}>Hide details</button>}
        </>
      ) : (
        <button className="btn ghost sm pg-more" onClick={() => setOpen(true)}>Show details</button>
      )}
    </section>
  );
}
