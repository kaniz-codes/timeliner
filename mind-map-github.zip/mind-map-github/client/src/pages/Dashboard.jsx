// Dashboard: "What do I do now?" One list for today, a way to add things, and a small side column.
// Hard days switch to one thing at a time.
import { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import { Flame, Check, SkipForward, ChevronRight, Leaf, Target, CalendarClock, Plus, CloudRain } from 'lucide-react';
import { api } from '../lib/api.js';
import { useApp, useApi } from '../lib/app.jsx';
import { Checkbox, CountUp, PageSkeleton, Ring } from '../components/ui.jsx';
import { Cat } from '../components/Cat.jsx';
import Plant, { plantKindFor } from '../components/Plant.jsx';
import { fmtDue, fmtDuration, fmtTime, fmtDayLabel, greeting, minutesBetween, nowDt, today } from '../lib/format.js';
import { play } from '../lib/sound.js';
import { ProgressSection } from './Progress.jsx';
import './dashboard.css';

const MOOD_KEY = 'mindmap.mood';
const LIGHTEN_KEY = 'mindmap.lightened';

function readMood() {
  try {
    const m = JSON.parse(localStorage.getItem(MOOD_KEY));
    return m?.date === today() ? m.mood : null;
  } catch {
    return null;
  }
}

// Re-render every 30s so "now" and time left stay fresh.
function useClock() {
  const [, setT] = useState(0);
  useEffect(() => {
    const id = setInterval(() => setT((t) => t + 1), 30000);
    return () => clearInterval(id);
  }, []);
  return nowDt();
}

const EXAMPLES = ['Lab report 2h by Friday', 'Call Mitu tomorrow 5pm', 'Gym 45m', 'Revise CSE 331 tonight 1h', 'urgent essay due Mon 3h'];

// One line in, one task scheduled into real free time.
function SmartAdd() {
  const { refresh, toast } = useApp();
  const [text, setText] = useState('');
  const [busy, setBusy] = useState(false);
  const [hint] = useState(() => EXAMPLES[Math.floor(Math.random() * EXAMPLES.length)]);
  const submit = async (e) => {
    e.preventDefault();
    if (!text.trim()) return;
    setBusy(true);
    try {
      const r = await api.post('/tasks/quick', { text });
      play('grow');
      refresh();
      setText('');
      const when = r.task.scheduled_start ? `${fmtDayLabel(r.task.scheduled_start)} ${fmtTime(r.task.scheduled_start)}` : 'no free slot yet';
      toast(`Added “${r.task.title}” · ${when}${r.placement?.moved ? ` (${r.placement.moved})` : ''}`);
    } catch (err) {
      toast(err.message, 'error');
    } finally {
      setBusy(false);
    }
  };
  return (
    <form className="smart-add" onSubmit={submit} data-tour="smart-add">
      <Plus size={20} />
      <input value={text} onChange={(e) => setText(e.target.value)} placeholder={`Add anything… e.g. “${hint}”`} aria-label="Add a task in plain words" />
      <button className="btn primary sm" disabled={busy || !text.trim()}>{busy ? 'Adding…' : 'Add'}</button>
    </form>
  );
}

// The main list: missed work first, then today in time order with free gaps and the current item marked.
function TodayList({ data, loose, now }) {
  const { completeTask, uncompleteTask, pushLater, openDialog } = useApp();
  const toggle = (t, isDone) => (isDone ? uncompleteTask(t) : completeTask(t));
  const rows = [
    ...data.schedule.items.map((i) => ({ type: 'item', at: i.start, i })),
    ...data.schedule.free.filter((f) => f.end > now && f.minutes >= 30).map((f) => ({ type: 'free', at: f.start > now ? f.start : now, f })),
  ].sort((a, b) => a.at.localeCompare(b.at));
  const tasks = [...data.schedule.items.filter((i) => i.kind === 'task'), ...loose];
  const done = tasks.filter((t) => t.status === 'completed').length;

  const TaskActions = ({ t, primary }) => (
    <>
      <button className={`btn xs ${primary ? 'primary' : 'ghost'} td-later`} onClick={() => pushLater(t)} title="Move to the next good free slot"><SkipForward size={14} />Later</button>
      {primary && <button className="btn xs ghost" onClick={() => openDialog('reschedule', { task: t })} aria-label={`Choose a time for ${t.title}`} title="Choose a time"><CalendarClock size={14} /></button>}
    </>
  );

  return (
    <section className="card today-card" data-tour="today">
      <div className="card-head">
        <h2>Today</h2>
        {tasks.length > 0 && <span className="today-count">{done}/{tasks.length} done</span>}
      </div>

      {data.missed.length > 0 && (
        <div className="td-group">
          {data.missed.map((t) => (
            <div key={`m${t.id}`} className="td-row missed">
              <span className="td-time">Missed</span>
              <span className="grow truncate strong">{t.title}</span>
              <span className="td-meta">{fmtDuration(t.estimated_minutes)}</span>
              <TaskActions t={t} primary />
            </div>
          ))}
        </div>
      )}

      {rows.length === 0 && loose.length === 0 && <p className="muted td-empty"><Leaf size={16} /> Nothing planned. Add something above.</p>}
      <div className="td-group">
        {rows.map((r) => {
          if (r.type === 'free') {
            return <div key={`f${r.at}`} className="td-free"><span className="td-time">{fmtTime(r.at)}</span><span>Free · {fmtDuration(minutesBetween(r.at, r.f.end))}</span></div>;
          }
          const i = r.i;
          const isTask = i.kind === 'task';
          const isDone = i.status === 'completed';
          const isNow = i.start <= now && i.end > now && !isDone;
          const past = i.end <= now && !isNow;
          return (
            <div key={`${i.kind}${i.id}${i.start}`} className={`td-row ${i.kind} ${isDone ? 'done' : ''} ${isNow ? 'now' : ''} ${past && !isTask ? 'past' : ''}`}>
              <span className="td-time">{isNow ? <b className="now-tag">Now</b> : fmtTime(i.start)}</span>
              {isTask ? <Checkbox checked={isDone} onChange={() => toggle(i, isDone)} label={isDone ? `Mark ${i.title} as not done` : `Done: ${i.title}`} /> : <span className={`dot ${i.kind}`} />}
              <span className="grow truncate">{i.title}</span>
              <span className="td-meta">{i.kind === 'class' ? (i.room ? `Room ${i.room}` : 'Class') : i.kind === 'activity' ? (i.location || 'Activity') : fmtDuration(i.minutes)}</span>
              {isTask && !isDone && <TaskActions t={i} />}
            </div>
          );
        })}
        {loose.map((t) => (
          <div key={`l${t.id}`} className={`td-row task ${t.status === 'completed' ? 'done' : ''}`}>
            <span className="td-time">Any time</span>
            <Checkbox checked={t.status === 'completed'} onChange={() => toggle(t, t.status === 'completed')} label={t.status === 'completed' ? `Mark ${t.title} as not done` : `Done: ${t.title}`} />
            <span className="grow truncate">{t.title}</span>
            <span className="td-meta">{fmtDuration(t.estimated_minutes)}</span>
            {t.status !== 'completed' && <TaskActions t={t} />}
          </div>
        ))}
      </div>
      <Link to="/schedule?view=week" className="card-link">See my week <ChevronRight size={15} /></Link>
    </section>
  );
}

function GoalsCard({ goals }) {
  return (
    <section className="card" data-tour="garden">
      <div className="card-head"><h2>Your garden</h2><Link to="/goals" className="small strong">All goals</Link></div>
      {goals.length === 0 && <Link to="/goals" className="btn soft sm"><Target size={15} />Plant your first goal</Link>}
      <div className="garden">
        {goals.map((g) => (
          <Link key={g.id} to={`/goals/${g.id}`} className="garden-item" title={g.title}>
            <Plant progress={g.progress} kind={plantKindFor(g.id)} size={96} label={g.title} />
            <span className="garden-name">{g.title}</span>
            <span className="garden-pct">{g.progress}%</span>
          </Link>
        ))}
      </div>
    </section>
  );
}

function ComingUp({ list }) {
  if (!list.length) return null;
  return (
    <section className="card">
      <div className="card-head"><h2>Coming up</h2></div>
      <div className="mini-list">
        {list.slice(0, 3).map((d) => (
          <div key={`${d.kind}${d.id}`} className="mini">
            <span className={`dot ${d.kind === 'registration' ? 'activity' : 'deadline'}`} />
            <span className="grow truncate">{d.title.replace('Register: ', '')}</span>
            <span className={`due ${d.priority === 'high' ? 'high' : ''}`}>{fmtDue(d.due).replace('Due ', '')}</span>
          </div>
        ))}
      </div>
    </section>
  );
}

// Hard day: a quiet focus screen. One thing, a ring showing its time, and a way to push the rest.
function HardDay({ data, now, setMood }) {
  const { refresh, toast, completeTask, pushLater } = useApp();
  const items = data.schedule.items.filter((i) => i.status !== 'completed');
  const tasks = data.schedule.items.filter((i) => i.kind === 'task');
  const done = tasks.filter((t) => t.status === 'completed').length;
  const current = items.find((i) => i.start <= now && i.end > now);
  const focus = current || items.find((i) => i.start > now) || data.missed[0] && { ...data.missed[0], kind: 'task', start: null, end: null, missed: true };
  const after = focus && items.filter((i) => i.start > (focus.start || now) && i !== focus)[0];
  const movable = tasks.filter((t) => t.status !== 'completed' && t.priority !== 'high' && t.start > now && t !== focus);
  const [offer, setOffer] = useState(localStorage.getItem(LIGHTEN_KEY) !== today());

  const lighten = async () => {
    localStorage.setItem(LIGHTEN_KEY, today());
    setOffer(false);
    try {
      const r = await api.post('/tasks/lighten', { date: today() });
      refresh();
      if (!r.moved.length) return toast('Nothing could move, and that is okay. Go slow.', 'info');
      play('whoosh');
      toast(`Moved ${r.moved.length} task${r.moved.length > 1 ? 's' : ''} to later this week`, 'success', 6000, {
        label: 'Undo',
        onClick: async () => {
          for (const m of r.moved) await api.post(`/tasks/${m.id}/move`, { start: m.from, end: m.fromEnd }).catch(() => {});
          refresh();
        },
      });
    } catch (e) {
      toast(e.message, 'error');
    }
  };

  // Ring: time left in the current item, or time until the next one starts (within 2 hours).
  let ring = 0;
  let ringLabel = '';
  if (focus?.start && current) {
    const total = minutesBetween(focus.start, focus.end);
    const left = minutesBetween(now, focus.end);
    ring = ((total - left) / total) * 100;
    ringLabel = `${fmtDuration(left)} left`;
  } else if (focus?.start) {
    const until = minutesBetween(now, focus.start);
    ring = Math.max(0, 100 - (until / 120) * 100);
    ringLabel = until <= 0 ? 'starting' : `in ${fmtDuration(until)}`;
  }

  return (
    <div className="focus-mode">
      <div className="focus-miso">
        <Cat mood="sleepy" size={84} />
        <p>{focus ? 'Just this one. I’ll keep the rest safe.' : 'Nothing left today. Rest is part of the plan.'}</p>
      </div>

      {focus ? (
        <section className={`focus-card ${focus.kind}`}>
          <div className="focus-kicker">{focus.missed ? 'Waiting from before' : current ? 'Now' : `Next · ${fmtTime(focus.start)}`}</div>
          <div className="focus-body">
            {focus.start && (
              <Ring value={ring} size={112} stroke={9} color={current ? 'var(--goal)' : 'var(--primary)'} label={ringLabel}>
                <span className="focus-ring-text">{ringLabel}</span>
              </Ring>
            )}
            <div className="grow">
              <div className="focus-title">{focus.title}</div>
              {focus.start && <div className="focus-sub">{fmtTime(focus.start)} – {fmtTime(focus.end)}{focus.room ? ` · Room ${focus.room}` : ''}</div>}
            </div>
          </div>
          {focus.kind === 'task' && (
            <div className="focus-actions">
              <button className="btn primary" onClick={() => completeTask(focus)}><Check size={20} />Done</button>
              <button className="btn" onClick={() => pushLater(focus)}><SkipForward size={20} />Later</button>
            </div>
          )}
          {after && <div className="focus-next">Then {fmtTime(after.start)} · {after.title}</div>}
        </section>
      ) : (
        <section className="focus-card empty"><Leaf size={30} /><div className="focus-title">All clear</div></section>
      )}

      {tasks.length > 0 && (
        <div className="focus-dots" aria-label={`${done} of ${tasks.length} done today`}>
          {tasks.map((t) => <i key={t.id} className={t.status === 'completed' ? 'on' : ''} />)}
        </div>
      )}

      {offer && movable.length > 0 && (
        <button className="focus-lighten" onClick={lighten}>
          <CloudRain size={18} />
          <span className="grow">Move {movable.length} smaller task{movable.length > 1 ? 's' : ''} to later this week</span>
          <ChevronRight size={18} />
        </button>
      )}

      <button className="btn ghost focus-exit" onClick={() => setMood(null)}>I feel better, show my full day</button>
    </div>
  );
}

export default function Dashboard() {
  const { user } = useApp();
  const { data, error } = useApi('/dashboard');
  const { data: dayTasks } = useApi(`/tasks?from=${today()}&to=${today()}&status=pending,in_progress,rescheduled,completed`);
  const [mood, setMoodState] = useState(readMood);
  const now = useClock();
  const setMood = (m) => {
    play('tap');
    if (m) localStorage.setItem(MOOD_KEY, JSON.stringify({ date: today(), mood: m }));
    else localStorage.removeItem(MOOD_KEY);
    setMoodState(m);
  };
  useEffect(() => {
    if (data && window.location.hash === '#progress') setTimeout(() => document.getElementById('progress')?.scrollIntoView({ behavior: 'smooth' }), 400);
  }, [data]);

  if (error) return <div className="page"><div className="form-error">{error.message}</div></div>;
  if (!data) return <PageSkeleton />;
  const name = user?.name?.split(' ')[0] || data.user.name;
  const loose = (dayTasks?.tasks || []).filter((t) => !t.scheduled_start);
  const hard = mood === 'hard';

  return (
    <div className={`page dashboard ${hard ? 'is-hard' : ''}`}>
      <div className="dash-head">
        <h1>{greeting()}, {name}</h1>
        {data.streak > 0 && <span className="pill streak" title={`${data.streak} productive days in a row`}><Flame size={15} /><CountUp value={data.streak} duration={500} /></span>}
        <button className={`btn sm hard-toggle ${hard ? 'on' : ''}`} onClick={() => setMood(hard ? null : 'hard')} aria-pressed={hard} data-tour="mood">
          <CloudRain size={15} />{hard ? 'Hard day mode on' : 'Hard day?'}
        </button>
      </div>

      {hard ? (
        <HardDay data={data} now={now} setMood={setMood} />
      ) : (
        <>
          <SmartAdd />
          <div className="dash-grid">
            <TodayList data={data} loose={loose} now={now} />
            <div className="stack" style={{ gap: 20 }}>
              <GoalsCard goals={data.goals} />
              <ComingUp list={data.deadlines} />
            </div>
          </div>
          <ProgressSection compact />
        </>
      )}
    </div>
  );
}
