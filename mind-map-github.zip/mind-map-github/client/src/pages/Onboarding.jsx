import { useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { User, BookOpen, Tent, Target, Sparkles, Check, ChevronLeft, Plus } from 'lucide-react';
import { api } from '../lib/api.js';
import { useApp } from '../lib/app.jsx';
import { DialogHost } from '../components/dialogs.jsx';
import { Toasts } from '../components/Layout.jsx';
import { Field, ProgressBar } from '../components/ui.jsx';
import * as RoutineImport from './RoutineImport.jsx';
import { DAYS_SHORT, fmtRange, fmtDate } from '../lib/format.js';
import './onboarding.css';

const STEPS = [
  { key: 'profile', title: 'A little about you', text: 'So the planner can talk to you like a person.', icon: User },
  { key: 'routine', title: 'Your class routine', text: 'Upload a photo of your routine or add classes by hand. Everything else gets planned around them.', icon: BookOpen },
  { key: 'activities', title: 'Clubs, events and activities', text: 'Add anything you have coming up. We will warn you if it clashes with a class.', icon: Tent },
  { key: 'goal', title: 'Your first personal goal', text: 'Something bigger than this week: a skill, an exam, a project.', icon: Target },
  { key: 'roadmap', title: 'Generate your AI roadmap', text: 'The planner breaks your goal into milestones and places each task only where you are actually free.', icon: Sparkles },
];

export default function Onboarding() {
  const { user, loadMe, openDialog, version, refresh, toast } = useApp();
  const navigate = useNavigate();
  const [step, setStep] = useState(0);
  const [profile, setProfile] = useState({ name: user?.name || '', department: user?.department || '', university: user?.university || '', year: user?.year || '' });
  const [classes, setClasses] = useState([]);
  const [activities, setActivities] = useState([]);
  const [goal, setGoal] = useState(null);
  const [importing, setImporting] = useState(false);
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState(null);

  useEffect(() => {
    api.get('/classes').then((r) => setClasses(r.classes)).catch(() => {});
    api.get('/activities').then((r) => setActivities(r.activities)).catch(() => {});
    api.get('/goals').then((r) => r.goals[0] && setGoal((g) => g || r.goals[0])).catch(() => {});
  }, [version]);

  const finish = async (to = '/') => {
    await api.put('/me', { onboarded: true });
    await loadMe();
    navigate(to);
  };

  const next = async () => {
    setError(null);
    if (STEPS[step].key === 'profile') {
      if (!profile.name.trim()) return setError('What should we call you?');
      setBusy(true);
      try {
        await api.put('/me', profile);
      } catch (e) {
        setBusy(false);
        return setError(e.message);
      }
      setBusy(false);
    }
    setStep((s) => Math.min(s + 1, STEPS.length - 1));
  };

  const generate = async () => {
    setBusy(true);
    setError(null);
    try {
      const r = await api.post(`/goals/${goal.id}/roadmap`);
      await api.put('/me', { onboarded: true });
      await loadMe();
      refresh();
      navigate(`/planner/review/${r.roadmap.id}`);
    } catch (e) {
      setError(e.message);
      setBusy(false);
    }
  };

  const S = STEPS[step];
  const bind = (k) => ({ value: profile[k], onChange: (e) => setProfile((p) => ({ ...p, [k]: e.target.value })) });

  return (
    <div className="onb">
      <header className="onb-top">
        <div className="row"><img src="/logo.svg" alt="" width={32} height={32} style={{ borderRadius: 9 }} /><strong className="onb-brand">MIND MAP</strong></div>
        <button className="btn ghost sm" onClick={() => finish('/')}>Skip setup</button>
      </header>

      <main className="onb-main">
        <div className="onb-progress">
          <span className="small strong">{step + 1} of {STEPS.length}</span>
          <ProgressBar value={((step + 1) / STEPS.length) * 100} label="Setup progress" />
          <ol className="onb-steps">
            {STEPS.map((s, i) => (
              <li key={s.key} className={i === step ? 'active' : i < step ? 'done' : ''}>
                <span>{i < step ? <Check size={13} /> : i + 1}</span>{s.title}
              </li>
            ))}
          </ol>
        </div>

        <section key={S.key} className="card onb-card">
          <div className="onb-icon"><S.icon size={24} /></div>
          <h1>{S.title}</h1>
          <p className="muted">{S.text}</p>
          {error && <div className="form-error" style={{ marginTop: 14 }}>{error}</div>}

          <div className="onb-body">
            {S.key === 'profile' && (
              <div className="form-grid">
                <Field label="Name" full><input className="input" autoFocus {...bind('name')} /></Field>
                <Field label="Department"><input className="input" placeholder="Computer Science & Engineering" {...bind('department')} /></Field>
                <Field label="University"><input className="input" placeholder="BUBT" {...bind('university')} /></Field>
                <Field label="Year"><input className="input" placeholder="3rd year" {...bind('year')} /></Field>
              </div>
            )}

            {S.key === 'routine' && (
              importing && RoutineImport.RoutineImporter ? (
                <RoutineImport.RoutineImporter compact onDone={() => { setImporting(false); refresh(); }} />
              ) : (
                <div className="stack">
                  <div className="row wrap">
                    <button className="btn primary" onClick={() => setImporting(true)}><BookOpen size={16} />Upload routine image</button>
                    <button className="btn" onClick={() => openDialog('class')}><Plus size={16} />Add a class manually</button>
                  </div>
                  {classes.length > 0 ? (
                    <div className="onb-list">
                      {classes.map((c) => (
                        <div key={c.id} className="item class"><div className="grow"><div className="item-title">{c.course_code}{c.title ? ` · ${c.title}` : ''}</div><div className="item-meta">{DAYS_SHORT[c.day]} · {fmtRange(c.start_time, c.end_time)}{c.room ? ` · Room ${c.room}` : ''}</div></div></div>
                      ))}
                    </div>
                  ) : <p className="small muted">No classes yet. A clear screenshot of your routine works best.</p>}
                </div>
              )
            )}

            {S.key === 'activities' && (
              <div className="stack">
                <button className="btn" style={{ alignSelf: 'flex-start' }} onClick={() => openDialog('activity')}><Plus size={16} />Add an activity</button>
                {activities.length > 0 ? (
                  <div className="onb-list">
                    {activities.map((a) => (
                      <div key={a.id} className="item activity"><div className="grow"><div className="item-title">{a.title}</div><div className="item-meta">{a.category}{a.event_date ? ` · ${fmtDate(a.event_date)}` : ''}</div></div></div>
                    ))}
                  </div>
                ) : <p className="small muted">Nothing planned yet? That's fine, you can add these any time.</p>}
              </div>
            )}

            {S.key === 'goal' && (
              goal ? (
                <div className="item goal"><div className="grow"><div className="item-title">{goal.title}</div><div className="item-meta">{goal.weekly_hours}h a week{goal.deadline ? ` · by ${fmtDate(goal.deadline)}` : ''}</div></div>
                  <button className="btn sm ghost" onClick={() => openDialog('goal', { initial: goal, onSaved: setGoal })}>Edit</button></div>
              ) : (
                <button className="btn primary" onClick={() => openDialog('goal', { onSaved: (g) => { setGoal(g); toast('Goal saved'); } })}><Target size={16} />Create a goal</button>
              )
            )}

            {S.key === 'roadmap' && (
              goal ? (
                <div className="stack">
                  <div className="onb-considers">
                    <span><BookOpen size={15} />{classes.length} weekly classes</span>
                    <span><Tent size={15} />{activities.length} activities</span>
                    <span><Target size={15} />{goal.weekly_hours}h a week for {goal.title}</span>
                  </div>
                  <button className="btn primary" disabled={busy} onClick={generate}>
                    {busy ? <><span className="spinner" style={{ borderTopColor: '#fff' }} />Drafting milestones and finding free time…</> : <><Sparkles size={16} />Generate AI Roadmap</>}
                  </button>
                </div>
              ) : <p className="small muted">Create a goal in the previous step first, or finish setup and do it later.</p>
            )}
          </div>

          <div className="onb-foot">
            {step > 0 ? <button className="btn ghost" onClick={() => setStep((s) => s - 1)}><ChevronLeft size={16} />Back</button> : <span />}
            <div className="row">
              {step < STEPS.length - 1 && step > 0 && <button className="btn ghost" onClick={() => setStep((s) => s + 1)}>Skip this step</button>}
              {step < STEPS.length - 1
                ? <button className="btn primary" disabled={busy} onClick={next}>Continue</button>
                : <button className="btn" onClick={() => finish('/')}>Finish and go to dashboard</button>}
            </div>
          </div>
        </section>
      </main>
      <Toasts />
      <DialogHost />
    </div>
  );
}
