import { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { Sparkles, BookOpen, Target, Tent } from 'lucide-react';
import { api } from '../lib/api.js';
import { useApp } from '../lib/app.jsx';
import { Field } from '../components/ui.jsx';
import './login.css';

export default function Login({ mode }) {
  const register = mode === 'register';
  const { signIn } = useApp();
  const navigate = useNavigate();
  const [v, setV] = useState({ name: '', email: '', password: '' });
  const [error, setError] = useState(null);
  const [busy, setBusy] = useState(null);

  const bind = (k) => ({ value: v[k], onChange: (e) => setV((s) => ({ ...s, [k]: e.target.value })) });

  const submit = async (e) => {
    e.preventDefault();
    setBusy('form');
    setError(null);
    try {
      const r = await api.post(register ? '/auth/register' : '/auth/login', v);
      signIn(r.user);
      navigate(r.user.onboarded ? '/' : '/onboarding');
    } catch (err) {
      setError(err.message);
    } finally {
      setBusy(null);
    }
  };

  const demo = async () => {
    setBusy('demo');
    setError(null);
    try {
      const r = await api.post('/auth/demo');
      signIn(r.user);
      navigate('/');
    } catch (err) {
      setError(err.message);
      setBusy(null);
    }
  };

  return (
    <div className="auth">
      <section className="auth-art" aria-hidden="true">
        <div className="brand-lg"><img src="/logo.svg" alt="" width={44} height={44} /><span>MIND MAP</span></div>
        <h1>Plan smarter.<br />Balance better.</h1>
        <p>Classes, clubs and big goals in one calm plan. It finds your free time and keeps you on track when a day slips.</p>
        <div className="auth-preview">
          <div className="ap-card" style={{ '--c': 'var(--class)' }}><BookOpen size={16} /><div><b>CSE 327 · Software Engineering</b><span>9:40 AM · Room 301</span></div></div>
          <div className="ap-card" style={{ '--c': 'var(--goal)' }}><Target size={16} /><div><b>React Hooks practice</b><span>Moved to Thu 4:00 PM</span></div></div>
          <div className="ap-free">Free · 4:00 – 6:00 PM</div>
          <div className="ap-card" style={{ '--c': 'var(--activity)' }}><Tent size={16} /><div><b>Programming Club</b><span>5:00 PM · Lab 4</span></div></div>
          <div className="ap-bubble"><Sparkles size={14} />Thursday afternoon is free. That looks like the safest place for this task.</div>
        </div>
      </section>

      <section className="auth-form">
        <form onSubmit={submit} className="auth-box">
          <div className="brand-sm"><img src="/logo.svg" alt="" width={36} height={36} /><span>MIND MAP</span></div>
          <h2>{register ? 'Create your account' : 'Welcome back'}</h2>
          <p className="muted small" style={{ marginBottom: 8 }}>{register ? 'Takes a minute. We\'ll set up your week together.' : 'Log in to see what matters today.'}</p>
          {error && <div className="form-error">{error}</div>}
          {register && <Field label="Name"><input className="input" autoComplete="name" placeholder="Kaniz Fatema" {...bind('name')} required /></Field>}
          <Field label="Email"><input className="input" type="email" autoComplete="email" placeholder="you@university.edu" {...bind('email')} required /></Field>
          <Field label="Password" hint={register ? 'at least 6 characters' : undefined}>
            <input className="input" type="password" autoComplete={register ? 'new-password' : 'current-password'} {...bind('password')} required minLength={register ? 6 : undefined} />
          </Field>
          {!register && <Link to="/forgot" className="small strong auth-forgot">Forgot password?</Link>}
          <button className="btn primary block" disabled={!!busy}>{busy === 'form' ? 'One moment…' : register ? 'Create Account' : 'Log In'}</button>
          {register
            ? <Link to="/login" className="btn block">I already have an account</Link>
            : <Link to="/register" className="btn block">Create Account</Link>}
          <div className="auth-or"><span>or</span></div>
          <button type="button" className="btn soft block" onClick={demo} disabled={!!busy}>
            <Sparkles size={16} />{busy === 'demo' ? 'Setting up a demo week…' : 'Continue as Demo User'}
          </button>
          <p className="tiny muted" style={{ textAlign: 'center' }}>The demo has a full semester of sample data, reset on each visit.</p>
        </form>
      </section>
    </div>
  );
}
