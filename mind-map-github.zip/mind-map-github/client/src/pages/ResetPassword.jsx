// Forgot password (ask for a link) and reset password (use the link), on the same calm auth layout.
import { useState } from 'react';
import { Link, useNavigate, useSearchParams } from 'react-router-dom';
import { MailCheck } from 'lucide-react';
import { api } from '../lib/api.js';
import { useApp } from '../lib/app.jsx';
import { Field } from '../components/ui.jsx';
import { Cat } from '../components/Cat.jsx';
import './login.css';

function Shell({ children }) {
  return (
    <div className="auth auth-single">
      <section className="auth-form">
        <div className="auth-box">
          <div className="brand-sm" style={{ display: 'flex' }}><img src="/logo.svg" alt="" width={36} height={36} /><span>MIND MAP</span></div>
          {children}
        </div>
      </section>
    </div>
  );
}

export function ForgotPassword() {
  const [email, setEmail] = useState('');
  const [sent, setSent] = useState(null);
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState(null);
  const submit = async (e) => {
    e.preventDefault();
    setBusy(true);
    setError(null);
    try {
      setSent(await api.post('/auth/forgot', { email }));
    } catch (err) {
      setError(err.message);
    } finally {
      setBusy(false);
    }
  };
  if (sent) {
    return (
      <Shell>
        <div className="auth-done"><MailCheck size={30} /></div>
        <h2>Check your email</h2>
        <p className="muted">If an account exists for <b>{email}</b>, a link to reset the password is on its way. It works for 30 minutes.</p>
        {sent.delivery === 'console' && (
          <p className="small auth-note">Running locally without email set up: the reset link is printed in the server terminal.</p>
        )}
        <Link to="/login" className="btn block">Back to log in</Link>
      </Shell>
    );
  }
  return (
    <Shell>
      <div className="row" style={{ gap: 12 }}><Cat mood="think" size={56} /><h2>Forgot your password?</h2></div>
      <p className="muted small">Type your email and we'll send you a link to choose a new one.</p>
      <form onSubmit={submit} className="stack">
        {error && <div className="form-error">{error}</div>}
        <Field label="Email"><input className="input" type="email" autoComplete="email" value={email} onChange={(e) => setEmail(e.target.value)} required autoFocus /></Field>
        <button className="btn primary block" disabled={busy}>{busy ? 'Sending…' : 'Send reset link'}</button>
        <Link to="/login" className="btn ghost block">Back to log in</Link>
      </form>
    </Shell>
  );
}

export default function ResetPassword() {
  const [params] = useSearchParams();
  const navigate = useNavigate();
  const { signIn } = useApp();
  const [v, setV] = useState({ password: '', confirm: '' });
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState(null);
  const token = params.get('token');
  const submit = async (e) => {
    e.preventDefault();
    if (v.password !== v.confirm) return setError("The two passwords don't match");
    setBusy(true);
    setError(null);
    try {
      const r = await api.post('/auth/reset', { token, password: v.password });
      signIn(r.user);
      navigate('/');
    } catch (err) {
      setError(err.message);
      setBusy(false);
    }
  };
  return (
    <Shell>
      <h2>Choose a new password</h2>
      {!token && <div className="form-error">This link is incomplete. <Link to="/forgot">Ask for a new one</Link>.</div>}
      <form onSubmit={submit} className="stack">
        {error && <div className="form-error">{error}</div>}
        <Field label="New password" hint="at least 6 characters">
          <input className="input" type="password" autoComplete="new-password" minLength={6} value={v.password} onChange={(e) => setV({ ...v, password: e.target.value })} required autoFocus />
        </Field>
        <Field label="Type it again">
          <input className="input" type="password" autoComplete="new-password" value={v.confirm} onChange={(e) => setV({ ...v, confirm: e.target.value })} required />
        </Field>
        <button className="btn primary block" disabled={busy || !token}>{busy ? 'Saving…' : 'Save and log in'}</button>
      </form>
    </Shell>
  );
}
