import { useEffect, useState } from 'react';
import { Sun, Moon, Clock, Bell, KeyRound, RotateCcw, Trash2, LogOut, Info, Volume2, VolumeX } from 'lucide-react';
import { api } from '../lib/api.js';
import { Cat, catEnabled, setCatEnabled } from '../components/Cat.jsx';
import { openGuide } from '../components/MisoGuide.jsx';
import { play, soundOn, setSoundOn } from '../lib/sound.js';
import { useApp } from '../lib/app.jsx';
import { Field, Modal, PageSkeleton } from '../components/ui.jsx';
import { fmtTime } from '../lib/format.js';
import './settings.css';

const STUDY = [
  { value: 'morning', label: 'Morning' },
  { value: 'afternoon', label: 'Afternoon' },
  { value: 'evening', label: 'Evening' },
  { value: 'any', label: 'Any time' },
];
const REMINDER_OFFSETS = [
  { value: 10, label: '10 minutes before' },
  { value: 15, label: '15 minutes before' },
  { value: 30, label: '30 minutes before' },
  { value: 60, label: '1 hour before' },
  { value: 120, label: '2 hours before' },
  { value: 1440, label: '1 day before' },
];

const dayFields = (p) => ({
  day_start: p.day_start, day_end: p.day_end, sleep_start: p.sleep_start, sleep_end: p.sleep_end,
  preferred_study: p.preferred_study, hours: String((p.max_daily_minutes || 0) / 60), week_start: p.week_start,
  semester_start: p.semester_start || '', semester_end: p.semester_end || '',
});

function Switch({ checked, onChange, label, disabled }) {
  return (
    <button type="button" role="switch" aria-checked={checked} aria-label={label} disabled={disabled}
      className={`st-switch ${checked ? 'on' : ''}`} onClick={() => onChange(!checked)}>
      <i />
    </button>
  );
}

function Section({ icon: Icon, title, sub, children, tour }) {
  return (
    <section className="card st-section" data-tour={tour}>
      <div className="st-section-head">
        <span className="st-icon"><Icon size={18} /></span>
        <div><h2>{title}</h2>{sub && <p className="small muted">{sub}</p>}</div>
      </div>
      {children}
    </section>
  );
}

function Appearance() {
  const { theme, setTheme, toast } = useApp();
  const [cat, setCat] = useState(catEnabled());
  const [sound, setSound] = useState(soundOn());
  const toggleSound = () => {
    setSoundOn(!sound);
    setSound(!sound);
    if (!sound) setTimeout(() => play('complete'), 50);
  };
  const toggleCat = () => {
    setCatEnabled(!cat);
    setCat(!cat);
    toast(cat ? 'Miso is taking a nap. Turn her back on any time.' : 'Miso is back!');
  };
  const opts = [
    { value: 'light', label: 'Light', icon: Sun },
    { value: 'dark', label: 'Dark', icon: Moon },
  ];
  return (
    <Section tour="set-look" icon={Sun} title="Appearance" sub="Pick what's easier on your eyes. It switches instantly.">
      <div className="st-themes" role="radiogroup" aria-label="Theme">
        {opts.map((o) => (
          <button key={o.value} type="button" role="radio" aria-checked={theme === o.value}
            className={`st-theme ${o.value} ${theme === o.value ? 'active' : ''}`} onClick={() => setTheme(o.value)}>
            <span className="st-preview" aria-hidden="true"><i /><b /><b /></span>
            <span className="row"><o.icon size={15} />{o.label}</span>
          </button>
        ))}
      </div>
      <div className="st-miso">
        <span className="st-sound-icon">{sound ? <Volume2 size={22} /> : <VolumeX size={22} />}</span>
        <div className="grow">
          <div className="strong">Sounds</div>
          <div className="small muted">{sound ? 'Soft sounds when you finish things.' : 'Silent.'}</div>
        </div>
        <button type="button" className="btn sm" onClick={toggleSound}>{sound ? 'Mute' : 'Turn on'}</button>
      </div>
      <div className="st-miso">
        <Cat mood={cat ? 'wave' : 'sleepy'} size={52} />
        <div className="grow">
          <div className="strong">Miso the cat</div>
          <div className="small muted">{cat ? 'Shows up with small tips.' : 'Hidden. Miso is napping.'}</div>
        </div>
        <button type="button" className="btn sm" onClick={toggleCat}>{cat ? 'Hide Miso' : 'Show Miso'}</button>
      </div>
      <button type="button" className="btn soft block" style={{ marginTop: 12 }} onClick={openGuide}>Open Miso's guide</button>
    </Section>
  );
}

function YourDay() {
  const { prefs, setPrefs, refresh, toast } = useApp();
  const [v, setV] = useState(() => dayFields(prefs));
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState('');
  useEffect(() => { setV(dayFields(prefs)); }, [prefs]);

  const bind = (k) => ({ value: v[k], onChange: (e) => setV((s) => ({ ...s, [k]: e.target.value })) });
  const dirty = JSON.stringify(v) !== JSON.stringify(dayFields(prefs));
  const hours = Number(v.hours);

  const save = async (e) => {
    e.preventDefault();
    setError('');
    if (v.day_start >= v.day_end) { setError('Your day has to start before it ends.'); return; }
    if (!(hours > 0 && hours <= 16)) { setError('Max study time should be between 0.5 and 16 hours.'); return; }
    setSaving(true);
    try {
      const { hours: _h, ...rest } = v;
      const { preferences } = await api.put('/me/preferences', { ...rest, week_start: Number(v.week_start), max_daily_minutes: Math.round(hours * 60) });
      setPrefs(preferences);
      refresh();
      toast('Saved. Your free time is recalculated.');
    } catch (err) {
      setError(err.message);
    } finally {
      setSaving(false);
    }
  };

  return (
    <Section tour="set-day" icon={Clock} title="Your day" sub="When you're awake and how much studying feels realistic.">
      <form onSubmit={save}>
        <div className="form-grid st-day-grid">
          <Field label="Day starts"><input type="time" className="input" {...bind('day_start')} /></Field>
          <Field label="Day ends"><input type="time" className="input" {...bind('day_end')} /></Field>
          <Field label="Sleep from"><input type="time" className="input" {...bind('sleep_start')} /></Field>
          <Field label="Wake up at"><input type="time" className="input" {...bind('sleep_end')} /></Field>
          <Field label="Best time to study" full>
            <div className="row wrap" role="radiogroup" aria-label="Best time to study">
              {STUDY.map((s) => (
                <button key={s.value} type="button" role="radio" aria-checked={v.preferred_study === s.value}
                  className={`chip ${v.preferred_study === s.value ? 'active' : ''}`} onClick={() => setV((x) => ({ ...x, preferred_study: s.value }))}>
                  {s.label}
                </button>
              ))}
            </div>
          </Field>
          <Field label="Max study per day" hint="hours">
            <input type="number" className="input" min={0.5} max={16} step={0.5} {...bind('hours')} />
          </Field>
          <Field label="Week starts on">
            <div className="tabs st-week" role="radiogroup" aria-label="Week starts on">
              {[{ value: 0, label: 'Sunday' }, { value: 1, label: 'Monday' }].map((o) => (
                <button key={o.value} type="button" role="radio" aria-checked={Number(v.week_start) === o.value}
                  className={Number(v.week_start) === o.value ? 'active' : ''} onClick={() => setV((s) => ({ ...s, week_start: o.value }))}>
                  {o.label}
                </button>
              ))}
            </div>
          </Field>
          <Field label="Semester starts" hint="optional">
            <input type="date" className="input" {...bind('semester_start')} />
          </Field>
          <Field label="Semester ends" hint="classes stop repeating after this">
            <input type="date" className="input" min={v.semester_start || undefined} {...bind('semester_end')} />
          </Field>
        </div>
        <div className="st-note">
          <Info size={16} />
          <span>
            Free-time detection only looks between <strong>{fmtTime(v.day_start)}</strong> and <strong>{fmtTime(v.day_end)}</strong>,
            skips your sleep hours, and won't plan more than <strong>{hours > 0 ? `${hours}h` : '…'}</strong> of study on one day.
            The assistant and auto-scheduling use the same rules.
          </span>
        </div>
        {error && <div className="form-error" style={{ marginTop: 12 }}>{error}</div>}
        <div className="st-actions">
          {dirty && <button type="button" className="btn ghost" onClick={() => setV(dayFields(prefs))}>Discard</button>}
          <button type="submit" className="btn primary" disabled={!dirty || saving}>{saving ? 'Saving…' : 'Save changes'}</button>
        </div>
      </form>
    </Section>
  );
}

function Notifications() {
  const { prefs, setPrefs, toast } = useApp();
  const supported = typeof window !== 'undefined' && 'Notification' in window;
  const [permission, setPermission] = useState(supported ? Notification.permission : 'unsupported');
  const on = !!prefs.notify_browser && permission === 'granted';

  const update = async (patch, msg) => {
    try {
      const { preferences } = await api.put('/me/preferences', patch);
      setPrefs(preferences);
      if (msg) toast(msg);
    } catch (err) { toast(err.message, 'error'); }
  };

  const toggle = async (next) => {
    if (!next) return update({ notify_browser: 0 }, 'Browser notifications are off.');
    if (!supported) return toast("This browser doesn't support notifications.", 'error');
    const result = permission === 'granted' ? 'granted' : await Notification.requestPermission();
    setPermission(result);
    if (result === 'granted') update({ notify_browser: 1 }, "Notifications are on. We'll only ping you for reminders.");
    else toast('Your browser blocked notifications. You can allow them in the site settings.', 'error', 5000);
  };

  const status = {
    unsupported: "This browser doesn't support notifications.",
    denied: 'Blocked in your browser settings. Allow notifications for this site to turn them on.',
    default: 'Your browser will ask for permission the first time.',
    granted: on ? 'On. Reminders pop up even when this tab is in the background.' : 'Allowed by your browser, currently off.',
  }[permission];

  return (
    <Section icon={Bell} title="Notifications" sub="Gentle nudges for the things you asked to be reminded about.">
      <div className="st-line">
        <div className="grow">
          <div className="strong">Browser notifications</div>
          <div className="small muted">{status}</div>
        </div>
        <Switch checked={on} onChange={toggle} label="Browser notifications" disabled={permission === 'unsupported'} />
      </div>
      <div className="divider" />
      <div className="st-line">
        <div className="grow">
          <div className="strong">Default reminder</div>
          <div className="small muted">Used when you add a reminder to a task, class or activity.</div>
        </div>
        <select className="select st-select" aria-label="Default reminder" value={prefs.default_reminder}
          onChange={(e) => update({ default_reminder: Number(e.target.value) }, 'Default reminder updated.')}>
          {REMINDER_OFFSETS.map((o) => <option key={o.value} value={o.value}>{o.label}</option>)}
          {!REMINDER_OFFSETS.some((o) => o.value === prefs.default_reminder) && <option value={prefs.default_reminder}>{prefs.default_reminder} minutes before</option>}
        </select>
      </div>
    </Section>
  );
}

function Account() {
  const { loadMe, refresh, logout, toast } = useApp();
  const [pw, setPw] = useState({ current: '', next: '', confirm: '' });
  const [pwError, setPwError] = useState('');
  const [pwSaving, setPwSaving] = useState(false);
  const [confirmReset, setConfirmReset] = useState(false);
  const [resetting, setResetting] = useState(false);

  const changePassword = async (e) => {
    e.preventDefault();
    setPwError('');
    if (pw.next.length < 6) { setPwError('Your new password needs at least 6 characters.'); return; }
    if (pw.next !== pw.confirm) { setPwError("The two new passwords don't match."); return; }
    setPwSaving(true);
    try {
      await api.put('/me/password', { current: pw.current, next: pw.next });
      setPw({ current: '', next: '', confirm: '' });
      toast('Password changed.');
    } catch (err) {
      setPwError(err.message);
    } finally {
      setPwSaving(false);
    }
  };

  const replay = async () => {
    try {
      await api.put('/me', { onboarded: false });
      await loadMe();
    } catch (err) { toast(err.message, 'error'); }
  };

  const reset = async () => {
    setResetting(true);
    try {
      await api.del('/me/data');
      refresh();
      setConfirmReset(false);
      toast('Your data is cleared. Fresh start.', 'info');
    } catch (err) {
      toast(err.message, 'error');
    } finally {
      setResetting(false);
    }
  };

  const bind = (k) => ({ value: pw[k], onChange: (e) => setPw((s) => ({ ...s, [k]: e.target.value })) });

  return (
    <Section icon={KeyRound} title="Account" sub="Password, setup and your data.">
      <form onSubmit={changePassword}>
        <h3 className="st-sub">Change password</h3>
        <div className="form-grid st-pw">
          <Field label="Current password"><input type="password" className="input" autoComplete="current-password" {...bind('current')} /></Field>
          <Field label="New password" hint="6+ characters"><input type="password" className="input" autoComplete="new-password" {...bind('next')} /></Field>
          <Field label="Repeat new password"><input type="password" className="input" autoComplete="new-password" {...bind('confirm')} /></Field>
        </div>
        {pwError && <div className="form-error" style={{ marginTop: 12 }}>{pwError}</div>}
        <div className="st-actions">
          <button type="submit" className="btn" disabled={pwSaving || !pw.current || !pw.next}>{pwSaving ? 'Changing…' : 'Change password'}</button>
        </div>
      </form>
      <div className="divider" />
      <div className="st-line">
        <div className="grow">
          <div className="strong">Replay onboarding</div>
          <div className="small muted">Walk through setup again: classes, your day and a first goal. Nothing gets deleted.</div>
        </div>
        <button type="button" className="btn sm" onClick={replay}><RotateCcw size={15} />Replay</button>
      </div>
      <div className="divider" />
      <div className="st-line">
        <div className="grow">
          <div className="strong">Reset my data</div>
          <div className="small muted">Removes classes, goals, tasks, activities, reminders and chat history. Your account stays.</div>
        </div>
        <button type="button" className="btn sm danger" onClick={() => setConfirmReset(true)}><Trash2 size={15} />Reset data</button>
      </div>
      <div className="divider" />
      <div className="st-line">
        <div className="grow">
          <div className="strong">Sign out</div>
          <div className="small muted">You can sign back in any time. Your plan stays saved.</div>
        </div>
        <button type="button" className="btn sm" onClick={logout}><LogOut size={15} />Sign out</button>
      </div>

      {confirmReset && (
        <Modal title="Reset all your data?" onClose={() => !resetting && setConfirmReset(false)}
          footer={(
            <>
              <button className="btn ghost" onClick={() => setConfirmReset(false)} disabled={resetting}>Keep my data</button>
              <button className="btn primary st-danger-btn" onClick={reset} disabled={resetting}>{resetting ? 'Clearing…' : 'Yes, reset everything'}</button>
            </>
          )}>
          <p>This clears your classes, goals, tasks, activities, reminders and assistant chat. It can't be undone.</p>
          <p className="small muted" style={{ marginTop: 10 }}>Your account, password and settings stay as they are.</p>
        </Modal>
      )}
    </Section>
  );
}

export default function Settings() {
  const { prefs } = useApp();
  if (!prefs) return <PageSkeleton />;
  return (
    <div className="page settings-page">
      <div className="page-head">
        <div>
          <h1>Settings</h1>
          <p>Make MIND MAP fit the way your days actually go.</p>
        </div>
      </div>
      <div className="st-grid">
        <div className="stack st-col">
          <YourDay />
        </div>
        <div className="stack st-col">
          <Appearance />
          <Notifications />
        </div>
        <div className="st-full"><Account /></div>
      </div>
    </div>
  );
}
