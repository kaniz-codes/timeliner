import { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import { BookOpen, Flame, Target, Settings as SettingsIcon, CalendarHeart, GraduationCap, Building2 } from 'lucide-react';
import { api } from '../lib/api.js';
import { useApp, useApi } from '../lib/app.jsx';
import { Field, PageSkeleton } from '../components/ui.jsx';
import { fmtDate } from '../lib/format.js';
import './profile.css';

const YEARS = ['1st year', '2nd year', '3rd year', '4th year', '5th year', "Master's", 'PhD', 'Other'];
const pick = (u) => ({ name: u?.name || '', department: u?.department || '', university: u?.university || '', year: u?.year || '' });

export default function Profile() {
  const { user, loadMe, toast } = useApp();
  const { data: classes } = useApi('/classes');
  const { data: goals } = useApi('/goals');
  const { data: progress } = useApi('/progress');
  const [form, setForm] = useState(() => pick(user));
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState('');

  useEffect(() => { setForm(pick(user)); }, [user]);
  if (!user) return <PageSkeleton />;

  const bind = (k) => ({ value: form[k], onChange: (e) => setForm((f) => ({ ...f, [k]: e.target.value })) });
  const dirty = JSON.stringify(form) !== JSON.stringify(pick(user));
  const years = form.year && !YEARS.includes(form.year) ? [form.year, ...YEARS] : YEARS;

  const save = async (e) => {
    e.preventDefault();
    setError('');
    if (!form.name.trim()) { setError('Your name can’t be empty.'); return; }
    setSaving(true);
    try {
      await api.put('/me', form);
      await loadMe();
      toast('Profile saved.');
    } catch (err) {
      setError(err.message);
    } finally {
      setSaving(false);
    }
  };

  const activeGoals = goals?.goals.filter((g) => g.status === 'active').length;
  const streak = progress?.streak;
  const since = user.created_at ? fmtDate(user.created_at.slice(0, 10), { month: 'long', year: 'numeric' }) : null;
  const line = [user.department, user.university].filter(Boolean).join(' · ');

  return (
    <div className="page profile-page">
      <div className="page-head">
        <div>
          <h1>Profile</h1>
          <p>The basics MIND MAP uses to plan around you.</p>
        </div>
        <div className="page-actions">
          <Link to="/settings" className="btn sm"><SettingsIcon size={15} />Settings</Link>
        </div>
      </div>

      <section className="card pf-hero">
        <div className="pf-avatar" aria-hidden="true">{user.name?.[0]?.toUpperCase()}</div>
        <div className="grow">
          <h2>{user.name}</h2>
          <div className="muted small">{user.email}</div>
          <div className="pf-tags">
            {user.department && <span className="pf-tag"><GraduationCap size={14} />{user.department}</span>}
            {user.university && <span className="pf-tag"><Building2 size={14} />{user.university}</span>}
            {user.year && <span className="pf-tag">{user.year}</span>}
            {!line && !user.year && <span className="small muted">Add your department and university below.</span>}
          </div>
        </div>
        {since && <div className="pf-since"><CalendarHeart size={15} />Member since {since}</div>}
      </section>

      <div className="grid cols-3 pf-stats">
        <Link to="/schedule?view=classes" className="card stat pf-stat class">
          <span className="pf-stat-icon"><BookOpen size={18} /></span>
          <div><div className="value">{classes ? classes.classes.length : '–'}</div><div className="label">weekly classes</div></div>
        </Link>
        <Link to="/goals" className="card stat pf-stat goal">
          <span className="pf-stat-icon"><Target size={18} /></span>
          <div><div className="value">{activeGoals ?? '–'}</div><div className="label">active goals</div></div>
        </Link>
        <Link to="/progress" className="card stat pf-stat streak">
          <span className="pf-stat-icon"><Flame size={18} /></span>
          <div>
            <div className="value">{streak ?? '–'}</div>
            <div className="label">{streak === 0 ? 'day streak · start one today' : `productive day${streak === 1 ? '' : 's'} in a row`}</div>
          </div>
        </Link>
      </div>

      <form className="card pf-form" onSubmit={save}>
        <div className="card-head">
          <div><h2>Your details</h2><span className="sub">Shown on your dashboard and used by the assistant.</span></div>
        </div>
        <div className="form-grid">
          <Field label="Name"><input className="input" autoComplete="name" {...bind('name')} /></Field>
          <Field label="Email" hint="used to sign in"><input className="input" value={user.email} readOnly disabled /></Field>
          <Field label="Department"><input className="input" placeholder="e.g. Computer Science & Engineering" {...bind('department')} /></Field>
          <Field label="University"><input className="input" placeholder="e.g. BUBT" {...bind('university')} /></Field>
          <Field label="Year">
            <select className="select" {...bind('year')}>
              <option value="">Choose…</option>
              {years.map((y) => <option key={y}>{y}</option>)}
            </select>
          </Field>
        </div>
        {error && <div className="form-error" style={{ marginTop: 14 }}>{error}</div>}
        <div className="row pf-actions">
          {dirty && <button type="button" className="btn ghost" onClick={() => setForm(pick(user))}>Discard changes</button>}
          <button type="submit" className="btn primary" disabled={!dirty || saving}>{saving ? 'Saving…' : 'Save profile'}</button>
        </div>
      </form>
    </div>
  );
}
