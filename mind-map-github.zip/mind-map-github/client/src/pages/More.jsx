import { Link } from 'react-router-dom';
import { ChevronRight, LogOut, Moon, Settings, Sun, User, Search } from 'lucide-react';
import { useApp } from '../lib/app.jsx';
import { NAV } from '../components/Layout.jsx';
import './more.css';

const EXTRA = [
  { to: '/search', label: 'Search', icon: Search },
  { to: '/profile', label: 'Profile', icon: User },
  { to: '/settings', label: 'Settings', icon: Settings },
];

function NavList({ items }) {
  return (
    <nav className="card mo-list">
      {items.map((n) => (
        <Link key={n.to} to={n.to} className="mo-item">
          <span className="mo-icon"><n.icon size={18} /></span>
          <span className="grow">{n.label}</span>
          <ChevronRight size={17} className="muted" />
        </Link>
      ))}
    </nav>
  );
}

export default function More() {
  const { user, logout, theme, setTheme } = useApp();
  const detail = [user?.department, user?.university].filter(Boolean).join(' · ') || user?.email;
  return (
    <div className="page more-page">
      <div className="page-head">
        <div>
          <h1>More</h1>
          <p>Everything else in MIND MAP, one tap away.</p>
        </div>
      </div>

      <Link to="/profile" className="card mo-profile">
        <span className="mo-avatar" aria-hidden="true">{user?.name?.[0]?.toUpperCase()}</span>
        <span className="grow" style={{ minWidth: 0 }}>
          <span className="mo-name">{user?.name}</span>
          <span className="mo-detail truncate">{detail}</span>
        </span>
        <span className="small strong mo-view">View profile</span>
        <ChevronRight size={18} className="muted" />
      </Link>

      <h2 className="mo-heading">Sections</h2>
      <NavList items={NAV} />

      <h2 className="mo-heading">You</h2>
      <NavList items={EXTRA} />

      <div className="card mo-list">
        <button className="mo-item" onClick={() => setTheme(theme === 'dark' ? 'light' : 'dark')}>
          <span className="mo-icon">{theme === 'dark' ? <Sun size={18} /> : <Moon size={18} />}</span>
          <span className="grow">{theme === 'dark' ? 'Switch to light mode' : 'Switch to dark mode'}</span>
        </button>
        <button className="mo-item danger" onClick={logout}>
          <span className="mo-icon"><LogOut size={18} /></span>
          <span className="grow">Sign out</span>
        </button>
      </div>
    </div>
  );
}
