// My Schedule: Day / Week / Month views of the timeline, plus the Classes grid.
import { useMemo } from 'react';
import { useSearchParams } from 'react-router-dom';
import { useApp, useApi } from '../lib/app.jsx';
import { Skeleton, Tabs } from '../components/ui.jsx';
import { addDays, fmtDate, fmtDuration, parseDate, startOfWeek, today } from '../lib/format.js';
import Schedule from './Schedule.jsx';
import TodayView from './schedule/DayView.jsx';
import WeekView from './schedule/WeekView.jsx';
import MonthView from './schedule/MonthView.jsx';
import { useMissed, addMonths, Conflicts, DateNav } from './schedule/shared.jsx';
import './timeline.css';

const VIEWS = [
  { value: 'today', label: 'Day' },
  { value: 'week', label: 'Week' },
  { value: 'month', label: 'Month' },
  { value: 'classes', label: 'Classes' },
];

export default function Timeline() {
  const { prefs } = useApp();
  const [params, setParams] = useSearchParams();
  const view = VIEWS.some((v) => v.value === params.get('view')) ? params.get('view') : 'today';
  const date = /^\d{4}-\d{2}-\d{2}$/.test(params.get('date') || '') ? params.get('date') : today();
  const ws = prefs?.week_start ?? 0;
  const go = (v, d) => setParams((p) => {
    const n = new URLSearchParams(p);
    n.set('view', v);
    if (d && d !== today()) n.set('date', d); else n.delete('date');
    return n;
  }, { replace: true });

  const range = useMemo(() => {
    if (view === 'week') { const s = startOfWeek(date, ws); return { from: s, to: addDays(s, 6) }; }
    if (view === 'month') {
      const first = `${date.slice(0, 7)}-01`;
      const s = startOfWeek(first, ws);
      const last = addDays(addMonths(first, 1), -1);
      const e = addDays(startOfWeek(last, ws), 6);
      return { from: s, to: e, first };
    }
    return { from: date, to: date };
  }, [view, date, ws]);

  const { data, error } = useApi(view === 'classes' ? null : `/timeline?from=${range.from}&to=${range.to}`);
  const missed = useMissed();
  const conflictKeys = useMemo(() => new Set((data?.conflicts || []).flatMap((c) => [`${c.a.kind}:${c.a.id}`, `${c.b.kind}:${c.b.id}`])), [data]);
  const openDay = (d) => go('today', d);

  let nav = null;
  if (view === 'today') {
    nav = <DateNav label={fmtDate(date, { weekday: 'short', month: 'short', day: 'numeric' })} onPrev={() => go(view, addDays(date, -1))} onNext={() => go(view, addDays(date, 1))} onToday={() => go(view, today())} isCurrent={date === today()} prevLabel="Previous day" nextLabel="Next day" />;
  } else if (view === 'week') {
    const s = range.from;
    nav = <DateNav label={`${fmtDate(s)} – ${fmtDate(addDays(s, 6), parseDate(s).getMonth() === parseDate(addDays(s, 6)).getMonth() ? { day: 'numeric' } : undefined)}`} onPrev={() => go(view, addDays(s, -7))} onNext={() => go(view, addDays(s, 7))} onToday={() => go(view, today())} isCurrent={s === startOfWeek(today(), ws)} prevLabel="Previous week" nextLabel="Next week" todayLabel="This week" />;
  } else if (view === 'month') {
    nav = <DateNav label={fmtDate(range.first, { month: 'long', year: 'numeric' })} onPrev={() => go(view, addMonths(date, -1))} onNext={() => go(view, addMonths(date, 1))} onToday={() => go(view, today())} isCurrent={date.slice(0, 7) === today().slice(0, 7)} prevLabel="Previous month" nextLabel="Next month" todayLabel="This month" />;
  }

  return (
    <div className="page timeline-page">
      <div className="page-head">
        <div>
          <h1>My Schedule</h1>
          <p>Classes, goal tasks and activities in one place. Dashed gaps are your free time.</p>
        </div>
      </div>

      <div className="tl-toolbar" data-tour="schedule-tabs">
        <Tabs value={view} onChange={(v) => go(v, v === 'classes' ? null : date)} options={VIEWS} />
        {view !== 'classes' && <div className="row wrap tl-toolbar-right" data-tour="schedule-nav">
          {data && view !== 'today' && (
            <span className="pill mood tl-hide-sm">{view === 'week' ? `Week looks ${data.mood.toLowerCase()}` : `${fmtDuration(data.totalMinutes)} planned`}{view === 'week' ? ` · ${fmtDuration(data.totalMinutes)}` : ''}</span>
          )}
          {nav}
        </div>}
      </div>

      {view === 'classes' && <Schedule embedded />}
      {error && <div className="form-error" style={{ marginBottom: 16 }}>{error.message}</div>}
      {view !== 'classes' && (!data ? <Skeleton h={480} /> : (
        <div key={`${view}${range.from}`} className="stack tl-view" style={{ gap: 20 }} data-tour="schedule-view">
          <Conflicts list={data.conflicts.filter((c) => c.date >= today() || view === 'today')} />
          {view === 'today' && <TodayView data={data} date={date} missed={missed} conflictKeys={conflictKeys} />}
          {view === 'week' && <WeekView data={data} date={date} missed={missed} conflictKeys={conflictKeys} onOpenDay={openDay} />}
          {view === 'month' && <MonthView data={data} monthStart={range.first} missed={missed} conflicts={data.conflicts} onOpenDay={openDay} />}
        </div>
      ))}
    </div>
  );
}
