import { useMemo, useState } from 'react';
import { Link } from 'react-router-dom';
import { ImageUp, Plus, Pencil, Trash2, CalendarDays, AlertTriangle } from 'lucide-react';
import { api } from '../lib/api.js';
import { useApp, useApi } from '../lib/app.jsx';
import { EmptyState, PageSkeleton, Tabs, ItemRow, Menu } from '../components/ui.jsx';
import { DAYS, DAYS_SHORT, addDays, fmtDate, fmtDuration, fmtTime, nowDt, startOfWeek, timeOf, toMin, today, weekday } from '../lib/format.js';
import './schedule.css';

const HOUR_PX = 56;
const PX_PER_MIN = HOUR_PX / 60;

// "9:40 – 11:10 AM" when both ends share AM/PM, otherwise "11:20 AM – 12:50 PM".
function compactRange(start, end) {
  const [a, ap] = fmtTime(start).split(' ');
  const [b, bp] = fmtTime(end).split(' ');
  return ap === bp ? `${a} – ${b} ${bp}` : `${a} ${ap} – ${b} ${bp}`;
}

// Narrow columns drop AM/PM: "9:40–11:10".
function TimeText({ start, end }) {
  return (
    <span className="sb-time">
      <span className="t-full">{compactRange(start, end)}</span>
      <span className="t-short">{fmtTime(start).split(' ')[0]}–{fmtTime(end).split(' ')[0]}</span>
    </span>
  );
}

const hourLabel = (h) => `${h % 12 === 0 ? 12 : h % 12}${h < 12 || h === 24 ? 'a' : 'p'}`;
const classMinutes = (c) => toMin(c.end_time) - toMin(c.start_time);
const shortTitle = (t) => (t || '').split(' · ')[0];
const roomText = (r) => (/^room\b/i.test(String(r)) ? String(r) : `Room ${r}`);

// Side-by-side lanes for blocks that overlap in the same day column.
function layoutLanes(blocks) {
  const sorted = [...blocks].sort((x, y) => x.s - y.s || y.e - x.e);
  const out = [];
  let cluster = [];
  let clusterEnd = -1;
  const flush = () => {
    const lanes = [];
    for (const b of cluster) {
      let lane = lanes.findIndex((end) => end <= b.s);
      if (lane === -1) { lane = lanes.length; lanes.push(b.e); } else lanes[lane] = b.e;
      b.lane = lane;
    }
    cluster.forEach((b) => out.push({ ...b, lanes: lanes.length }));
    cluster = [];
  };
  for (const b of sorted) {
    if (cluster.length && b.s >= clusterEnd) flush();
    cluster.push(b);
    clusterEnd = Math.max(clusterEnd, b.e);
  }
  if (cluster.length) flush();
  return out;
}

function useWeek() {
  const t = today();
  const weekStart = startOfWeek(t, 0);
  const dates = DAYS.map((_, i) => addDays(weekStart, i));
  return { t, weekStart, weekEnd: dates[6], dates };
}

function WeeklyGrid({ classes, activities, clashes, dates, t, onClass, onActivity }) {
  const todayIdx = dates.indexOf(t);
  const allBlocks = [
    ...classes.map((c) => ({ type: 'class', day: c.day, s: toMin(c.start_time), e: toMin(c.end_time), c, key: `c${c.id}` })),
    ...activities.map((a) => ({ type: 'activity', day: weekday(a.date), s: toMin(timeOf(a.start)), e: toMin(timeOf(a.end)), a, key: `a${a.id}` })),
  ];
  const minStart = Math.min(7 * 60, ...allBlocks.map((b) => b.s));
  const maxEnd = Math.max(22 * 60, ...allBlocks.map((b) => b.e));
  const startH = Math.floor(minStart / 60);
  const endH = Math.ceil(maxEnd / 60);
  const hours = Array.from({ length: endH - startH }, (_, i) => startH + i);
  const gridStart = startH * 60;
  const height = (endH - startH) * HOUR_PX;
  const nowMin = toMin(nowDt().slice(11, 16));
  const showNow = todayIdx >= 0 && nowMin >= gridStart && nowMin <= endH * 60;

  return (
    <div className="sch-grid" role="grid" aria-label="Weekly class grid" data-tour="classes-grid">
      <div className="sch-row sch-headrow" role="row">
        <div className="sch-corner" />
        {DAYS_SHORT.map((d, i) => (
          <div key={d} role="columnheader" className={`sch-dayhead ${i === todayIdx ? 'today' : ''}`}>
            <span>{d}</span>
            <b>{fmtDate(dates[i], { day: 'numeric' })}</b>
          </div>
        ))}
      </div>
      <div className="sch-row sch-body" style={{ height, '--hour': `${HOUR_PX}px` }}>
        <div className="sch-times" aria-hidden="true">
          {hours.map((h, i) => <span key={h} style={{ top: i * HOUR_PX }}>{hourLabel(h)}</span>)}
        </div>
        {DAYS.map((dayName, i) => {
          const blocks = layoutLanes(allBlocks.filter((b) => b.day === i));
          return (
            <div key={dayName} className={`sch-col ${i === todayIdx ? 'today' : ''}`} role="gridcell" aria-label={dayName}>
              {blocks.map((b) => {
                const style = {
                  top: (b.s - gridStart) * PX_PER_MIN + 1,
                  height: Math.max((b.e - b.s) * PX_PER_MIN - 3, 22),
                  left: `calc(${(b.lane / b.lanes) * 100}% + 3px)`,
                  width: `calc(${100 / b.lanes}% - 6px)`,
                };
                const narrow = b.lanes > 1;
                const tall = b.e - b.s >= 60 && !narrow;
                if (b.type === 'class') {
                  const c = b.c;
                  const clash = clashes.get(`class:${c.id}@${dates[i]}`);
                  return (
                    <button key={b.key} type="button" className={`sch-block class ${clash ? 'clash' : ''} ${narrow ? 'narrow' : tall ? '' : 'short'}`} style={style}
                      onClick={() => onClass(c)} aria-label={`${c.course_code} ${c.title || ''}, ${DAYS[c.day]} ${compactRange(c.start_time, c.end_time)}. Edit or delete`}
                      title={clash ? `Overlaps ${clash}` : undefined}>
                      <span className="sb-code">{c.course_code}{clash && <AlertTriangle size={12} />}</span>
                      {tall && c.title && <span className="sb-title truncate">{c.title}</span>}
                      <TimeText start={c.start_time} end={c.end_time} />
                      {tall && c.room && <span className="sb-room truncate">{roomText(c.room)}</span>}
                      <Pencil size={12} className="sb-edit" aria-hidden="true" />
                    </button>
                  );
                }
                const a = b.a;
                const clash = clashes.get(`activity:${a.id}@${a.date}`);
                return (
                  <button key={b.key} type="button" className={`sch-block activity ${clash ? 'clash' : ''} ${narrow ? 'narrow' : tall ? '' : 'short'}`} style={style}
                    onClick={() => onActivity(a)} aria-label={`${a.title}, ${compactRange(timeOf(a.start), timeOf(a.end))}. Open activity`}
                    title={clash ? `Overlaps ${clash}` : undefined}>
                    <span className="sb-code truncate">{a.title}{clash && <AlertTriangle size={12} />}</span>
                    <TimeText start={timeOf(a.start)} end={timeOf(a.end)} />
                    {tall && a.location && <span className="sb-room truncate">{a.location}</span>}
                  </button>
                );
              })}
              {showNow && i === todayIdx && <div className="sch-now" style={{ top: (nowMin - gridStart) * PX_PER_MIN }} aria-hidden="true" />}
            </div>
          );
        })}
      </div>
    </div>
  );
}

function DayRow({ block, onOpen, right }) {
  return (
    <div className="sch-dayrow" onClick={onOpen} role="button" tabIndex={0} onKeyDown={(e) => e.target === e.currentTarget && (e.key === 'Enter' || e.key === ' ') && (e.preventDefault(), onOpen())}>
      <ItemRow item={block.item} meta={block.meta} right={right} />
    </div>
  );
}

function classBlock(c) {
  return {
    key: `c${c.id}`, s: toMin(c.start_time),
    item: { kind: 'class', id: c.id, title: c.title ? `${c.course_code} · ${c.title}` : c.course_code },
    meta: [compactRange(c.start_time, c.end_time), fmtDuration(classMinutes(c)), c.room && roomText(c.room), c.instructor].filter(Boolean).join(' · '),
  };
}

function activityBlock(a) {
  return {
    key: `a${a.id}`, s: toMin(timeOf(a.start)),
    item: { kind: 'activity', id: a.id, title: a.title },
    meta: [compactRange(timeOf(a.start), timeOf(a.end)), fmtDuration(a.minutes), a.location, a.category].filter(Boolean).join(' · '),
  };
}

// Mobile: pick a day, see that day's classes (and this week's activities) as a list.
function DayPicker({ classes, activities, dates, t, onClass, onActivity }) {
  const todayIdx = dates.indexOf(t);
  const [day, setDay] = useState(todayIdx >= 0 ? todayIdx : 0);
  const rows = [
    ...classes.filter((c) => c.day === day).map((c) => ({ ...classBlock(c), open: () => onClass(c) })),
    ...activities.filter((a) => weekday(a.date) === day).map((a) => ({ ...activityBlock(a), open: () => onActivity(a) })),
  ].sort((x, y) => x.s - y.s);
  return (
    <div className="sch-mobile">
      <div className="sch-daychips" role="tablist" aria-label="Day of the week">
        {DAYS_SHORT.map((d, i) => {
          const n = classes.filter((c) => c.day === i).length;
          return (
            <button key={d} type="button" role="tab" aria-selected={day === i} className={`sch-daychip ${day === i ? 'active' : ''} ${i === todayIdx ? 'today' : ''}`} onClick={() => setDay(i)}>
              <span>{d}</span>
              <b>{fmtDate(dates[i], { day: 'numeric' })}</b>
              <i className={n ? 'has' : ''} aria-label={`${n} classes`} />
            </button>
          );
        })}
      </div>
      <div className="row between sch-dayhead-m">
        <h3>{DAYS[day]}{day === todayIdx && <span className="badge primary">Today</span>}</h3>
        <span className="small muted">{rows.length ? `${rows.length} item${rows.length > 1 ? 's' : ''}` : ''}</span>
      </div>
      {rows.length === 0
        ? <div className="free sch-dayfree">No classes on {DAYS[day]}. A good day for goals.</div>
        : <div className="list">{rows.map((r) => <DayRow key={r.key} block={r} onOpen={r.open} />)}</div>}
    </div>
  );
}

function ListView({ classes, onEdit, onDelete }) {
  return (
    <div className="stack sch-list" style={{ gap: 18 }}>
      {DAYS.map((d, i) => {
        const list = classes.filter((c) => c.day === i);
        if (!list.length) return null;
        const total = list.reduce((s, c) => s + classMinutes(c), 0);
        return (
          <section key={d} className="card sch-listday">
            <div className="card-head">
              <h2>{d}</h2>
              <span className="sub">{list.length} class{list.length > 1 ? 'es' : ''} · {fmtDuration(total)}</span>
            </div>
            <div className="list">
              {list.map((c) => {
                const b = classBlock(c);
                return (
                  <DayRow key={b.key} block={b} onOpen={() => onEdit(c)}
                    right={<Menu label={`Actions for ${c.course_code}`} items={[
                      { label: 'Edit', icon: Pencil, onClick: () => onEdit(c) },
                      { label: 'Delete', icon: Trash2, danger: true, onClick: () => onDelete(c) },
                    ]} />} />
                );
              })}
            </div>
          </section>
        );
      })}
    </div>
  );
}

// `embedded`: shown as the Classes tab of My Schedule (no page header of its own).
export default function Schedule({ embedded = false }) {
  const { openDialog, refresh, toast } = useApp();
  const [view, setView] = useState('grid');
  const { t, weekStart, weekEnd, dates } = useWeek();
  const { data, error } = useApi('/classes');
  const { data: tl } = useApi(`/timeline?from=${weekStart}&to=${weekEnd}`);

  const activities = useMemo(() => (tl?.days || []).flatMap((d) => d.items.filter((i) => i.kind === 'activity' && i.date === d.date)), [tl]);
  // "kind:id@date" → short title of whatever it overlaps.
  const clashes = useMemo(() => {
    const m = new Map();
    for (const c of tl?.conflicts || []) {
      m.set(`${c.a.kind}:${c.a.id}@${c.date}`, `${shortTitle(c.b.title)} by ${fmtDuration(c.overlapMinutes)}`);
      m.set(`${c.b.kind}:${c.b.id}@${c.date}`, `${shortTitle(c.a.title)} by ${fmtDuration(c.overlapMinutes)}`);
    }
    return m;
  }, [tl]);

  if (error) return <div className="page"><div className="form-error">{error.message}</div></div>;
  if (!data) return <PageSkeleton />;

  const classes = data.classes;
  const totalMin = classes.reduce((s, c) => s + classMinutes(c), 0);
  const editClass = (c) => openDialog('class', { initial: c });
  const openActivity = async (a) => {
    try {
      const { activities: all } = await api.get('/activities');
      const full = all.find((x) => x.id === a.id);
      if (full) openDialog('activity', { initial: full });
    } catch (e) {
      toast(e.message, 'error');
    }
  };
  const deleteClass = async (c) => {
    try {
      await api.del(`/classes/${c.id}`);
      refresh();
      toast(`${c.course_code} on ${DAYS[c.day]} removed`, 'info');
    } catch (e) {
      toast(e.message, 'error');
    }
  };

  return (
    <div className={embedded ? 'schedule sch-embedded' : 'page schedule'}>
      <div className={embedded ? 'sch-embed-bar' : 'page-head'}>
        <div>
          {!embedded && <h1>My Schedule</h1>}
        </div>
        <div className="page-actions" data-tour="classes-actions">
          <Link className="btn" to="/schedule/import"><ImageUp size={17} />Import from image</Link>
          <button className="btn primary" onClick={() => openDialog('class')}><Plus size={17} />Add class</button>
        </div>
      </div>

      {classes.length === 0 ? (
        <div className="card">
          <EmptyState cat="wave" icon={CalendarDays} title="No classes yet"
            text="Add your weekly classes once. MIND MAP plans your goals and activities around them."
            action={(
              <div className="row wrap" style={{ justifyContent: 'center', marginTop: 6 }}>
                <button className="btn primary" onClick={() => openDialog('class')}><Plus size={17} />Add class</button>
                <Link className="btn" to="/schedule/import"><ImageUp size={17} />Import from image</Link>
              </div>
            )} />
        </div>
      ) : (
        <>
          <div className="sch-toolbar">
            <Tabs value={view} onChange={setView} options={[{ value: 'grid', label: 'Weekly grid' }, { value: 'list', label: 'List' }]} />
            <div className="sch-legend">
              {view === 'grid' && activities.length > 0 && (
                <>
                  <span className="row small"><span className="dot class" />Classes</span>
                  <span className="row small"><span className="dot activity" />Activities this week</span>
                </>
              )}
              <span className="small muted">{classes.length} weekly class{classes.length === 1 ? '' : 'es'} · {fmtDuration(totalMin)} a week</span>
            </div>
          </div>

          {view === 'grid' ? (
            <>
              <div className="sch-desktop card flat">
                <WeeklyGrid classes={classes} activities={activities} clashes={clashes} dates={dates} t={t} onClass={editClass} onActivity={openActivity} />
              </div>
              <DayPicker classes={classes} activities={activities} dates={dates} t={t} onClass={editClass} onActivity={openActivity} />
              <p className="tiny muted sch-hint"><Pencil size={12} />Click a class to edit or delete it.</p>
            </>
          ) : (
            <ListView classes={classes} onEdit={editClass} onDelete={deleteClass} />
          )}
        </>
      )}
    </div>
  );
}
