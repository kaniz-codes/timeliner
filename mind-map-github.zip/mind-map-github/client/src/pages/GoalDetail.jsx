import { useEffect, useState } from 'react';
import { Link, useNavigate, useParams, useSearchParams } from 'react-router-dom';
import {
  ArrowLeft, Pencil, Trash2, Plus, Sparkles, CalendarDays, GraduationCap, Clock, Sun, PartyPopper, Check,
  CalendarClock, FileEdit, Target, ChevronDown, RefreshCw, ListChecks,
} from 'lucide-react';
import { api } from '../lib/api.js';
import { useApp, useApi } from '../lib/app.jsx';
import { ItemRow, PriorityBadge, ProgressBar, EmptyState, PageSkeleton, Modal, Menu } from '../components/ui.jsx';
import { cap, fmtDate, fmtDuration, fmtSlot } from '../lib/format.js';
import { FeasibilityLine, cheerFor, weeksLeftText } from './Goals.jsx';
import './goals.css';
import Plant, { plantKindFor, stageOf } from '../components/Plant.jsx';
import { useGenerateRoadmap } from './GenerateRoadmap.jsx';
import './goal-detail.css';

const TIME_LABEL = { morning: 'Mornings', afternoon: 'Afternoons', evening: 'Evenings', any: 'Any time' };

function taskMeta(t) {
  const when = t.scheduled_start ? fmtSlot(t.scheduled_start, t.scheduled_end) : 'Not scheduled';
  const due = t.deadline ? `due ${fmtDate(t.deadline)}` : null;
  return [when, fmtDuration(t.estimated_minutes), due].filter(Boolean).join(' · ');
}

function TaskList({ tasks }) {
  const { completeTask, openDialog } = useApp();
  const reschedule = (t) => openDialog('reschedule', { task: t });
  return (
    <div className="list gd-tasks">
      {tasks.map((t) => {
        const missed = t.status === 'missed';
        return (
          <ItemRow key={t.id} item={{ ...t, kind: 'task' }} showTime={false}
            onComplete={completeTask}
            onEdit={(x) => openDialog('task', { initial: tasks.find((y) => y.id === x.id) })}
            onReschedule={missed ? undefined : reschedule}
            meta={<span className={t.scheduled_start ? '' : 'gd-unscheduled'}>{taskMeta(t)}</span>}
            right={missed && <button className="btn sm gd-resched" onClick={() => reschedule(t)}><CalendarClock size={15} />Reschedule</button>} />
        );
      })}
    </div>
  );
}

function Milestone({ m, index, open, onToggle, last }) {
  const done = m.tasks.length > 0 && m.tasks.every((t) => t.status === 'completed');
  const minutes = m.tasks.reduce((s, t) => s + t.estimated_minutes, 0);
  const left = m.tasks.filter((t) => t.status !== 'completed').length;
  return (
    <li className={`gd-step ${done ? 'done' : ''} ${last ? 'last' : ''}`}>
      <div className="gd-node" aria-hidden="true">{done ? <Check size={15} strokeWidth={3} /> : index + 1}</div>
      <section className="card gd-ms">
        <button className="gd-ms-head" onClick={onToggle} aria-expanded={open}>
          <div className="grow">
            <div className="row wrap" style={{ gap: 8 }}>
              <span className="badge goal">Milestone {index + 1}</span>
              {done && <span className="badge done">Done</span>}
            </div>
            <h3 className="gd-ms-title">{m.title}</h3>
            <div className="small muted">
              {m.duration_weeks ? `${m.duration_weeks} week${m.duration_weeks === 1 ? '' : 's'} · ` : ''}{fmtDuration(minutes)}
              {' · '}{done ? 'all tasks done' : `${left} task${left === 1 ? '' : 's'} left`}
            </div>
          </div>
          <span className="gd-ms-pct">{m.progress}%</span>
          <ChevronDown size={18} className={`gd-chev ${open ? 'open' : ''}`} />
        </button>
        <ProgressBar value={m.progress} kind={done ? 'done' : ''} label={`${m.title} progress`} />
        {open && (
          <div className="gd-ms-body">
            {m.description && <p className="small muted" style={{ marginBottom: 12 }}>{m.description}</p>}
            {m.tasks.length ? <TaskList tasks={m.tasks} /> : <p className="small muted">No tasks in this milestone.</p>}
          </div>
        )}
      </section>
    </li>
  );
}

function ConfirmDelete({ goal, onClose, onConfirm }) {
  const [busy, setBusy] = useState(false);
  return (
    <Modal title="Delete this goal?" onClose={onClose} footer={
      <>
        <button className="btn ghost" onClick={onClose}>Keep it</button>
        <button className="btn danger" disabled={busy} onClick={async () => { setBusy(true); await onConfirm(); }}>
          <Trash2 size={16} />{busy ? 'Deleting…' : 'Delete goal'}
        </button>
      </>
    }>
      <p><strong>{goal.title}</strong> and all of its milestones and tasks will be removed from your schedule. This can't be undone.</p>
    </Modal>
  );
}

export default function GoalDetail() {
  const { id } = useParams();
  const navigate = useNavigate();
  const { openDialog, refresh, toast } = useApp();
  const { data, error, reload } = useApi(`/goals/${id}`);
  const [params, setParams] = useSearchParams();
  const [generate, generating] = useGenerateRoadmap({ id: Number(id), title: data?.goal?.title });
  // The Goals list links here with ?generate=1 to start a roadmap straight away.
  useEffect(() => {
    if (params.get('generate') && data) { setParams({}, { replace: true }); generate(); }
  }, [params, data]); // eslint-disable-line react-hooks/exhaustive-deps
  const [openMap, setOpenMap] = useState({});
  const [confirming, setConfirming] = useState(false);
  const [growing, setGrowing] = useState(false);
  useEffect(() => {
    const on = (e) => {
      if (String(e.detail.id) !== String(id)) return;
      setGrowing(true);
      setTimeout(() => setGrowing(false), 700);
    };
    window.addEventListener('mindmap:grow', on);
    return () => window.removeEventListener('mindmap:grow', on);
  }, [id]);

  if (error) {
    return (
      <div className="page">
        <div className="card">
          <EmptyState icon={Target} title="We couldn't find that goal" text={error.status === 404 ? 'It may have been deleted.' : error.message}
            action={<Link className="btn primary sm" to="/goals">Back to goals</Link>} />
        </div>
      </div>
    );
  }
  if (!data) return <PageSkeleton />;

  const { goal, milestones, other_tasks: other } = data;
  const cheer = goal.totalTasks ? cheerFor(goal.progress) : null;
  const firstOpen = milestones.findIndex((m) => m.tasks.some((t) => t.status !== 'completed'));
  const isOpen = (m, i) => openMap[m.id] ?? i === firstOpen;
  const f = goal.feasibility || {};
  const addTask = () => openDialog('task', { initial: { goal_id: goal.id } });
  const missed = [...milestones.flatMap((m) => m.tasks), ...other].filter((t) => t.status === 'missed');

  const remove = async () => {
    try {
      await api.del(`/goals/${goal.id}`);
      navigate('/goals');
      refresh();
      toast('Goal deleted', 'info');
    } catch (e) {
      toast(e.message, 'error');
      setConfirming(false);
    }
  };

  const meta = [
    { icon: CalendarDays, text: goal.deadline ? `Due ${fmtDate(goal.deadline, { month: 'short', day: 'numeric', year: 'numeric' })} · ${weeksLeftText(goal.deadline)}` : 'No deadline' },
    { icon: GraduationCap, text: goal.current_level },
    { icon: Clock, text: `${goal.weekly_hours}h a week` },
    goal.preferred_time && { icon: Sun, text: TIME_LABEL[goal.preferred_time] || cap(goal.preferred_time) },
  ].filter(Boolean);

  return (
    <div className="page goal-detail">
      <Link to="/goals" className="gd-back small strong"><ArrowLeft size={15} />All goals</Link>
      <div className="page-head">
        <div className="gd-head-main">
          <div className="gd-plant">
            <Plant progress={goal.progress} kind={plantKindFor(goal.id)} size={120} grow={growing} label={goal.title} />
            <span className="gd-plant-stage">{stageOf(goal.progress, plantKindFor(goal.id)).name} · {goal.progress}%</span>
          </div>
          <div className="grow">
            <div className="row wrap" style={{ gap: 10 }}>
              <h1>{goal.title}</h1>
              {cheer && <span className="pill gl-cheer gd-cheer"><PartyPopper size={14} />{cheer}</span>}
            </div>
            {goal.description && <p>{goal.description}</p>}
            <div className="gd-meta">
              {meta.map((x) => <span key={x.text}><x.icon size={14} />{x.text}</span>)}
              <PriorityBadge priority={goal.priority} />
              {goal.status !== 'active' && <span className={`badge ${goal.status === 'completed' ? 'done' : ''}`}>{cap(goal.status)}</span>}
            </div>
          </div>
        </div>
        <div className="page-actions">
          <button className="btn" onClick={() => openDialog('goal', { initial: goal, onSaved: () => reload() })}><Pencil size={15} />Edit</button>
          <button className="btn icon danger" onClick={() => setConfirming(true)} aria-label="Delete goal" title="Delete goal"><Trash2 size={17} /></button>
          {goal.has_roadmap && (
            <Menu label="More goal actions" items={[
              { label: 'Plan a new roadmap', icon: RefreshCw, onClick: generate },
              { label: 'Add a custom task', icon: Plus, onClick: addTask },
            ]} />
          )}
        </div>
      </div>

      <div className="gd-top">
        <section className="card gd-stat">
          <div className="small muted">Progress</div>
          {goal.totalTasks ? (
            <>
              <div className="gd-stat-value">{goal.completedTasks}<span> of {goal.totalTasks} tasks</span></div>
              <div className="small muted">{fmtDuration(goal.completedMinutes)} done · {fmtDuration(goal.remainingMinutes)} to go</div>
            </>
          ) : (
            <>
              <div className="gd-stat-value">0<span> tasks yet</span></div>
              <div className="small muted">Progress starts with the first step.</div>
            </>
          )}
        </section>
        <section className="card gd-feas-card">
          <div className="small muted">Will it fit?</div>
          <FeasibilityLine goal={goal} className="gd-feas-line" />
          <div className="gd-feas-facts">
            {f.weeksLeft != null && <span><b>{f.weeksLeft}</b> weeks left</span>}
            {f.capacityMinutes != null && <span><b>{Math.round(f.capacityMinutes / 60)}h</b> of goal time left at {goal.weekly_hours}h a week</span>}
            {f.unplannedMinutes > 0 && <span className="warn"><b>{fmtDuration(f.unplannedMinutes)}</b> not scheduled yet</span>}
          </div>
        </section>
      </div>

      {missed.length > 0 && (
        <div className="gd-missed-note small">
          <CalendarClock size={15} />{missed.length} task{missed.length > 1 ? 's' : ''} didn't get done. No stress, pick a new time below.
        </div>
      )}

      {goal.draft_id && (
        <section className="card gd-draft">
          <FileEdit size={20} />
          <div className="grow"><strong>A draft roadmap is waiting for you</strong><div className="small muted">Nothing is in your schedule until you accept it.</div></div>
          <Link className="btn primary sm" to={`/planner/review/${goal.draft_id}`}>Review draft</Link>
        </section>
      )}

      {!goal.has_roadmap && !goal.draft_id && (
        <section className="card gd-generate">
          <div className="gd-gen-art"><Sparkles size={26} /></div>
          <div className="grow">
            <h2>Turn this goal into a plan</h2>
            <p>The AI planner drafts milestones and weekly tasks. MIND MAP then places each task only in time you're actually free, and you review it before anything lands in your schedule.</p>
          </div>
          <button className="btn primary" onClick={generate}><Sparkles size={16} />Generate AI Roadmap</button>
        </section>
      )}

      {milestones.length > 0 && (
        <>
          <div className="gd-section-head">
            <h2>Roadmap</h2>
            <button className="btn sm soft" onClick={addTask}><Plus size={15} />Add custom task</button>
          </div>
          <ol className="gd-stepper">
            {milestones.map((m, i) => (
              <Milestone key={m.id} m={m} index={i} last={i === milestones.length - 1} open={isOpen(m, i)}
                onToggle={() => setOpenMap((s) => ({ ...s, [m.id]: !isOpen(m, i) }))} />
            ))}
          </ol>
        </>
      )}

      {(other.length > 0 || milestones.length === 0) && (
        <section className="card gd-other">
          <div className="card-head">
            <div><h2>{milestones.length ? 'Other tasks' : 'Tasks'}</h2><span className="sub">Tasks you added yourself</span></div>
            <button className="btn sm soft" onClick={addTask}><Plus size={15} />Add custom task</button>
          </div>
          {other.length ? <TaskList tasks={other} /> : (
            <EmptyState icon={ListChecks} title="No tasks yet" text="Generate a roadmap above, or add your own tasks one at a time." />
          )}
        </section>
      )}

      {confirming && <ConfirmDelete goal={goal} onClose={() => setConfirming(false)} onConfirm={remove} />}
      {generating}
    </div>
  );
}
