import { useEffect, useMemo, useState } from 'react';
import { useNavigate, useSearchParams } from 'react-router-dom';
import { Search as SearchIcon, Target, ListTodo, BookOpen, Tent, X, SearchX, ChevronRight } from 'lucide-react';
import { useApi } from '../lib/app.jsx';
import { ACTIVITY_CATEGORIES, ACTIVITY_STATUSES } from '../components/dialogs.jsx';
import { PriorityBadge, StatusBadge, EmptyState, Skeleton } from '../components/ui.jsx';
import { cap, fmtDate, fmtDayLabel, fmtTime } from '../lib/format.js';
import './search.css';

const TYPES = [
  { value: '', label: 'Everything' },
  { value: 'task', label: 'Tasks', icon: ListTodo },
  { value: 'goal', label: 'Goals', icon: Target },
  { value: 'class', label: 'Courses', icon: BookOpen },
  { value: 'activity', label: 'Activities', icon: Tent },
];
const GROUPS = [
  { type: 'goal', label: 'Goals', icon: Target },
  { type: 'task', label: 'Tasks', icon: ListTodo },
  { type: 'class', label: 'Courses', icon: BookOpen },
  { type: 'activity', label: 'Activities', icon: Tent },
];
const TASK_STATUSES = ['pending', 'in_progress', 'completed', 'missed', 'rescheduled', 'cancelled'];
const GOAL_STATUSES = ['active', 'completed', 'paused'];
const FILTER_KEYS = ['type', 'priority', 'status', 'from', 'to', 'category', 'goal_id'];

function statusOptions(type) {
  if (type === 'task') return TASK_STATUSES;
  if (type === 'goal') return GOAL_STATUSES;
  if (type === 'activity') return ACTIVITY_STATUSES;
  if (type === 'class') return [];
  return [...new Set([...TASK_STATUSES, ...GOAL_STATUSES, ...ACTIVITY_STATUSES])];
}

function Highlight({ text, q }) {
  if (!q) return text;
  const i = text.toLowerCase().indexOf(q.toLowerCase());
  if (i < 0) return text;
  return <>{text.slice(0, i)}<mark>{text.slice(i, i + q.length)}</mark>{text.slice(i + q.length)}</>;
}

function when(r) {
  if (!r.date) return null;
  const label = fmtDayLabel(r.date);
  if (r.type === 'goal') return `Due ${fmtDate(r.date, { month: 'short', day: 'numeric', year: 'numeric' })}`;
  return r.date.length > 10 ? `${label} · ${fmtTime(r.date)}` : label;
}

export default function Search() {
  const navigate = useNavigate();
  const [params, setParams] = useSearchParams();
  const [q, setQ] = useState(params.get('q') || '');
  const f = Object.fromEntries(FILTER_KEYS.map((k) => [k, params.get(k) || '']));
  const { data: goalsData } = useApi('/goals');

  // Keep the input in sync when the top-bar search navigates here with a new query.
  const urlQ = params.get('q') || '';
  useEffect(() => { setQ(urlQ); }, [urlQ]);

  const setParam = (patch) => {
    const next = new URLSearchParams(params);
    for (const [k, v] of Object.entries(patch)) (v ? next.set(k, v) : next.delete(k));
    setParams(next, { replace: true });
  };

  // Debounce typing into the URL; the URL drives the query.
  useEffect(() => {
    if (q === urlQ) return;
    const id = setTimeout(() => setParam({ q }), 250);
    return () => clearTimeout(id);
  });

  const setType = (type) => {
    const patch = { type };
    if (type !== 'activity') patch.category = '';
    if (type !== 'task') patch.goal_id = '';
    if (f.status && !statusOptions(type).includes(f.status)) patch.status = '';
    if (type === 'class') { patch.priority = ''; patch.status = ''; }
    setParam(patch);
  };

  const active = FILTER_KEYS.filter((k) => k !== 'type' && f[k]).length;
  const hasQuery = !!(urlQ.trim() || active || f.type);
  const path = useMemo(() => {
    const sp = new URLSearchParams();
    if (urlQ.trim()) sp.set('q', urlQ.trim());
    for (const k of FILTER_KEYS) if (f[k]) sp.set(k, f[k]);
    return `/search?${sp.toString()}`;
  }, [urlQ, f.type, f.priority, f.status, f.from, f.to, f.category, f.goal_id]);
  const { data, error, loading } = useApi(hasQuery ? path : null, { skip: !hasQuery });

  const results = data?.results || [];
  const grouped = GROUPS.map((g) => ({ ...g, items: results.filter((r) => r.type === g.type) })).filter((g) => g.items.length);

  const go = (r) => {
    const to = { goal: `/goals/${r.id}`, task: r.goal_id ? `/goals/${r.goal_id}` : '/schedule', class: '/schedule?view=classes', activity: '/extracurricular' }[r.type];
    navigate(to);
  };

  const clearFilters = () => setParam(Object.fromEntries(FILTER_KEYS.map((k) => [k, ''])));
  const statuses = statusOptions(f.type);
  const noPriority = f.type === 'class';

  return (
    <div className="page search-page">
      <div className="page-head">
        <div>
          <h1>Search</h1>
          <p>Find any goal, task, course or activity, then narrow it down.</p>
        </div>
      </div>

      <div className="sr-box">
        <SearchIcon size={20} className="muted" />
        <input autoFocus value={q} onChange={(e) => setQ(e.target.value)} placeholder="Search everything…" aria-label="Search"
          onKeyDown={(e) => { if (e.key === 'Enter') setParam({ q }); }} />
        {q && <button className="btn ghost icon sm" aria-label="Clear search" onClick={() => { setQ(''); setParam({ q: '' }); }}><X size={16} /></button>}
      </div>

      <div className="sr-types" role="group" aria-label="Type">
        {TYPES.map((t) => (
          <button key={t.value} className={`chip ${f.type === t.value ? 'active' : ''}`} aria-pressed={f.type === t.value} onClick={() => setType(t.value)}>
            {t.icon && <t.icon size={14} />}{t.label}
          </button>
        ))}
      </div>

      <div className="card flat sr-filters">
        {!noPriority && (
          <label className="sr-filter">
            <span>Priority</span>
            <select className="select sm" value={f.priority} onChange={(e) => setParam({ priority: e.target.value })}>
              <option value="">Any</option>
              <option value="high">High</option><option value="medium">Medium</option><option value="low">Low</option>
            </select>
          </label>
        )}
        {statuses.length > 0 && (
          <label className="sr-filter">
            <span>Status</span>
            <select className="select sm" value={f.status} onChange={(e) => setParam({ status: e.target.value })}>
              <option value="">Any</option>
              {statuses.map((s) => <option key={s} value={s}>{cap(s.replace('_', ' '))}</option>)}
            </select>
          </label>
        )}
        {f.type !== 'goal' && f.type !== 'class' && (
          <>
            <label className="sr-filter">
              <span>From</span>
              <input type="date" className="input sm" value={f.from} max={f.to || undefined} onChange={(e) => setParam({ from: e.target.value })} />
            </label>
            <label className="sr-filter">
              <span>To</span>
              <input type="date" className="input sm" value={f.to} min={f.from || undefined} onChange={(e) => setParam({ to: e.target.value })} />
            </label>
          </>
        )}
        {f.type === 'activity' && (
          <label className="sr-filter">
            <span>Category</span>
            <select className="select sm" value={f.category} onChange={(e) => setParam({ category: e.target.value })}>
              <option value="">Any</option>
              {ACTIVITY_CATEGORIES.map((c) => <option key={c}>{c}</option>)}
            </select>
          </label>
        )}
        {f.type === 'task' && (
          <label className="sr-filter">
            <span>Goal</span>
            <select className="select sm" value={f.goal_id} onChange={(e) => setParam({ goal_id: e.target.value })}>
              <option value="">Any goal</option>
              {goalsData?.goals.map((g) => <option key={g.id} value={g.id}>{g.title}</option>)}
            </select>
          </label>
        )}
        {f.type === 'class' && <span className="small muted sr-hint">Courses match by code, title or instructor.</span>}
        {!f.type && <span className="small muted sr-hint">Pick a type for category and goal filters.</span>}
        {active > 0 && <button className="btn ghost sm sr-clear" onClick={clearFilters}><X size={14} />Clear {active} filter{active > 1 ? 's' : ''}</button>}
      </div>

      {!hasQuery && (
        <div className="card">
          <EmptyState icon={SearchIcon} title="What are you looking for?" text="Type a course code, a task, a goal or an event. Filters work without a search term too." />
        </div>
      )}
      {hasQuery && error && <div className="form-error">{error.message}</div>}
      {hasQuery && !data && !error && <div className="stack"><Skeleton h={120} /><Skeleton h={120} /></div>}
      {hasQuery && data && results.length === 0 && (
        <div className="card">
          <EmptyState icon={SearchX} title={urlQ.trim() ? `Nothing matches “${urlQ.trim()}”` : 'Nothing matches these filters'}
            text="Try a shorter word, or loosen a filter or two."
            action={active > 0 ? <button className="btn sm" onClick={clearFilters}>Clear filters</button> : null} />
        </div>
      )}

      {hasQuery && results.length > 0 && (
        <div className={`stack sr-results ${loading ? 'loading' : ''}`}>
          <p className="small muted">{results.length} result{results.length === 1 ? '' : 's'}{urlQ.trim() ? ` for “${urlQ.trim()}”` : ''}</p>
          {grouped.map((g) => (
            <section key={g.type} className={`card sr-group ${g.type}`}>
              <div className="card-head">
                <h2 className="row"><span className="sr-gicon"><g.icon size={16} /></span>{g.label}</h2>
                <span className="sub">{g.items.length}</span>
              </div>
              <div className="sr-list">
                {g.items.map((r) => (
                  <button key={`${r.type}-${r.id}`} className="sr-row" onClick={() => go(r)}>
                    <span className={`dot ${r.type}`} />
                    <span className="grow sr-main">
                      <span className="sr-title"><Highlight text={r.title} q={urlQ.trim()} /></span>
                      <span className="sr-sub">{[r.subtitle, when(r)].filter(Boolean).join(' · ')}</span>
                    </span>
                    <span className="sr-badges">
                      {r.status && r.status !== 'pending' && <StatusBadge status={r.status} />}
                      <PriorityBadge priority={r.priority} />
                    </span>
                    <ChevronRight size={16} className="muted sr-chev" />
                  </button>
                ))}
              </div>
            </section>
          ))}
        </div>
      )}
    </div>
  );
}
