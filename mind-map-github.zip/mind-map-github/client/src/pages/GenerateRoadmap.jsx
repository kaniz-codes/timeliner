// Generates an AI roadmap for a goal, shows calm progress steps while waiting,
// then opens the review page. This is the AI planner, built into Goals.
import { useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { Sparkles, Check, BookOpen, CalendarSearch, ListTree, CalendarCheck } from 'lucide-react';
import { api } from '../lib/api.js';
import { useApp } from '../lib/app.jsx';
import './generate-roadmap.css';

const STEPS = [
  { label: 'Reading your schedule…', icon: BookOpen },
  { label: 'Finding free time…', icon: CalendarSearch },
  { label: 'Drafting milestones…', icon: ListTree },
  { label: "Placing tasks where you're free…", icon: CalendarCheck },
];

export function PlanningSteps({ goalTitle }) {
  const [step, setStep] = useState(0);
  useEffect(() => {
    const id = setInterval(() => setStep((s) => Math.min(s + 1, STEPS.length - 1)), 3200);
    return () => clearInterval(id);
  }, []);
  return (
    <div className="card pl-loading" role="status" aria-live="polite">
      <div className="pl-loading-art"><Sparkles size={26} /></div>
      <h2>Building your roadmap</h2>
      {goalTitle && <p className="muted">{goalTitle}</p>}
      <ol className="pl-steps">
        {STEPS.map((s, i) => {
          const state = i < step ? 'done' : i === step ? 'active' : 'todo';
          return (
            <li key={s.label} className={state}>
              <span className="pl-step-icon">{state === 'done' ? <Check size={14} strokeWidth={3} /> : state === 'active' ? <span className="spinner" /> : <s.icon size={14} />}</span>
              {s.label}
            </li>
          );
        })}
      </ol>
      <div className="pl-indeterminate"><i /></div>
      <p className="tiny muted">This usually takes 10 to 20 seconds. Nothing is added to your schedule until you accept.</p>
    </div>
  );
}

// Returns [generate(), overlayElement]. Render the overlay anywhere on the page.
export function useGenerateRoadmap(goal) {
  const navigate = useNavigate();
  const { toast } = useApp();
  const [busy, setBusy] = useState(false);
  const generate = async () => {
    setBusy(true);
    try {
      const r = await api.post(`/goals/${goal.id}/roadmap`);
      navigate(`/planner/review/${r.roadmap.id}`);
    } catch (e) {
      toast(e.message, 'error');
      setBusy(false);
    }
  };
  const overlay = busy ? <div className="overlay"><PlanningSteps goalTitle={goal?.title} /></div> : null;
  return [generate, overlay, busy];
}
