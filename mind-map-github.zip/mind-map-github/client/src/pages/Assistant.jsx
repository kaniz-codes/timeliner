import { Fragment, useCallback, useEffect, useRef, useState } from 'react';
import { useSearchParams } from 'react-router-dom';
import { ArrowUp, CalendarClock, Check, MessageCircle, Sparkles, Trash2 } from 'lucide-react';
import { api } from '../lib/api.js';
import { useApp, useApi } from '../lib/app.jsx';
import { PriorityBadge, Skeleton } from '../components/ui.jsx';
import { addDays, fmtDayLabel, fmtDuration, fmtDue, fmtSlot, nowDt, today } from '../lib/format.js';
import './assistant.css';

const SUGGESTIONS = [
  'What should I focus on today?',
  'Do I have free time tomorrow?',
  'Which task is most urgent?',
  'Why is Tuesday so busy?',
  'Can I finish my goal before December?',
  'Move my unfinished task to the next best slot.',
  'Show me my upcoming extracurricular activities.',
  'Reduce my workload on Thursday.',
];

// "8–10 AM", "11:30 AM–5 PM": compact enough for the narrow rail.
function shortRange(start, end) {
  const parts = (dt) => {
    const [h, m] = dt.slice(11, 16).split(':').map(Number);
    return { t: `${h % 12 || 12}${m ? `:${String(m).padStart(2, '0')}` : ''}`, ap: h >= 12 ? 'PM' : 'AM' };
  };
  const a = parts(start);
  const b = parts(end);
  return `${a.t}${a.ap === b.ap ? '' : ` ${a.ap}`}–${b.t} ${b.ap}`;
}

const askAbout = (title) => `I didn't finish ${title}. When should I do it instead?`;

// Replies are plain text; support **bold** and line breaks without pulling in a markdown library.
function RichText({ text }) {
  return String(text).split(/(\*\*[^*]+\*\*)/g).map((part, i) => (
    part.startsWith('**') && part.endsWith('**') ? <strong key={i}>{part.slice(2, -2)}</strong> : <Fragment key={i}>{part}</Fragment>
  ));
}

function Bubble({ msg, isLast, busy, onPick }) {
  const mine = msg.role === 'user';
  const meta = msg.meta || {};
  const options = !mine && isLast && !meta.moved ? meta.options || [] : [];
  return (
    <div className={`as-msg ${mine ? 'mine' : 'theirs'}`}>
      {!mine && <span className="as-avatar" aria-hidden="true"><Sparkles size={15} /></span>}
      <div className="as-body">
        <div className={`as-bubble ${msg.error ? 'error' : ''}`}><RichText text={msg.content} /></div>
        {meta.moved && (
          <div className="as-moved"><Check size={14} />Moved to {fmtSlot(meta.moved.start, meta.moved.end)}</div>
        )}
        {options.length > 0 && (
          <div className="as-options" role="group" aria-label="Suggested times">
            {options.map((o) => (
              <button key={o.id || o.start} className="as-option" disabled={busy} onClick={() => onPick(o, meta.focus_task_id)}>
                <CalendarClock size={14} />{o.label}
              </button>
            ))}
          </div>
        )}
        {!mine && meta.provider === 'rules' && !meta.moved && !msg.greeting && <div className="as-foot">answered offline</div>}
      </div>
    </div>
  );
}

function Typing() {
  return (
    <div className="as-msg theirs" aria-live="polite">
      <span className="as-avatar" aria-hidden="true"><Sparkles size={15} /></span>
      <div className="as-bubble as-typing" aria-label="Assistant is thinking"><i /><i /><i /></div>
    </div>
  );
}

function FreeRail() {
  const from = today();
  const { data } = useApi(`/free?from=${from}&to=${addDays(from, 6)}`);
  const now = nowDt();
  return (
    <section className="card as-rail-card">
      <div className="card-head"><h3>Free time this week</h3><span className="tiny muted">real gaps only</span></div>
      {!data && <Skeleton h={120} />}
      {data && (
        <div className="as-free-days">
          {Object.entries(data.free).map(([date, slots]) => {
            const open = slots.filter((s) => s.end > now);
            const total = open.reduce((n, s) => n + s.minutes, 0);
            return (
              <div key={date} className="as-free-day">
                <div className="row between">
                  <span className="strong small">{fmtDayLabel(date)}</span>
                  <span className={`tiny ${total ? 'as-free-total' : 'muted'}`}>{total ? fmtDuration(total) : 'Fully booked'}</span>
                </div>
                {open.length > 0 && (
                  <div className="as-free-slots">
                    {open.slice(0, 3).map((s) => <span key={s.start} className="as-free-slot">{shortRange(s.start, s.end)}</span>)}
                    {open.length > 3 && <span className="tiny muted">+{open.length - 3}</span>}
                  </div>
                )}
              </div>
            );
          })}
        </div>
      )}
    </section>
  );
}

function MissedRail({ onAsk, busy }) {
  const { data } = useApi('/tasks?status=missed');
  const tasks = data?.tasks || [];
  return (
    <section className="card as-rail-card">
      <div className="card-head"><h3>Needs a new time</h3>{tasks.length > 0 && <span className="badge deadline">{tasks.length}</span>}</div>
      {!data && <Skeleton h={80} />}
      {data && tasks.length === 0 && <p className="small muted">Nothing waiting. Every task has a time.</p>}
      <div className="stack tight">
        {tasks.map((t) => (
          <div key={t.id} className="as-missed">
            <div className="grow">
              <div className="strong small">{t.title}</div>
              <div className="tiny muted">{fmtDuration(t.estimated_minutes)} · {fmtDue(t.deadline)}</div>
            </div>
            <div className="row" style={{ gap: 6, justifyContent: 'space-between' }}>
              <PriorityBadge priority={t.priority} />
              <button className="btn xs soft" disabled={busy} onClick={() => onAsk(t)}><MessageCircle size={13} />Ask about this</button>
            </div>
          </div>
        ))}
      </div>
    </section>
  );
}

export default function Assistant() {
  const { user, refresh, toast } = useApp();
  const [params, setParams] = useSearchParams();
  const [messages, setMessages] = useState(null);
  const [text, setText] = useState('');
  const [sending, setSending] = useState(false);
  const scroller = useRef(null);
  const input = useRef(null);
  const started = useRef(false);
  const first = user?.name?.split(' ')[0] || 'there';

  const send = useCallback(async (message, extra = {}) => {
    const body = String(message || '').trim();
    if (!body) return;
    setMessages((m) => [...(m || []), { id: `u${Date.now()}`, role: 'user', content: body }]);
    setSending(true);
    try {
      const r = await api.post('/assistant/chat', { message: body, ...extra });
      setMessages((m) => [...m, {
        id: `a${Date.now()}`, role: 'assistant', content: r.reply,
        meta: { focus_task_id: r.focus_task_id, options: r.options, moved: r.moved, provider: r.provider },
      }]);
      if (r.moved) refresh();
    } catch (e) {
      setMessages((m) => [...m, { id: `e${Date.now()}`, role: 'assistant', error: true, content: `Sorry, I couldn't answer that just now (${e.message}). Give it another try in a moment.` }]);
    } finally {
      setSending(false);
      requestAnimationFrame(() => input.current?.focus({ preventScroll: true }));
    }
  }, [refresh]);

  // Load history once, then handle ?task= / ?q= deep links a single time.
  useEffect(() => {
    if (started.current) return;
    started.current = true;
    const taskId = params.get('task');
    const q = params.get('q');
    api.get('/assistant/messages')
      .then((r) => setMessages(r.messages))
      .catch(() => setMessages([]))
      .then(async () => {
        if (taskId || q) setParams({}, { replace: true });
        if (taskId) {
          try {
            const { task } = await api.get(`/tasks/${taskId}`);
            if (task) send(askAbout(task.title), { focus_task_id: task.id });
          } catch { toast("I couldn't find that task. It may have been removed.", 'error'); }
        } else if (q) {
          send(q);
        }
      });
  }, [params, setParams, send, toast]);

  useEffect(() => {
    const el = scroller.current;
    if (el) el.scrollTo({ top: el.scrollHeight, behavior: messages?.length > 1 ? 'smooth' : 'auto' });
  }, [messages, sending]);

  // Grow the composer with its content, up to a few lines.
  useEffect(() => {
    const el = input.current;
    if (!el) return;
    el.style.height = 'auto';
    el.style.height = `${Math.min(el.scrollHeight, 140)}px`;
  }, [text]);

  const submit = (e) => {
    e?.preventDefault();
    if (sending || !text.trim()) return;
    const t = text;
    setText('');
    send(t);
  };

  const pick = (o, focusId) => send(`Move it to ${o.label}`, { focus_task_id: focusId, slot: { start: o.start, end: o.end } });
  const askTask = (t) => send(askAbout(t.title), { focus_task_id: t.id });

  const clear = async () => {
    try {
      await api.del('/assistant/messages');
      setMessages([]);
      toast('Chat cleared. Fresh start.', 'info');
    } catch (e) { toast(e.message, 'error'); }
  };

  const greeting = {
    id: 'greeting', role: 'assistant', greeting: true,
    content: `Hi ${first}. I can see your classes, your goals and where your free time actually is. Ask me what to focus on, when you're free, or where a task should go.`,
  };
  const list = messages ? [greeting, ...messages] : [];
  const lastAssistant = [...list].reverse().find((m) => m.role === 'assistant');
  const empty = messages && messages.length === 0;

  return (
    <div className="page assistant-page">
      <div className="page-head">
        <div>
          <h1>AI Assistant</h1>
          <p>It reads your real schedule. It will not invent free time that is not there.</p>
        </div>
        <div className="page-actions">
          <button className="btn sm" onClick={clear} disabled={!messages?.length || sending}><Trash2 size={15} />Clear chat</button>
        </div>
      </div>

      <div className="as-layout">
        <section className="card as-chat" aria-label="Conversation">
          <div className="as-scroll" ref={scroller}>
            {!messages && <div className="stack"><Skeleton h={60} w="70%" /><Skeleton h={44} w="45%" style={{ alignSelf: 'flex-end' }} /></div>}
            {list.map((m) => (
              <Bubble key={m.id} msg={m} isLast={m === lastAssistant && !sending} busy={sending} onPick={pick} />
            ))}
            {empty && (
              <div className="as-starters">
                <span className="tiny muted strong">Try asking</span>
                <div className="as-chips wrap" data-tour="ai-chips">
                  {SUGGESTIONS.map((s) => <button key={s} className="chip" onClick={() => send(s)}>{s}</button>)}
                </div>
              </div>
            )}
            {sending && <Typing />}
          </div>

          <div className="as-bottom">
            {!empty && (
              <div className="as-chips" data-tour="ai-chips" aria-label="Suggestions"
                onWheel={(e) => { if (Math.abs(e.deltaY) > Math.abs(e.deltaX)) e.currentTarget.scrollLeft += e.deltaY; }}>
                {SUGGESTIONS.map((s) => <button key={s} className="chip" disabled={sending} onClick={() => send(s)}>{s}</button>)}
              </div>
            )}
            <form className={`as-composer ${sending ? 'busy' : ''}`} onSubmit={submit} data-tour="ai-composer">
              <textarea ref={input} rows={1} value={text} placeholder="Ask about your week…"
                aria-label="Message the assistant" disabled={sending}
                onChange={(e) => setText(e.target.value)}
                onKeyDown={(e) => { if (e.key === 'Enter' && !e.shiftKey && !e.nativeEvent.isComposing) submit(e); }} />
              <button type="submit" className="as-send" disabled={sending || !text.trim()} aria-label="Send message">
                <ArrowUp size={18} />
              </button>
            </form>
          </div>
        </section>

        <aside className="as-rail" aria-label="Your week at a glance" data-tour="ai-rail">
          <MissedRail onAsk={askTask} busy={sending} />
          <FreeRail />
        </aside>
      </div>
    </div>
  );
}

