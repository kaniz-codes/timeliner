import { AlertTriangle, Flag } from 'lucide-react';
import { useApp } from '../../lib/app.jsx';
import { DAYS_SHORT, fmtDate, parseDate, today } from '../../lib/format.js';
import { LEVELS, levelClass, plural, missedOn, MissedCard } from './shared.jsx';

export default function MonthView({ data, monthStart, missed, conflicts, onOpenDay }) {
  const month = parseDate(monthStart).getMonth();
  const clashDays = new Set(conflicts.map((c) => c.date));
  const { prefs } = useApp();
  const ws = prefs?.week_start ?? 0;
  const heads = Array.from({ length: 7 }, (_, k) => DAYS_SHORT[(ws + k) % 7]);
  return (
    <>
      <section className="card tl-month">
        <div className="mo-grid mo-heads">{heads.map((h) => <span key={h}>{h}</span>)}</div>
        <div className="mo-grid">
          {data.days.map((d) => {
            const inMonth = parseDate(d.date).getMonth() === month;
            const count = (k) => d.items.filter((i) => i.kind === k).length;
            const m = missedOn(missed, d.date).length;
            const due = d.deadlines.filter((x) => x.status !== 'completed').length;
            const kinds = [['class', count('class'), 'class', 'classes'], ['task', count('task') + m, 'task', 'tasks'], ['activity', count('activity'), 'activity', 'activities']];
            const label = [fmtDate(d.date, { weekday: 'long', month: 'long', day: 'numeric' }), d.load?.level, ...kinds.filter((k) => k[1]).map((k) => plural(k[1], k[2], k[3])), due ? `${due} due` : null, clashDays.has(d.date) ? 'has a conflict' : null].filter(Boolean).join(', ');
            return (
              <button key={d.date} className={`mo-cell ${inMonth ? '' : 'out'} ${d.date === today() ? 'today' : ''} ${d.date < today() ? 'past' : ''} ${levelClass(d.load?.level)}`} onClick={() => onOpenDay(d.date)} aria-label={label}>
                <span className="mo-top">
                  <span className="mo-num">{parseDate(d.date).getDate()}</span>
                  {clashDays.has(d.date) && <AlertTriangle size={13} className="mo-clash" aria-hidden="true" />}
                </span>
                <span className="mo-kinds">
                  {kinds.filter((k) => k[1]).map(([k, n]) => <span key={k} className="mo-kind"><i className={`dot ${k}`} />{n}</span>)}
                </span>
                {[...d.items.filter((i) => i.kind !== 'class'), ...missedOn(missed, d.date)].slice(0, 2).map((i) => (
                  <span key={`${i.kind}${i.id}`} className={`mo-title ${i.kind} ${i.status === 'completed' ? 'done' : ''} ${i.status === 'missed' ? 'missed' : ''}`}>{i.title}</span>
                ))}
                {due > 0 && <span className="mo-due"><Flag size={11} />{due} due</span>}
              </button>
            );
          })}
        </div>
        <div className="mo-legend">
          <span><i className="dot class" />Classes</span>
          <span><i className="dot task" />Goal tasks</span>
          <span><i className="dot activity" />Activities</span>
          <span><Flag size={12} color="var(--deadline)" />Deadlines</span>
          <span className="mo-heat">Load {LEVELS.map((l) => <i key={l} className={levelClass(l)} title={l} />)}</span>
        </div>
      </section>
      <MissedCard missed={missed} />
    </>
  );
}

/* ------------------------------------------------------------------ */
/* Agenda view: next 14 days, sticky day headers                       */
/* ------------------------------------------------------------------ */
