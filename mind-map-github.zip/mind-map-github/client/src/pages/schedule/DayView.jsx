import { Sparkles } from 'lucide-react';
import { fmtDate, fmtDayLabel, fmtDuration, fmtRange, today } from '../../lib/format.js';
import { levelClass, missedOn, DayAgenda, MissedCard } from './shared.jsx';

export default function TodayView({ data, date, missed, conflictKeys }) {
  const day = data.days[0];
  const dayMissed = missedOn(missed, date);
  const freeMin = day.free.reduce((s, f) => s + f.minutes, 0);
  const tasks = [...day.items.filter((i) => i.kind === 'task'), ...dayMissed];
  const done = tasks.filter((t) => t.status === 'completed').length;
  const longest = [...day.free].sort((x, y) => y.minutes - x.minutes)[0];
  return (
    <div className="grid main-side">
      <section className="card">
        <div className="card-head">
          <div>
            <h2>{['Today', 'Tomorrow', 'Yesterday'].includes(fmtDayLabel(date)) ? fmtDayLabel(date) : fmtDate(date, { weekday: 'long' })}</h2>
            <span className="sub">{fmtDate(date, { month: 'long', day: 'numeric', year: date.slice(0, 4) === today().slice(0, 4) ? undefined : 'numeric' })}{day.load ? ` · ${fmtDuration(day.load.minutes) || 'nothing'} planned` : ''}</span>
          </div>
          {day.load && <span className={`badge tl-level ${levelClass(day.load.level)}`}>{day.load.level}</span>}
        </div>
        <DayAgenda day={day} missed={dayMissed} conflictKeys={conflictKeys} />
      </section>
      <div className="stack" style={{ gap: 20 }}>
        <section className="card tl-glance">
          <div className="card-head"><h2>At a glance</h2></div>
          <div className="tl-glance-grid">
            <div className="class"><b>{day.load?.classes ?? 0}</b><span>{day.load?.classes === 1 ? 'class' : 'classes'}</span></div>
            <div className="goal"><b>{tasks.length}</b><span>{tasks.length === 1 ? 'task' : 'tasks'} · {done} done</span></div>
            <div className="activity"><b>{day.load?.activities ?? 0}</b><span>{day.load?.activities === 1 ? 'activity' : 'activities'}</span></div>
            <div className="free-stat"><b>{fmtDuration(freeMin) || '0m'}</b><span>free {date === today() ? 'left today' : ''}</span></div>
          </div>
          {longest && (
            <p className="small muted" style={{ marginTop: 12 }}>
              <Sparkles size={13} className="tl-inline-icon" />Longest free: <strong className="tl-free-text">{fmtRange(longest.start, longest.end)}</strong>
            </p>
          )}
        </section>
        <MissedCard missed={missed} />
      </div>
    </div>
  );
}

/* ------------------------------------------------------------------ */
/* Week view: time grid (desktop) / day picker + list (mobile)         */
/* ------------------------------------------------------------------ */
