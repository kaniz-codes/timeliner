// Pieces shared by the My Schedule views: missed tasks, conflicts, the day agenda, date navigation.
import { useMemo, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { AlertTriangle, Bell, CalendarClock, ChevronLeft, ChevronRight, Flag, Leaf, MessageCircle, Plus, XCircle } from 'lucide-react';
import { api } from '../../lib/api.js';
import { useApp, useApi } from '../../lib/app.jsx';
import { EmptyState, ItemRow, Menu, PriorityBadge } from '../../components/ui.jsx';
import { fmtDate, fmtDayLabel, fmtDue, fmtDuration, fmtRange, fmtTime, nowDt, parseDate, toDateStr, today } from '../../lib/format.js';

export const LEVELS = ['Free', 'Light', 'Medium', 'Busy', 'Very Busy'];
export const levelClass = (level) => `lvl-${String(level || 'Free').replace(' ', '').toLowerCase()}`;
export const plural = (n, word, many = `${word}s`) => `${n} ${n === 1 ? word : many}`;

// Missed tasks are not part of the timeline's busy blocks, so fetch them once and merge by day.
export function useMissed() {
  const { data } = useApi('/tasks?status=missed');
  return data?.tasks || [];
}

export function missedAsBlock(t) {
  return {
    kind: 'task', id: t.id, date: t.scheduled_start.slice(0, 10), title: t.title, start: t.scheduled_start,
    end: t.scheduled_end || t.scheduled_start, minutes: t.estimated_minutes, status: 'missed', priority: t.priority,
    goal_id: t.goal_id, goal_title: t.goal_title, deadline: t.deadline, estimated_minutes: t.estimated_minutes,
  };
}

export function missedOn(missed, date) {
  return missed.filter((t) => t.scheduled_start?.slice(0, 10) === date).map(missedAsBlock);
}

export function addMonths(date, n) {
  const d = parseDate(date);
  return toDateStr(new Date(d.getFullYear(), d.getMonth() + n, 1));
}

function itemMeta(i) {
  return [
    fmtRange(i.start, i.end),
    fmtDuration(i.minutes),
    i.kind === 'class' ? (i.room ? `Room ${i.room}` : null) : i.goal_title || i.location || i.category,
  ].filter(Boolean).join(' · ');
}

const conflictDay = (d) => {
  const rel = fmtDayLabel(d);
  const full = fmtDate(d, { weekday: 'short', month: 'short', day: 'numeric' });
  return rel === 'Today' || rel === 'Tomorrow' ? `${rel}, ${fmtDate(d)}` : full;
};

const askAiAbout = (conflict) => `${conflict.a.title} overlaps ${conflict.b.title} on ${fmtDayLabel(conflict.date)}. What should I do?`;

/* ------------------------------------------------------------------ */
/* Conflict card                                                       */
/* ------------------------------------------------------------------ */

export function ConflictCard({ conflict }) {
  const navigate = useNavigate();
  const { openDialog, refresh, toast } = useApp();
  const [leaving, setLeaving] = useState(false);
  const { a, b } = conflict;
  const activity = [a, b].find((x) => x.kind === 'activity');
  const task = [a, b].find((x) => x.kind === 'task');

  const editActivity = async () => {
    try {
      const { activities } = await api.get('/activities');
      const act = activities.find((x) => x.id === activity.id);
      if (act) openDialog('activity', { initial: act });
    } catch (e) {
      toast(e.message, 'error');
    }
  };
  const changeTime = () => (activity ? editActivity() : openDialog('reschedule', { task: { id: task.id, title: task.title } }));
  const ignore = async () => {
    setLeaving(true);
    try {
      await api.post('/conflicts/ignore', { key: conflict.key });
      setTimeout(refresh, 200);
      toast('Okay, we won\'t flag that one again', 'info');
    } catch (e) {
      setLeaving(false);
      toast(e.message, 'error');
    }
  };

  return (
    <div className={`conflict tl-conflict ${leaving ? 'leaving' : ''}`} role="alert">
      <div className="row between wrap">
        <div className="row"><AlertTriangle size={18} color="var(--danger)" /><strong>Schedule conflict · {conflictDay(conflict.date)}</strong></div>
        <span className="badge danger">Overlap {fmtDuration(conflict.overlapMinutes)}</span>
      </div>
      <div className="tl-conflict-pair">
        {[a, b].map((x) => (
          <div key={`${x.kind}${x.id}`} className={`tl-conflict-item ${x.kind}`}>
            <span className="strong truncate">{x.title}</span>
            <span className="muted small">{fmtRange(x.start, x.end)}</span>
          </div>
        ))}
      </div>
      <div className="row wrap">
        {(activity || task) && <button className="btn sm" onClick={changeTime}><CalendarClock size={15} />Change {activity ? 'activity' : 'task'} time</button>}
        {activity && <button className="btn sm ghost" onClick={() => navigate('/extracurricular')}>Edit activity</button>}
        <button className="btn sm ghost" onClick={() => navigate(`/assistant?q=${encodeURIComponent(askAiAbout(conflict))}`)}><MessageCircle size={15} />Ask AI Assistant</button>
        <button className="btn sm ghost" onClick={ignore}>Ignore</button>
      </div>
    </div>
  );
}

export function Conflicts({ list, max = 3 }) {
  const [all, setAll] = useState(false);
  if (!list?.length) return null;
  const shown = all ? list : list.slice(0, max);
  return (
    <div className="stack tl-conflicts">
      {shown.map((c) => <ConflictCard key={c.key} conflict={c} />)}
      {list.length > shown.length && (
        <button className="btn sm ghost tl-more" onClick={() => setAll(true)}>Show {list.length - shown.length} more conflict{list.length - shown.length > 1 ? 's' : ''}</button>
      )}
    </div>
  );
}

/* ------------------------------------------------------------------ */
/* Day agenda: time-ordered list with free time inline                 */
/* ------------------------------------------------------------------ */

const ORDER = { deadline: 0, reminder: 1, item: 2, now: 3, free: 4 };

export function DayAgenda({ day, missed = [], conflictKeys, emptyTitle }) {
  const { completeTask, openDialog, refresh, toast } = useApp();
  const now = nowDt();
  const isToday = day.date === today();

  const rows = useMemo(() => {
    const list = [
      ...day.items.map((i) => ({ type: 'item', at: i.start, item: i })),
      ...missed.map((i) => ({ type: 'item', at: i.start, item: i })),
      ...day.free.map((f) => ({ type: 'free', at: f.start, item: f })),
      ...day.deadlines.map((d) => ({ type: 'deadline', at: d.deadline.length > 10 ? d.deadline : `${day.date}T00:00`, item: d })),
      ...(day.reminders || []).map((r) => ({ type: 'reminder', at: r.reminder_time, item: r })),
    ];
    if (isToday && list.some((r) => r.type === 'item' || r.type === 'free')) list.push({ type: 'now', at: now });
    return list.sort((x, y) => x.at.localeCompare(y.at) || ORDER[x.type] - ORDER[y.type]);
  }, [day, missed, isToday, now]);

  const didntFinish = async (t) => {
    try {
      await api.post(`/tasks/${t.id}/missed`);
      refresh();
      openDialog('reschedule', { task: { ...t, status: 'missed' } });
    } catch (e) {
      toast(e.message, 'error');
    }
  };

  const hasContent = rows.some((r) => r.type !== 'now');
  if (!hasContent) {
    return <EmptyState cat="happy" icon={Leaf} title={emptyTitle || (isToday ? 'Your schedule is clear today.' : 'Nothing planned for this day.')} text="Enjoy it, or get ahead on a goal."
      action={<button className="btn sm soft" onClick={() => openDialog('task', { initial: { when: 'pick', date: day.date, time: '18:00' } })}><Plus size={15} />Plan a task</button>} />;
  }

  return (
    <div className="tl-line">
      {rows.map((r) => {
        const key = `${r.type}-${r.item?.kind || ''}-${r.item?.id || ''}-${r.at}`;
        if (r.type === 'now') {
          return (
            <div key="now" className="tl-row tl-now" aria-label={`Now, ${fmtTime(now)}`}>
              <span className="tl-time">{fmtTime(now)}</span>
              <span className="tl-dot now" />
              <div className="tl-now-line"><span>Now</span></div>
            </div>
          );
        }
        if (r.type === 'free') {
          const f = r.item;
          const past = f.end < now;
          return (
            <div key={key} className={`tl-row ${past ? 'past' : ''}`}>
              <span className="tl-time">{fmtTime(f.start)}</span>
              <span className="tl-dot free-dot" />
              <div className="free tl-free grow">
                <Leaf size={15} color="var(--done)" />
                <span><strong>Free · {fmtDuration(f.minutes)}</strong><span className="tl-free-range">{fmtRange(f.start, f.end)}</span></span>
                <button className="btn xs ghost tl-plan" onClick={() => openDialog('task', { initial: { when: 'pick', date: day.date, time: f.start.slice(11, 16), estimated_minutes: Math.min(f.minutes, 60) } })} aria-label={`Plan a task at ${fmtTime(f.start)}`}>
                  <Plus size={13} />Plan
                </button>
              </div>
            </div>
          );
        }
        if (r.type === 'deadline') {
          const d = r.item;
          const done = d.status === 'completed';
          return (
            <div key={key} className="tl-row">
              <span className="tl-time">{d.deadline.length > 10 ? fmtTime(d.deadline) : 'Due'}</span>
              <span className="tl-dot deadline" />
              <div className={`tl-marker deadline ${done ? 'done' : ''}`}>
                <Flag size={15} />
                <span className="grow truncate"><span className="strong">{d.title}</span>{d.status === 'missed' && <span className="muted"> · not done yet</span>}</span>
                {done ? <span className="badge done">Done</span> : <PriorityBadge priority={d.priority} />}
              </div>
            </div>
          );
        }
        if (r.type === 'reminder') {
          const rem = r.item;
          return (
            <div key={key} className={`tl-row ${rem.reminder_time < now ? 'past' : ''}`}>
              <span className="tl-time">{fmtTime(rem.reminder_time)}</span>
              <span className="tl-dot reminder" />
              <div className="tl-marker reminder">
                <Bell size={14} />
                <span className="grow truncate">{rem.title}</span>
                {rem.offset_label && <span className="tiny muted tl-hide-sm">{rem.offset_label}</span>}
              </div>
            </div>
          );
        }
        const i = r.item;
        const missedRow = i.status === 'missed';
        const done = i.status === 'completed';
        const past = i.end < now && !missedRow && !(i.kind === 'task' && !done);
        const started = i.start <= now;
        const inConflict = conflictKeys?.has(`${i.kind}:${i.id}`);
        let right = null;
        if (i.kind === 'task' && missedRow) {
          right = <button className="btn xs soft" onClick={() => openDialog('reschedule', { task: i })}><CalendarClock size={14} />Reschedule</button>;
        } else if (i.kind === 'task' && !done) {
          right = (
            <Menu label={`More actions for ${i.title}`} items={[
              { label: 'Reschedule', icon: CalendarClock, onClick: () => openDialog('reschedule', { task: i }) },
              ...(started || day.date < today() ? [{ label: "Didn't finish", icon: XCircle, onClick: () => didntFinish(i) }] : []),
            ]} />
          );
        }
        return (
          <div key={key} className={`tl-row ${past ? 'past' : ''} ${inConflict ? 'clash' : ''}`}>
            <span className="tl-time">{fmtTime(i.start)}</span>
            <span className={`tl-dot ${i.kind} ${done ? 'done' : ''} ${missedRow ? 'missed' : ''}`} />
            <div className="grow">
              <ItemRow item={i} onComplete={i.kind === 'task' ? completeTask : undefined} onReschedule={missedRow ? undefined : (t) => openDialog('reschedule', { task: t })}
                meta={itemMeta(i)} right={right} />
            </div>
          </div>
        );
      })}
    </div>
  );
}

/* ------------------------------------------------------------------ */
/* Missed tasks card                                                   */
/* ------------------------------------------------------------------ */

export function MissedCard({ missed }) {
  const { openDialog } = useApp();
  const navigate = useNavigate();
  const [all, setAll] = useState(false);
  if (!missed.length) return null;
  const shown = all ? missed : missed.slice(0, 3);
  return (
    <section className="card tl-missed">
      <div className="card-head">
        <div>
          <h2>Waiting for a new time</h2>
          <span className="sub">No stress. Give each one a free slot.</span>
        </div>
        <span className="badge danger">{missed.length} missed</span>
      </div>
      <div className="list">
        {shown.map((t) => (
          <div key={t.id} className="tl-missed-row">
            <div className="grow">
              <div className="item-title">{t.title}</div>
              <div className="item-meta">{fmtDuration(t.estimated_minutes)} · {fmtDue(t.deadline)}{t.scheduled_start ? ` · was ${fmtDate(t.scheduled_start, { weekday: 'short', month: 'short', day: 'numeric' })}` : ''}</div>
            </div>
            <div className="row tl-missed-actions" style={{ gap: 6 }}>
              {t.priority === 'high' && <PriorityBadge priority="high" />}
              <button className="btn xs ghost icon" onClick={() => navigate(`/assistant?task=${t.id}`)} aria-label={`Ask AI about ${t.title}`} title="Ask AI"><MessageCircle size={14} /></button>
              <button className="btn xs soft" onClick={() => openDialog('reschedule', { task: t })}><CalendarClock size={14} />Reschedule</button>
            </div>
          </div>
        ))}
      </div>
      {missed.length > 3 && !all && <button className="btn sm ghost tl-more" onClick={() => setAll(true)}>Show all {missed.length}</button>}
    </section>
  );
}

/* ------------------------------------------------------------------ */
/* Date navigation                                                     */
/* ------------------------------------------------------------------ */

export function DateNav({ label, onPrev, onNext, onToday, isCurrent, prevLabel = 'Previous', nextLabel = 'Next', todayLabel = 'Today' }) {
  return (
    <div className="tl-nav">
      <button className="btn sm icon" onClick={onPrev} aria-label={prevLabel}><ChevronLeft size={17} /></button>
      <span className="tl-nav-label">{label}</span>
      <button className="btn sm icon" onClick={onNext} aria-label={nextLabel}><ChevronRight size={17} /></button>
      <button className="btn sm ghost" onClick={onToday} disabled={isCurrent}>{todayLabel}</button>
    </div>
  );
}

/* ------------------------------------------------------------------ */
/* Today view                                                          */
/* ------------------------------------------------------------------ */
