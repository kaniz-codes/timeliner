import { useState } from 'react';
import { api } from '../../lib/api.js';
import { useApp } from '../../lib/app.jsx';
import { DAYS_SHORT, fmtDate, fmtDayLabel, fmtDuration, fmtRange, fmtTime, nowDt, parseDate, toMin, today, weekday, addMinutesDt, minutesBetween } from '../../lib/format.js';
import { play } from '../../lib/sound.js';
import { levelClass, missedOn, DayAgenda, MissedCard } from './shared.jsx';

const PPM = 0.9; // px per minute in the week grid

export default function WeekView({ data, date, missed, conflictKeys, onOpenDay }) {
  const { prefs, refresh, toast } = useApp();
  const [picked, setPicked] = useState(null);
  // Drag and drop: `drag` is the task being moved, `ghost` where it would land.
  const [drag, setDrag] = useState(null);
  const [ghost, setGhost] = useState(null);
  const now = nowDt();
  const days = data.days.map((d) => ({ ...d, missedBlocks: missedOn(missed, d.date) }));
  const all = days.flatMap((d) => [...d.items, ...d.missedBlocks]);
  const startH = Math.floor(Math.min(toMin(prefs?.day_start || '08:00'), ...all.map((i) => toMin(i.start.slice(11, 16)))) / 60);
  const endH = Math.ceil(Math.max(toMin(prefs?.day_end || '22:00'), ...all.map((i) => toMin(i.end.slice(11, 16)))) / 60);
  const gridStart = startH * 60;
  const hours = Array.from({ length: endH - startH }, (_, k) => startH + k);
  const height = (endH - startH) * 60 * PPM;
  const pos = (s, e) => {
    const top = (toMin(s.slice(11, 16)) - gridStart) * PPM;
    return { top, height: Math.max(20, (toMin(e.slice(11, 16)) - toMin(s.slice(11, 16))) * PPM - 2) };
  };
  const selected = picked || (days.some((d) => d.date === date) ? date : days[0].date);
  const selDay = days.find((d) => d.date === selected);
  const nowMin = toMin(now.slice(11, 16));

  const landing = (e, day) => {
    const rect = e.currentTarget.getBoundingClientRect();
    const raw = gridStart + (e.clientY - rect.top) / PPM - drag.grab;
    const startMin = Math.max(gridStart, Math.min(endH * 60 - drag.minutes, Math.round(raw / 15) * 15));
    const start = `${day.date}T${String(Math.floor(startMin / 60)).padStart(2, '0')}:${String(startMin % 60).padStart(2, '0')}`;
    const end = addMinutesDt(start, drag.minutes);
    const clash = [...day.items].some((b) => !(b.kind === 'task' && b.id === drag.id) && b.status !== 'completed' && b.start < end && b.end > start);
    return { date: day.date, start, end, clash, past: start < now };
  };
  const drop = async (e, day) => {
    e.preventDefault();
    const spot = landing(e, day);
    const moving = drag;
    setDrag(null);
    setGhost(null);
    if (spot.past) return toast("That time has already passed. Drop it later in the week.", 'info');
    if (spot.start === moving.start) return;
    try {
      await api.post(`/tasks/${moving.id}/move`, { start: spot.start, end: spot.end });
      play('whoosh');
      refresh();
      toast(`Moved to ${fmtDayLabel(spot.start)} ${fmtTime(spot.start)}`, 'success', 5000, {
        label: 'Undo',
        onClick: async () => { await api.post(`/tasks/${moving.id}/move`, { start: moving.start, end: moving.end }).catch(() => {}); refresh(); },
      });
    } catch (err) {
      toast(err.message, 'error');
    }
  };

  return (
    <>
      <section className="card tl-week" aria-label="Week grid">
        <span className="wk-hint">Tip: drag a task to a free gap to move it.</span>
        <div className="wk-head">
          <span />
          {days.map((d) => (
            <button key={d.date} className={`wk-dayhead ${d.date === today() ? 'today' : ''}`} onClick={() => onOpenDay(d.date)} aria-label={`Open ${fmtDate(d.date, { weekday: 'long', month: 'long', day: 'numeric' })}`}>
              <span className="wk-dow">{DAYS_SHORT[weekday(d.date)]}</span>
              <span className="wk-num">{parseDate(d.date).getDate()}</span>
              <span className={`wk-lvl ${levelClass(d.load?.level)}`}>{d.load?.level}</span>
            </button>
          ))}
        </div>
        <div className="wk-body" style={{ height }}>
          <div className="wk-times">
            {hours.map((h) => <span key={h} style={{ top: (h * 60 - gridStart) * PPM }}>{fmtTime(`${String(h).padStart(2, '0')}:00`).replace(':00', '')}</span>)}
          </div>
          {days.map((d) => (
            <div key={d.date} className={`wk-col ${d.date === today() ? 'today' : ''} ${d.date < today() ? 'past' : ''} ${drag ? 'dropzone' : ''}`} style={{ backgroundSize: `100% ${60 * PPM}px` }}
              onDragOver={drag ? (e) => { e.preventDefault(); setGhost(landing(e, d)); } : undefined}
              onDrop={drag ? (e) => drop(e, d) : undefined}>
              {ghost?.date === d.date && (
                <div className={`wk-ghost ${ghost.clash || ghost.past ? 'bad' : ''}`} style={pos(ghost.start, ghost.end)}>
                  {fmtTime(ghost.start)}{ghost.clash ? ' · busy' : ghost.past ? ' · past' : ''}
                </div>
              )}
              {d.free.map((f) => {
                const p = pos(f.start, f.end);
                return (
                  <div key={`f${f.start}`} className="wk-free" style={{ top: p.top + 1, height: p.height }} title={`Free ${fmtRange(f.start, f.end)} · ${fmtDuration(f.minutes)}`}>
                    {p.height >= 34 && <span>Free · {fmtDuration(f.minutes)}</span>}
                  </div>
                );
              })}
              {[...d.items, ...d.missedBlocks].map((i) => {
                const p = pos(i.start, i.end);
                const clash = conflictKeys.has(`${i.kind}:${i.id}`);
                return (
                  <button key={`${i.kind}${i.id}${i.start}`} onClick={() => onOpenDay(d.date)}
                    draggable={i.kind === 'task' && i.status !== 'completed' && i.status !== 'missed'}
                    onDragStart={(e) => {
                      e.dataTransfer.effectAllowed = 'move';
                      e.dataTransfer.setData('text/plain', String(i.id));
                      setDrag({ id: i.id, start: i.start, end: i.end, minutes: minutesBetween(i.start, i.end), grab: e.nativeEvent.offsetY / PPM });
                    }}
                    onDragEnd={() => { setDrag(null); setGhost(null); }}
                    className={`wk-block ${i.kind} ${drag?.id === i.id && i.kind === 'task' ? 'dragging' : ''} ${i.status === 'completed' ? 'done' : ''} ${i.status === 'missed' ? 'missed' : ''} ${clash ? 'clash' : ''} ${i.end < now ? 'past' : ''}`}
                    style={{ top: p.top + 1, height: p.height }} title={`${i.title} · ${fmtRange(i.start, i.end)}${i.status === 'missed' ? ' · missed' : ''}`}>
                    <span className="wk-title">{i.title.split(' · ')[0]}</span>
                    {p.height >= 40 && <span className="wk-when">{fmtRange(i.start, i.end)}</span>}
                  </button>
                );
              })}
              {d.date === today() && nowMin >= gridStart && nowMin <= endH * 60 && <div className="wk-now" style={{ top: (nowMin - gridStart) * PPM }} aria-hidden="true" />}
            </div>
          ))}
        </div>
      </section>

      {/* Mobile: horizontal day picker + list */}
      <section className="tl-week-mobile">
        <div className="wk-picker" role="tablist" aria-label="Pick a day">
          {days.map((d) => (
            <button key={d.date} role="tab" aria-selected={d.date === selected} className={`${d.date === selected ? 'active' : ''} ${d.date === today() ? 'today' : ''}`} onClick={() => setPicked(d.date)}>
              <span>{DAYS_SHORT[weekday(d.date)].slice(0, 2)}</span>
              <b>{parseDate(d.date).getDate()}</b>
              <i className={levelClass(d.load?.level)} aria-hidden="true" />
            </button>
          ))}
        </div>
        <div className="card">
          <div className="card-head">
            <div><h2>{fmtDayLabel(selected)}</h2><span className="sub">{fmtDate(selected, { weekday: 'long', month: 'short', day: 'numeric' })}</span></div>
            <span className={`badge tl-level ${levelClass(selDay.load?.level)}`}>{selDay.load?.level}</span>
          </div>
          <DayAgenda day={selDay} missed={selDay.missedBlocks} conflictKeys={conflictKeys} />
        </div>
      </section>
      <MissedCard missed={missed} />
    </>
  );
}

/* ------------------------------------------------------------------ */
/* Month view                                                          */
/* ------------------------------------------------------------------ */
