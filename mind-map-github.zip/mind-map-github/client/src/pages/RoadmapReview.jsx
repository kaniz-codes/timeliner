import { useEffect, useRef, useState } from 'react';
import { Link, useNavigate, useParams } from 'react-router-dom';
import {
  Sparkles, RefreshCw, Check, Plus, Minus, Trash2, Clock, CalendarDays, CalendarCheck, AlertTriangle, ExternalLink,
  ChevronDown, LayoutTemplate, Pencil, Target, ArrowRight, BookOpen, Save,
} from 'lucide-react';
import { api } from '../lib/api.js';
import { useApp } from '../lib/app.jsx';
import { PriorityBadge, EmptyState, PageSkeleton, Modal } from '../components/ui.jsx';
import { cap, fmtDate, fmtDuration, fmtTime, today } from '../lib/format.js';
import { PlanningSteps } from './GenerateRoadmap.jsx';
import './roadmap-review.css';

let keySeq = 0;
const nk = () => `k${++keySeq}`;
const withKeys = (milestones) => milestones.map((m) => ({ ...m, _key: nk(), tasks: m.tasks.map((t) => ({ ...t, _key: nk() })) }));

// Keep what the student typed; take only what the server computed (placement, dates).
function mergeServer(local, server) {
  const same = local.length === server.length && local.every((m, i) => m.tasks.length === server[i].tasks.length);
  if (!same) return withKeys(server);
  return local.map((m, i) => ({
    ...m,
    tasks: m.tasks.map((t, j) => {
      const s = server[i].tasks[j];
      return { ...t, _new: false, estimated_minutes: s.estimated_minutes, scheduled_start: s.scheduled_start, scheduled_end: s.scheduled_end, suggested_deadline: s.suggested_deadline, unplaced: !!s.unplaced };
    }),
  }));
}

const toPayload = (ms) => ms.map((m) => ({
  title: m.title.trim() || 'Milestone',
  description: m.description || '',
  duration_weeks: m.duration_weeks,
  tasks: m.tasks.map((t) => ({
    title: t.title.trim() || 'Untitled task',
    description: t.description || '',
    estimated_minutes: t.estimated_minutes,
    difficulty: t.difficulty,
    priority: t.priority,
    resources: t.resources || [],
    deadline: t.deadline || null,
  })),
}));

const plural = (n, w) => `${n} ${w}${n === 1 ? '' : 's'}`;
const fmtWeeks = (w) => { const n = Math.round((Number(w) || 1) * 10) / 10; return `${n} week${n === 1 ? '' : 's'}`; };

function DeadlinePicker({ task, goalDeadline, onChange, readOnly }) {
  const ref = useRef(null);
  const [fallback, setFallback] = useState(false);
  const due = task.deadline || task.suggested_deadline;
  const label = `${task.deadline ? 'due' : 'aim for'} ${due ? fmtDate(due) : 'no date'}`;
  if (readOnly) return <span className="rr-meta-item"><CalendarDays size={13} />{label}</span>;
  if (fallback) {
    return (
      <input type="date" className="input sm rr-date-visible" value={due || ''} min={today()} max={goalDeadline || undefined} aria-label="Deadline"
        autoFocus onBlur={() => setFallback(false)} onChange={(e) => onChange({ deadline: e.target.value || null })} />
    );
  }
  const open = () => {
    try { ref.current.showPicker(); } catch { setFallback(true); }
  };
  return (
    <span className="rr-date">
      <button type="button" className={`rr-chipbtn ${task.deadline ? 'set' : ''}`} onClick={open} aria-label={`Change deadline, currently ${label}`}>
        <CalendarDays size={13} />{label}
      </button>
      <input ref={ref} type="date" className="rr-date-input" tabIndex={-1} aria-hidden="true" value={due || ''} min={today()} max={goalDeadline || undefined}
        onChange={(e) => onChange({ deadline: e.target.value || null })} />
    </span>
  );
}

function Duration({ minutes, onChange, readOnly }) {
  if (readOnly) return <span className="rr-meta-item"><Clock size={13} />{fmtDuration(minutes)}</span>;
  return (
    <span className="rr-dur" role="group" aria-label={`Duration ${fmtDuration(minutes)}`}>
      <button type="button" onClick={() => onChange(Math.max(15, minutes - 15))} disabled={minutes <= 15} aria-label="15 minutes shorter"><Minus size={12} /></button>
      <span className="rr-dur-val"><Clock size={13} />{fmtDuration(minutes)}</span>
      <button type="button" onClick={() => onChange(Math.min(480, minutes + 15))} disabled={minutes >= 480} aria-label="15 minutes longer"><Plus size={12} /></button>
    </span>
  );
}

function PrioritySelect({ value, onChange, readOnly }) {
  if (readOnly) return <PriorityBadge priority={value} />;
  return (
    <label className={`rr-prio ${value}`} title="Change priority">
      <PriorityBadge priority={value} />
      <ChevronDown size={13} className="rr-prio-chev" />
      <select value={value} onChange={(e) => onChange(e.target.value)} aria-label="Priority">
        <option value="high">High</option><option value="medium">Medium</option><option value="low">Low</option>
      </select>
    </label>
  );
}

function TaskRow({ t, readOnly, leaving, goalDeadline, onChange, onDelete }) {
  const resources = (t.resources || []).map((r) => (typeof r === 'string' ? { title: r } : r)).filter((r) => r.title || r.url);
  return (
    <div className={`rr-task ${t.unplaced ? 'unplaced' : ''} ${leaving ? 'leaving' : ''}`}>
      <div className="grow">
        {readOnly ? <div className="rr-task-title">{t.title}</div> : (
          <input className="rr-task-title rr-inline" value={t.title} aria-label="Task title" autoFocus={!!t._new}
            onFocus={t._new ? (e) => e.target.select() : undefined}
            onChange={(e) => onChange({ title: e.target.value })}
            onKeyDown={(e) => e.key === 'Enter' && e.currentTarget.blur()}
            onBlur={(e) => !e.target.value.trim() && onChange({ title: 'Untitled task' })} />
        )}
        {t.description && <div className="rr-task-desc">{t.description}</div>}
        <div className="rr-task-meta">
          <Duration minutes={t.estimated_minutes} readOnly={readOnly} onChange={(v) => onChange({ estimated_minutes: v })} />
          <DeadlinePicker task={t} goalDeadline={goalDeadline} readOnly={readOnly} onChange={onChange} />
          {t.scheduled_start && (
            <span className="rr-meta-item rr-planned"><CalendarCheck size={13} />planned {fmtDate(t.scheduled_start, { weekday: 'short', month: 'short', day: 'numeric' })} · {fmtTime(t.scheduled_start)}</span>
          )}
          {t.difficulty && <span className="rr-meta-item muted">{cap(t.difficulty)}</span>}
        </div>
        {t.unplaced && (
          <div className="rr-unplaced"><AlertTriangle size={14} />Couldn't fit before the deadline. Try a shorter duration, or drop a lower-priority task.</div>
        )}
        {resources.length > 0 && (
          <div className="rr-res">
            {resources.map((r, i) => (r.url
              ? <a key={i} className="rr-res-chip" href={r.url} target="_blank" rel="noreferrer"><ExternalLink size={12} />{r.title || r.url.replace(/^https?:\/\//, '').split('/')[0]}</a>
              : <span key={i} className="rr-res-chip plain"><BookOpen size={12} />{r.title}</span>))}
          </div>
        )}
      </div>
      <div className="rr-task-side">
        <PrioritySelect value={t.priority || 'medium'} readOnly={readOnly} onChange={(v) => onChange({ priority: v })} />
        {!readOnly && <button type="button" className="btn ghost icon sm rr-del" onClick={onDelete} aria-label={`Delete ${t.title || 'task'}`} title="Delete task"><Trash2 size={16} /></button>}
      </div>
    </div>
  );
}

function MilestoneCard({ m, index, readOnly, leavingKeys, goalDeadline, onRename, onTask, onDelete, onAdd }) {
  const total = m.tasks.reduce((s, t) => s + t.estimated_minutes, 0);
  return (
    <section className="card rr-ms">
      <div className="rr-ms-head">
        <span className="badge goal">Milestone {index + 1}</span>
        {readOnly ? <h2 className="rr-ms-title grow">{m.title}</h2> : (
          <input className="rr-ms-title rr-inline grow" value={m.title} aria-label={`Milestone ${index + 1} name`}
            onChange={(e) => onRename(e.target.value)} onKeyDown={(e) => e.key === 'Enter' && e.currentTarget.blur()}
            onBlur={(e) => !e.target.value.trim() && onRename(`Milestone ${index + 1}`)} />
        )}
        <span className="rr-ms-meta">{fmtWeeks(m.duration_weeks)} · {fmtDuration(total)}</span>
      </div>
      {m.description && <p className="rr-ms-desc">{m.description}</p>}
      <div className="rr-tasks">
        {m.tasks.map((t) => (
          <TaskRow key={t._key} t={t} readOnly={readOnly} leaving={leavingKeys.has(t._key)} goalDeadline={goalDeadline}
            onChange={(patch) => onTask(t._key, patch)} onDelete={() => onDelete(t._key)} />
        ))}
        {m.tasks.length === 0 && <p className="small muted rr-ms-empty">No tasks left. This milestone will be dropped when the plan updates.</p>}
      </div>
      {!readOnly && <button type="button" className="btn sm ghost rr-add" onClick={onAdd}><Plus size={15} />Add task</button>}
    </section>
  );
}

function SaveStatus({ state }) {
  if (state === 'saving') return <span className="rr-status"><span className="spinner" />Updating plan…</span>;
  if (state === 'dirty') return <span className="rr-status">Unsaved changes</span>;
  if (state === 'error') return <span className="rr-status err">Couldn't update. Try again.</span>;
  return <span className="rr-status ok"><Check size={14} />Plan is up to date</span>;
}

function Review({ rid }) {
  const { toast, refresh } = useApp();
  const navigate = useNavigate();
  const [load, setLoad] = useState({ data: null, error: null });
  const [ms, setMs] = useState([]);
  const [meta, setMeta] = useState(null);
  const [saveState, setSaveState] = useState('saved');
  const [leavingKeys, setLeavingKeys] = useState(() => new Set());
  const [busy, setBusy] = useState(null); // 'accept' | 'regen'
  const [confirmRegen, setConfirmRegen] = useState(false);
  const msRef = useRef([]);
  const rev = useRef(0);
  const savedRev = useRef(0);
  const timer = useRef(null);
  const closed = useRef(false);

  useEffect(() => {
    let alive = true;
    api.get(`/goals/roadmaps/${rid}`).then((d) => {
      if (!alive) return;
      const keyed = withKeys(d.roadmap.milestones || []);
      msRef.current = keyed;
      setMs(keyed);
      setMeta(d.roadmap);
      setLoad({ data: d, error: null });
    }).catch((error) => alive && setLoad({ data: null, error }));
    return () => { alive = false; };
  }, [rid]);

  // Flush unsaved edits if the student leaves the page mid-edit.
  useEffect(() => () => {
    clearTimeout(timer.current);
    if (!closed.current && rev.current !== savedRev.current) {
      api.put(`/goals/roadmaps/${rid}`, { milestones: toPayload(msRef.current) }).catch(() => {});
    }
  }, [rid]);

  const save = async () => {
    clearTimeout(timer.current);
    if (closed.current) return;
    const sent = rev.current;
    setSaveState('saving');
    try {
      const r = await api.put(`/goals/roadmaps/${rid}`, { milestones: toPayload(msRef.current) });
      if (closed.current || rev.current !== sent) return; // newer edits are on their way
      savedRev.current = sent;
      const merged = mergeServer(msRef.current, r.roadmap.milestones);
      msRef.current = merged;
      setMs(merged);
      setMeta(r.roadmap);
      setSaveState('saved');
    } catch (e) {
      if (closed.current) return;
      if (rev.current === sent) setSaveState('error');
      toast(e.message, 'error');
    }
  };

  const update = (fn) => {
    const next = fn(msRef.current);
    msRef.current = next;
    setMs(next);
    rev.current += 1;
    setSaveState('dirty');
    clearTimeout(timer.current);
    timer.current = setTimeout(save, 800);
  };

  if (load.error) {
    return (
      <div className="page">
        <div className="card">
          <EmptyState icon={Sparkles} title="We couldn't find that roadmap" text={load.error.status === 404 ? 'It may have been replaced by a newer draft.' : load.error.message}
            action={<Link className="btn primary sm" to="/goals">Back to goals</Link>} />
        </div>
      </div>
    );
  }
  if (!load.data || !meta) return <PageSkeleton />;

  const goal = load.data.goal;
  const readOnly = meta.status !== 'draft';
  const allTasks = ms.flatMap((m) => m.tasks);
  const totalMinutes = allTasks.reduce((s, t) => s + t.estimated_minutes, 0);
  const unplaced = allTasks.filter((t) => t.unplaced).length;
  const liveMilestones = ms.filter((m) => m.tasks.length).length;
  const stats = meta.stats || {};
  const fromTemplate = meta.source === 'fallback';

  const renameMs = (key, title) => update((list) => list.map((m) => (m._key === key ? { ...m, title } : m)));
  const patchTask = (mKey, tKey, patch) => update((list) => list.map((m) => (m._key !== mKey ? m : { ...m, tasks: m.tasks.map((t) => (t._key === tKey ? { ...t, ...patch } : t)) })));
  const addTask = (mKey) => update((list) => list.map((m) => (m._key !== mKey ? m : {
    ...m, tasks: [...m.tasks, { _key: nk(), _new: true, title: 'New task', description: '', estimated_minutes: 60, difficulty: 'moderate', priority: 'medium', resources: [], deadline: null }],
  })));
  const deleteTask = (mKey, tKey) => {
    setLeavingKeys((s) => new Set(s).add(tKey));
    setTimeout(() => {
      update((list) => list.map((m) => (m._key !== mKey ? m : { ...m, tasks: m.tasks.filter((t) => t._key !== tKey) })));
      setLeavingKeys((s) => { const n = new Set(s); n.delete(tKey); return n; });
    }, 200);
  };

  const accept = async () => {
    clearTimeout(timer.current);
    setBusy('accept');
    try {
      const r = await api.post(`/goals/roadmaps/${rid}/accept`, { milestones: toPayload(msRef.current) });
      closed.current = true;
      toast(`${plural(r.placed, 'task')} added to your schedule${r.unplaced ? ` · ${r.unplaced} could not fit` : ''}`, r.unplaced ? 'info' : 'success', 4500);
      refresh();
      navigate(`/goals/${meta.goal_id}`);
    } catch (e) {
      toast(e.message, 'error');
      setBusy(null);
    }
  };

  const regenerate = async () => {
    setConfirmRegen(false);
    clearTimeout(timer.current);
    setBusy('regen');
    try {
      const r = await api.post(`/goals/${meta.goal_id}/roadmap`);
      closed.current = true;
      refresh();
      toast('Here is a fresh draft', 'info');
      navigate(`/planner/review/${r.roadmap.id}`, { replace: true });
    } catch (e) {
      toast(e.message, 'error', 5000);
      setBusy(null);
    }
  };

  return (
    <div className="page roadmap-review">
      <div className="page-head">
        <div>
          <Link to={`/goals/${goal.id}`} className="rr-goal-link small strong"><Target size={14} />{goal.title}</Link>
          <h1>Review your roadmap</h1>
          <p className="keep">{readOnly ? 'This roadmap is no longer a draft.' : 'Built by the planner · nothing is in your schedule yet. Change what you like, then accept.'}</p>
        </div>
        {!readOnly && (
          <div className="page-actions rr-actions">
            <button className="btn" onClick={() => (rev.current > 0 ? setConfirmRegen(true) : regenerate())} disabled={!!busy}><RefreshCw size={15} />Regenerate</button>
            <button className="btn primary" onClick={accept} disabled={!!busy || allTasks.length === 0}><Check size={16} />{busy === 'accept' ? 'Adding…' : 'Accept roadmap'}</button>
          </div>
        )}
      </div>

      {readOnly && (
        <div className="card rr-notice">
          <CalendarCheck size={20} />
          <div className="grow">
            <strong>{meta.status === 'accepted' ? 'This roadmap is already in your schedule.' : 'A newer draft replaced this one.'}</strong>
            <div className="small muted">{meta.status === 'accepted' ? 'Track progress and move tasks from the goal page.' : 'Open the goal to review the latest draft.'}</div>
          </div>
          <Link className="btn primary sm" to={`/goals/${goal.id}`}>Open goal<ArrowRight size={15} /></Link>
        </div>
      )}

      <div className="grid cols-4 rr-stats">
        <div className="card stat"><div className="value">{liveMilestones}</div><div className="label">milestones</div></div>
        <div className="card stat"><div className="value">{allTasks.length}</div><div className="label">tasks</div></div>
        <div className="card stat"><div className="value">{fmtDuration(totalMinutes)}</div><div className="label">total work</div></div>
        <div className="card stat"><div className="value">{fmtDuration(stats.weeklyMinutes || goal.weekly_hours * 60)}</div><div className="label">a week available</div></div>
      </div>

      <section className="card rr-summary">
        <div className="rr-summary-icon"><Sparkles size={18} /></div>
        <div className="grow">
          <p>{meta.summary}</p>
          <div className="rr-summary-foot">
            <span className="tiny muted rr-source">{fromTemplate ? <LayoutTemplate size={12} /> : <Sparkles size={12} />}{fromTemplate ? 'Built from a template' : 'Drafted by AI'} · dates placed by MIND MAP in your real free time</span>
            {stats.finishDate && <span className="badge done">Finishes around {fmtDate(stats.finishDate)}</span>}
            {goal.deadline && <span className="badge">Deadline {fmtDate(goal.deadline, { month: 'short', day: 'numeric', year: 'numeric' })}</span>}
            {unplaced > 0 && <span className="badge deadline"><AlertTriangle size={12} />{unplaced} couldn't fit</span>}
          </div>
        </div>
      </section>

      {!readOnly && (
        <div className="rr-editbar">
          <Pencil size={15} />
          <span className="grow small">Click a title, duration, date or priority to change it. The plan re-checks your free time as you go.</span>
          <SaveStatus state={saveState} />
          <button className="btn sm" onClick={save} disabled={saveState === 'saved' || saveState === 'saving'}><Save size={14} />Update plan</button>
        </div>
      )}

      <div className="rr-list">
        {ms.map((m, i) => (
          <MilestoneCard key={m._key} m={m} index={i} readOnly={readOnly} leavingKeys={leavingKeys} goalDeadline={goal.deadline}
            onRename={(title) => renameMs(m._key, title)}
            onTask={(tKey, patch) => patchTask(m._key, tKey, patch)}
            onDelete={(tKey) => deleteTask(m._key, tKey)}
            onAdd={() => addTask(m._key)} />
        ))}
      </div>

      {!readOnly && (
        <section className="card rr-final">
          <div className="grow">
            <h3>Looks good?</h3>
            <p className="small muted">
              Accepting adds {plural(allTasks.length - unplaced, 'task')} to your schedule at the planned times
              {unplaced > 0 ? `, and keeps ${unplaced} unscheduled for you to place later` : ''}. You can still move any of them.
            </p>
          </div>
          <button className="btn primary" onClick={accept} disabled={!!busy || allTasks.length === 0}><Check size={16} />{busy === 'accept' ? 'Adding…' : 'Accept roadmap'}</button>
        </section>
      )}

      {confirmRegen && (
        <Modal title="Start over with a fresh draft?" onClose={() => setConfirmRegen(false)} footer={
          <>
            <button className="btn ghost" onClick={() => setConfirmRegen(false)}>Keep editing</button>
            <button className="btn primary" onClick={regenerate}><RefreshCw size={15} />Regenerate</button>
          </>
        }>
          <p>The planner will build a new roadmap from scratch. Your edits to this draft won't carry over.</p>
        </Modal>
      )}
      {busy === 'regen' && <div className="overlay"><PlanningSteps goalTitle={goal.title} /></div>}
    </div>
  );
}

export default function RoadmapReview() {
  const { rid } = useParams();
  return <Review key={rid} rid={rid} />;
}
