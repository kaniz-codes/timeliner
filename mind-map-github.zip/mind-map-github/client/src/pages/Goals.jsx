import { useState } from 'react';
import { Link } from 'react-router-dom';
import { Plus, Target, CheckCircle2, AlertTriangle, ArrowRight, Sparkles, FileEdit, PartyPopper, Compass } from 'lucide-react';
import { useApp, useApi } from '../lib/app.jsx';
import { PriorityBadge, ProgressBar, EmptyState, PageSkeleton, Tabs } from '../components/ui.jsx';
import { fmtDate, fmtDayLabel, fmtTime, fmtDuration, daysBetween, today } from '../lib/format.js';
import Plant, { plantKindFor, stageOf } from '../components/Plant.jsx';
import './goals.css';

// Helpers shared with GoalDetail / Planner (same page family).
export function weeksLeftText(deadline) {
  if (!deadline) return 'No deadline';
  const d = daysBetween(today(), deadline);
  if (d < 0) return 'Past the deadline';
  if (d === 0) return 'Due today';
  if (d < 14) return `${d} day${d === 1 ? '' : 's'} left`;
  return `${Math.round(d / 7)} weeks left`;
}

// Turns the backend's feasibility numbers into one plain sentence.
export function feasibilityOf(goal) {
  const f = goal.feasibility || {};
  if (goal.status === 'completed' || (goal.totalTasks > 0 && goal.progress >= 100)) return { tone: 'ok', text: 'Goal complete. Well done.' };
  if (!goal.totalTasks) return { tone: 'idle', text: 'No plan yet. Generate a roadmap to see how it fits your week.' };
  if (f.feasible) {
    return { tone: 'ok', text: f.projectedFinish ? `On track to finish around ${fmtDate(f.projectedFinish)}` : 'On track for your deadline' };
  }
  const capacity = f.capacityMinutes ?? Infinity;
  const free = f.freeMinutes ?? Infinity;
  const short = (f.remainingMinutes || 0) - Math.min(capacity, free);
  if (short > 0) {
    const what = capacity <= free ? 'your weekly budget allows' : 'your free time allows';
    return { tone: 'risk', text: `At risk: needs ${fmtDuration(Math.round(short / 15) * 15)} more than ${what}` };
  }
  if (f.projectedFinish) return { tone: 'risk', text: `At risk: planned work runs to ${fmtDate(f.projectedFinish)}, past your deadline` };
  return { tone: 'risk', text: 'At risk of missing the deadline' };
}

export function cheerFor(progress) {
  if (progress >= 100) return 'Goal complete!';
  if (progress >= 75) return 'Almost there!';
  if (progress >= 50) return 'Halfway there!';
  if (progress >= 25) return 'A quarter of the way!';
  return null;
}

export function FeasibilityLine({ goal, className = '' }) {
  const f = feasibilityOf(goal);
  const Icon = f.tone === 'risk' ? AlertTriangle : f.tone === 'ok' ? CheckCircle2 : Compass;
  return <div className={`gl-feas ${f.tone} ${className}`}><Icon size={15} /><span>{f.text}</span></div>;
}

function roadmapCta(g) {
  if (g.draft_id) return { label: 'Review draft roadmap', to: `/planner/review/${g.draft_id}`, icon: FileEdit, primary: true };
  if (!g.has_roadmap && g.status !== 'completed') return { label: 'Generate AI Roadmap', to: `/goals/${g.id}?generate=1`, icon: Sparkles, primary: true };
  return { label: 'Open', to: `/goals/${g.id}`, icon: ArrowRight, primary: false };
}

function GoalCard({ g }) {
  const cta = roadmapCta(g);
  const done = g.status === 'completed';
  return (
    <article className={`card gl-card ${done ? 'is-done' : ''}`} data-tour="goal-card">
      <div className="gl-top">
        <div className="gl-plant"><Plant progress={g.progress} kind={plantKindFor(g.id)} size={64} label={g.title} /></div>
        <div className="grow">
          <Link to={`/goals/${g.id}`} className="gl-title">{g.title}</Link>
          <div className="gl-meta">{g.deadline ? `By ${fmtDate(g.deadline, { month: 'short', day: 'numeric' })}` : 'No deadline'}</div>
        </div>
        {done ? <span className="badge done">Completed</span> : <PriorityBadge priority={g.priority} />}
      </div>
      {g.description && <p className="gl-desc">{g.description}</p>}

      <div className="gl-progress">
        <div className="row between small">
          <span className="muted"><b className="gl-stage">{stageOf(g.progress, plantKindFor(g.id)).name}</b> · {g.totalTasks ? `${g.completedTasks} of ${g.totalTasks} tasks` : 'no tasks yet'}</span>
          <span className="gl-pct">{g.progress}%</span>
        </div>
        <ProgressBar value={g.progress} kind={done ? 'done' : ''} label={`${g.title} progress`} />
      </div>

      {g.next_task && !done && (
        <div className="gl-next">
          <span className="muted">Next</span>
          <span className="strong truncate">{g.next_task.title}</span>
          <span className="muted gl-next-when">{fmtDayLabel(g.next_task.scheduled_start)}, {fmtTime(g.next_task.scheduled_start)}</span>
        </div>
      )}

      <div className="gl-foot">
        <span />
        <Link className={`btn sm ${cta.primary ? 'primary' : 'soft'}`} to={cta.to}><cta.icon size={15} />{cta.label}</Link>
      </div>
    </article>
  );
}

export default function Goals() {
  const { openDialog } = useApp();
  const { data, error } = useApi('/goals');
  const [tab, setTab] = useState('active');
  if (error) return <div className="page"><div className="form-error">{error.message}</div></div>;
  if (!data) return <PageSkeleton />;

  const goals = data.goals;
  const counts = {
    active: goals.filter((g) => g.status === 'active').length,
    completed: goals.filter((g) => g.status === 'completed').length,
    all: goals.length,
  };
  const shown = goals.filter((g) => tab === 'all' || g.status === tab);
  const create = () => openDialog('goal');

  return (
    <div className="page goals-page">
      <div className="page-head">
        <div>
          <h1>Goals</h1>
          <p>The bigger things you're working toward, planned around your classes.</p>
        </div>
        <div className="page-actions" data-tour="goal-create">
          <button className="btn primary" onClick={create}><Plus size={17} />Create goal</button>
        </div>
      </div>

      {goals.length === 0 ? (
        <div className="card">
          <EmptyState cat="wave" icon={Target} title="Your next big goal starts here."
            text="Add something you want to learn or finish. The planner will turn it into small steps that fit your free time."
            action={<button className="btn primary" onClick={create}><Plus size={16} />Create Goal</button>} />
        </div>
      ) : (
        <>
          <div className="gl-toolbar">
            <Tabs value={tab} onChange={setTab} options={[
              { value: 'active', label: 'Active', count: counts.active },
              { value: 'completed', label: 'Completed', count: counts.completed },
              { value: 'all', label: 'All', count: counts.all },
            ]} />
          </div>
          {shown.length === 0 ? (
            <div className="card">
              <EmptyState cat="wave" icon={tab === 'completed' ? PartyPopper : Target}
                title={tab === 'completed' ? 'No finished goals yet' : 'No active goals right now'}
                text={tab === 'completed' ? 'Goals you complete will be kept here.' : 'Start a new one whenever you are ready.'}
                action={tab !== 'completed' && <button className="btn primary sm" onClick={create}><Plus size={15} />Create goal</button>} />
            </div>
          ) : (
            <div className="gl-grid">
              {shown.map((g) => <GoalCard key={g.id} g={g} />)}
            </div>
          )}
        </>
      )}
    </div>
  );
}
