import { useCallback, useEffect, useRef, useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import {
  ImageUp, ArrowLeft, Check, Pencil, RotateCcw, Plus, Trash2, AlertTriangle, ScanText, Lightbulb, ShieldCheck, CircleCheck, Maximize2, Minimize2,
} from 'lucide-react';
import { api } from '../lib/api.js';
import { useApp, useApi } from '../lib/app.jsx';
import { DAYS, fmtTime } from '../lib/format.js';
import './routine-import.css';

const ACCEPT = ['image/png', 'image/jpeg', 'image/webp'];
const MAX_BYTES = 8 * 1024 * 1024;
const STEPS = ['Reading your routine…', 'Finding course codes and rooms…', 'Matching days and times…', 'Almost there…'];
const FIELDS = [
  ['course_code', 'Course code'], ['title', 'Title'], ['day', 'Day'], ['start_time', 'Start'],
  ['end_time', 'End'], ['room', 'Room'], ['instructor', 'Instructor'],
];
const TIME = /^\d{2}:\d{2}$/;

let keySeq = 0;
const newRow = ({ day, room, ...r } = {}) => ({
  key: ++keySeq, course_code: '', title: '', start_time: '', end_time: '', instructor: '', ...r,
  room: String(room || '').replace(/^room\s*/i, ''),
  day: day === '' || day == null ? '' : String(day),
});

// Field → friendly message for everything the server would reject.
function rowIssues(r) {
  const out = {};
  if (!String(r.course_code).trim()) out.course_code = 'Add the course code';
  if (r.day === '') out.day = 'Pick a day';
  if (!TIME.test(r.start_time)) out.start_time = 'Add a start time';
  if (!TIME.test(r.end_time)) out.end_time = 'Add an end time';
  if (!out.start_time && !out.end_time && r.start_time >= r.end_time) out.end_time = 'Ends before it starts';
  return out;
}

function rangeText(r) {
  if (!r.start_time && !r.end_time) return null;
  return `${r.start_time ? fmtTime(r.start_time) : '?'} – ${r.end_time ? fmtTime(r.end_time) : '?'}`;
}

function DropZone({ onFile, compact }) {
  const inputRef = useRef(null);
  const [drag, setDrag] = useState(false);
  const depth = useRef(0);
  return (
    <div
      className={`ri-drop ${drag ? 'dragging' : ''} ${compact ? 'compact' : ''}`}
      onDragEnter={(e) => { e.preventDefault(); depth.current += 1; setDrag(true); }}
      onDragOver={(e) => e.preventDefault()}
      onDragLeave={() => { depth.current -= 1; if (depth.current <= 0) setDrag(false); }}
      onDrop={(e) => { e.preventDefault(); depth.current = 0; setDrag(false); const f = e.dataTransfer.files?.[0]; if (f) onFile(f); }}
    >
      <input ref={inputRef} type="file" accept={ACCEPT.join(',')} className="sr-only" tabIndex={-1} aria-hidden="true"
        onChange={(e) => { const f = e.target.files?.[0]; e.target.value = ''; if (f) onFile(f); }} />
      <div className="ri-drop-art"><ImageUp size={30} /></div>
      <h3>{drag ? 'Drop it here' : 'Drop your routine image here'}</h3>
      <p className="muted small">A screenshot, photo or scan of your weekly timetable. JPG, PNG or WEBP up to 8 MB.</p>
      <button type="button" className="btn primary" onClick={() => inputRef.current?.click()}><ImageUp size={17} />Choose an image</button>
      <p className="tiny muted">Tip: you can also paste a screenshot with {navigator.platform?.includes('Mac') ? '⌘' : 'Ctrl'}+V.</p>
    </div>
  );
}

function Tips() {
  return (
    <aside className="card flat ri-tips">
      <div className="row" style={{ marginBottom: 10 }}><Lightbulb size={18} color="var(--deadline)" /><h3>For the best result</h3></div>
      <ul>
        <li>Show the whole week, with day names and times readable.</li>
        <li>Crop out anything that isn't your routine.</li>
        <li>A straight screenshot works better than an angled photo.</li>
      </ul>
      <div className="ri-trust"><ShieldCheck size={16} />You'll check every class before anything is saved.</div>
    </aside>
  );
}

function Reading({ preview, step }) {
  return (
    <div className="ri-reading card">
      <div className="ri-scan">
        {preview && <img src={preview} alt="Your routine" />}
        <div className="ri-scanline" aria-hidden="true" />
      </div>
      <div className="ri-steps" role="status" aria-live="polite">
        <div className="row" style={{ gap: 10, marginBottom: 6 }}><ScanText size={20} color="var(--primary)" /><h2>Reading your routine</h2></div>
        <p className="muted small" style={{ marginBottom: 14 }}>This usually takes 5 to 15 seconds.</p>
        <ol>
          {STEPS.map((s, i) => (
            <li key={s} className={i < step ? 'done' : i === step ? 'now' : ''}>
              <span className="ri-step-ic">{i < step ? <Check size={13} /> : i === step ? <span className="spinner" /> : null}</span>
              {s}
            </li>
          ))}
        </ol>
      </div>
    </div>
  );
}

function Cell({ row, field, label, editing, issue, onChange, dup }) {
  const id = `ri-${row.key}-${field}`;
  const common = { id, 'aria-label': label, 'aria-invalid': !!issue, className: `input sm ${issue ? 'invalid' : ''}`, value: row[field] ?? '', onChange: (e) => onChange(field, e.target.value) };
  let content;
  if (editing) {
    if (field === 'day') {
      content = (
        <select {...common} className={`select sm ${issue ? 'invalid' : ''}`}>
          <option value="">Pick a day</option>
          {DAYS.map((d, i) => <option key={d} value={String(i)}>{d}</option>)}
        </select>
      );
    } else if (field === 'start_time' || field === 'end_time') {
      content = <input type="time" {...common} />;
    } else {
      content = <input {...common} placeholder={{ course_code: 'CSE 327', title: 'Course title', room: '301', instructor: 'Instructor' }[field]} />;
    }
  } else if (issue) {
    content = <span className="ri-missing">{issue}</span>;
  } else if (field === 'course_code') {
    content = <span className="strong">{row.course_code}{dup && <span className="badge ri-dup">Already added, will skip</span>}</span>;
  } else if (field === 'day') {
    content = <span>{DAYS[Number(row.day)]}</span>;
  } else if (field === 'start_time' || field === 'end_time') {
    content = <span className="ri-num">{fmtTime(row[field])}</span>;
  } else {
    content = row[field] ? <span className="truncate">{row[field]}</span> : <span className="muted">—</span>;
  }
  return (
    <div className={`ri-cell c-${field}`}>
      <span className="ri-lbl" aria-hidden="true">{label}</span>
      {content}
    </div>
  );
}

function ReviewRow({ row, editing, dup, onChange, onDelete, onEdit }) {
  const issues = rowIssues(row);
  const bad = Object.keys(issues).length > 0;
  return (
    <div className={`ri-row ${bad ? 'bad' : ''} ${editing ? 'editing' : ''}`}>
      {!editing && (
        <div className="ri-mobile-sum">
          <div className="strong">{row.course_code || 'Course code?'}{row.title && <span className="muted"> · {row.title}</span>}</div>
          <div className="small muted">{[row.day !== '' ? DAYS[Number(row.day)] : null, rangeText(row), row.room && `Room ${row.room}`].filter(Boolean).join(' · ')}</div>
          {bad && <div className="ri-missing">{Object.values(issues).join(' · ')}</div>}
        </div>
      )}
      {FIELDS.map(([f, label]) => <Cell key={f} row={row} field={f} label={label} editing={editing} issue={issues[f]} dup={dup} onChange={onChange} />)}
      <div className="ri-cell c-actions">
        {editing
          ? <button type="button" className="btn ghost icon sm ri-del" aria-label={`Remove row ${row.course_code || ''}`} onClick={onDelete}><Trash2 size={16} /></button>
          : <button type="button" className="btn ghost icon sm" aria-label={`Edit ${row.course_code || 'row'}`} onClick={onEdit}><Pencil size={15} /></button>}
      </div>
    </div>
  );
}

/**
 * Upload → extract → review → confirm. Nothing is saved until "Looks correct".
 * onDone(addedCount) runs after a successful bulk save. `compact` drops outer spacing (onboarding wizard).
 */
export function RoutineImporter({ onDone, compact = false }) {
  const { refresh, toast, openDialog } = useApp();
  const { data: existing } = useApi('/classes');
  const [stage, setStage] = useState('pick'); // pick | reading | review | error
  const [preview, setPreview] = useState(null);
  const [step, setStep] = useState(0);
  const [rows, setRows] = useState([]);
  const [editing, setEditing] = useState(false);
  const [error, setError] = useState(null);
  const [notice, setNotice] = useState(null);
  const [saving, setSaving] = useState(false);
  const [bigPreview, setBigPreview] = useState(false);
  const runId = useRef(0);
  const lastFile = useRef(null);
  const [retryFile, setRetryFile] = useState(null);
  const pendingFocus = useRef(null);

  useEffect(() => () => preview && URL.revokeObjectURL(preview), [preview]);

  // Friendly progress steps while the server reads the image.
  useEffect(() => {
    if (stage !== 'reading') return undefined;
    const id = setInterval(() => setStep((s) => Math.min(s + 1, STEPS.length - 1)), 1900);
    return () => clearInterval(id);
  }, [stage]);

  useEffect(() => {
    if (!pendingFocus.current) return;
    const el = document.getElementById(pendingFocus.current);
    pendingFocus.current = null;
    el?.focus();
    el?.scrollIntoView({ block: 'center', behavior: 'smooth' });
  });

  const handleFile = useCallback(async (file) => {
    if (!ACCEPT.includes(file.type)) {
      toast('That file type won\'t work. Use a JPG, PNG or WEBP image.', 'error');
      return;
    }
    if (file.size > MAX_BYTES) {
      toast('That image is over 8 MB. Try a smaller screenshot.', 'error');
      return;
    }
    const id = ++runId.current;
    if (lastFile.current !== file) setPreview(URL.createObjectURL(file));
    lastFile.current = file;
    setRetryFile(file);
    setStep(0);
    setError(null);
    setNotice(null);
    setStage('reading');
    try {
      const form = new FormData();
      form.append('image', file);
      const r = await api('/classes/import-image', { method: 'POST', form });
      if (id !== runId.current) return;
      const list = (r.classes || []).map(newRow);
      if (!list.length) {
        setError("We couldn't find any classes in that image. Try a sharper screenshot that shows day names and times.");
        setStage('error');
        return;
      }
      setRows(list);
      setEditing(false);
      setBigPreview(false);
      setStage('review');
    } catch (e) {
      if (id !== runId.current) return;
      setError(e.message);
      setStage('error');
    }
  }, [toast]);

  // Paste a screenshot straight from the clipboard.
  useEffect(() => {
    if (stage !== 'pick') return undefined;
    const onPaste = (e) => {
      const f = [...(e.clipboardData?.files || [])].find((x) => x.type.startsWith('image/'));
      if (f) { e.preventDefault(); handleFile(f); }
    };
    window.addEventListener('paste', onPaste);
    return () => window.removeEventListener('paste', onPaste);
  }, [stage, handleFile]);

  const tryAgain = () => {
    runId.current += 1;
    lastFile.current = null;
    setRetryFile(null);
    setRows([]);
    setError(null);
    setNotice(null);
    setPreview(null);
    setStage('pick');
  };

  const invalid = rows.map((r) => ({ r, issues: rowIssues(r) })).filter((x) => Object.keys(x.issues).length);
  const focusFirstInvalid = () => {
    const first = invalid[0];
    if (!first) return false;
    pendingFocus.current = `ri-${first.r.key}-${Object.keys(first.issues)[0]}`;
    return true;
  };
  const startEdit = () => {
    setEditing(true);
    if (!focusFirstInvalid() && rows[0]) pendingFocus.current = `ri-${rows[0].key}-course_code`;
  };
  const update = (key) => (field, value) => setRows((list) => list.map((r) => (r.key === key ? { ...r, [field]: value } : r)));
  const remove = (key) => setRows((list) => list.filter((r) => r.key !== key));
  const addRow = () => {
    const r = newRow();
    setRows((list) => [...list, r]);
    setEditing(true);
    pendingFocus.current = `ri-${r.key}-course_code`;
  };
  const isDup = (r) => (existing?.classes || []).some((c) => c.course_code === String(r.course_code).trim().toUpperCase() && String(c.day) === r.day && c.start_time === r.start_time);

  const confirm = async () => {
    if (invalid.length) {
      setEditing(true);
      focusFirstInvalid();
      setNotice(`${invalid.length === 1 ? 'One row needs' : `${invalid.length} rows need`} a fix before saving. They're highlighted below.`);
      return;
    }
    setSaving(true);
    setNotice(null);
    try {
      // Exact copies of classes already in the schedule are skipped, never duplicated.
      const fresh = rows.filter((r) => !isDup(r));
      const skipped = rows.length - fresh.length;
      const body = fresh.map(({ key: _key, ...r }) => ({ ...r, day: Number(r.day), recurring: 'weekly' }));
      const res = body.length ? await api.post('/classes/bulk', { classes: body }) : { added: 0 };
      const skipText = skipped ? ` · ${skipped} already there, skipped` : '';
      toast(res.added ? `${res.added} class${res.added === 1 ? '' : 'es'} added to your weekly schedule${skipText}` : 'Those classes are already in your schedule', res.added ? 'success' : 'info');
      refresh();
      onDone?.(res.added);
    } catch (e) {
      setNotice(e.message);
    } finally {
      setSaving(false);
    }
  };

  if (stage === 'pick') {
    return (
      <div className={`ri ${compact ? 'compact' : ''}`}>
        <div className="ri-pick">
          <DropZone onFile={handleFile} compact={compact} />
          {!compact && <Tips />}
        </div>
      </div>
    );
  }

  if (stage === 'reading') return <div className={`ri ${compact ? 'compact' : ''}`}><Reading preview={preview} step={step} /></div>;

  if (stage === 'error') {
    return (
      <div className={`ri ${compact ? 'compact' : ''}`}>
        <div className="card ri-error">
          {preview && <img src={preview} alt="The image you uploaded" className="ri-error-thumb" />}
          <div className="grow">
            <div className="row" style={{ marginBottom: 6 }}><AlertTriangle size={19} color="var(--danger)" /><h2>We couldn't read that routine</h2></div>
            <p className="ri-error-msg">{error}</p>
            <div className="row wrap" style={{ marginTop: 16 }}>
              {retryFile && <button type="button" className="btn primary" onClick={() => handleFile(retryFile)}><RotateCcw size={16} />Try again</button>}
              <button type="button" className={`btn ${retryFile ? '' : 'primary'}`} onClick={tryAgain}><ImageUp size={16} />Use another image</button>
              <button type="button" className="btn ghost" onClick={() => openDialog('class')}><Plus size={16} />Add classes manually</button>
            </div>
          </div>
        </div>
      </div>
    );
  }

  const dupCount = rows.filter(isDup).length;
  return (
    <div className={`ri ${compact ? 'compact' : ''}`}>
      <div className="card ri-review">
        <div className="ri-review-head">
          {preview && (
            <button type="button" className="ri-thumb" onClick={() => setBigPreview((b) => !b)} aria-label={bigPreview ? 'Hide your image' : 'Show your image larger'} aria-expanded={bigPreview}>
              <img src={preview} alt="" />
              <span>{bigPreview ? <Minimize2 size={13} /> : <Maximize2 size={13} />}</span>
            </button>
          )}
          <div className="grow">
            <h2>We found {rows.length} class{rows.length === 1 ? '' : 'es'}</h2>
            <p className="muted small">Check them against your image. Nothing is saved until you press "Looks correct".</p>
          </div>
          <div className="row wrap ri-flags">
            {invalid.length > 0
              ? <span className="badge danger"><AlertTriangle size={13} />{invalid.length} need{invalid.length === 1 ? 's' : ''} a fix</span>
              : rows.length > 0 && <span className="badge done"><CircleCheck size={13} />All rows look complete</span>}
            {dupCount > 0 && <span className="badge deadline">{dupCount} already in your schedule, will be skipped</span>}
          </div>
        </div>

        {bigPreview && preview && <div className="ri-bigpreview"><img src={preview} alt="Your routine image" /></div>}
        {notice && <div className="form-error" style={{ marginBottom: 12 }}>{notice}</div>}

        <div className={`ri-table ${editing ? 'editing' : ''}`}>
          <div className="ri-row ri-headrow" aria-hidden="true">
            {FIELDS.map(([f, l]) => <div key={f} className={`ri-cell c-${f}`}>{l}</div>)}
            <div className="ri-cell c-actions" />
          </div>
          {rows.map((r) => (
            <ReviewRow key={r.key} row={r} editing={editing} dup={isDup(r)} onChange={update(r.key)} onDelete={() => remove(r.key)}
              onEdit={() => { setEditing(true); pendingFocus.current = `ri-${r.key}-${Object.keys(rowIssues(r))[0] || 'course_code'}`; }} />
          ))}
          {rows.length === 0 && <div className="free ri-norows">All rows removed. Add one, or try another image.</div>}
        </div>
        <button type="button" className="btn ghost sm ri-add" onClick={addRow}><Plus size={15} />Add a missing class</button>

        <div className="ri-foot">
          <button type="button" className="btn ghost" onClick={tryAgain}><RotateCcw size={16} />Try again</button>
          <div className="row wrap ri-foot-main">
            {editing
              ? <button type="button" className="btn" onClick={() => { setEditing(false); setNotice(null); }}><Check size={16} />Done editing</button>
              : <button type="button" className="btn" onClick={startEdit}><Pencil size={16} />Edit</button>}
            <button type="button" className="btn primary" onClick={confirm} disabled={saving || rows.length === 0}>
              <Check size={17} />{saving ? 'Saving…' : 'Looks correct'}
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}

export default function RoutineImport() {
  const navigate = useNavigate();
  return (
    <div className="page routine-import">
      <div className="page-head">
        <div>
          <h1>Import Routine from Image</h1>
          <p>Upload your class routine. We'll read it, and you check it before anything is saved.</p>
        </div>
        <div className="page-actions">
          <Link className="btn ghost" to="/schedule?view=classes"><ArrowLeft size={17} />Back to classes</Link>
        </div>
      </div>
      <RoutineImporter onDone={() => navigate('/schedule?view=classes')} />
    </div>
  );
}
