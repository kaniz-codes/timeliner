import { useState } from 'react';
import { Bell, BellRing, BookOpen, CalendarClock, ClipboardCheck, Flag, Plus, Target, Tent, Trash2, Trophy, Check } from 'lucide-react';
import { api } from '../lib/api.js';
import { useApp, useApi } from '../lib/app.jsx';
import { EmptyState, PageSkeleton } from '../components/ui.jsx';
import { fmtDayLabel, fmtDuration, fmtTime, minutesBetween, nowDt } from '../lib/format.js';
import './reminders.css';

const TYPES = {
  class: { icon: BookOpen, label: 'Class' },
  task: { icon: Target, label: 'Goal task' },
  deadline: { icon: Flag, label: 'Deadline' },
  activity: { icon: Tent, label: 'Event' },
  registration: { icon: ClipboardCheck, label: 'Registration' },
  goal: { icon: Trophy, label: 'Goal' },
  custom: { icon: Bell, label: 'Reminder' },
};

function relative(dt, now) {
  const m = minutesBetween(now, dt);
  if (m < 0 || m >= 24 * 60) return null;
  if (m < 1) return 'now';
  return `in ${fmtDuration(m)}`;
}

function ReminderCard({ r, now, past, onRemove, index }) {
  const t = TYPES[r.reference_type] || TYPES.custom;
  const Icon = t.icon;
  const rel = !past && relative(r.reminder_time, now);
  return (
    <div className={`rm-card ${r.reference_type} ${past ? 'past' : ''} ${r.leaving ? 'leaving' : ''}`} style={{ animationDelay: `${Math.min(index, 8) * 40}ms` }}>
      <div className="rm-icon" aria-hidden="true"><Icon size={19} /></div>
      <div className="grow">
        <div className="rm-title">{r.title}</div>
        <div className="rm-when">
          <span className="strong">{fmtDayLabel(r.reminder_time)}</span> · {fmtTime(r.reminder_time)}
          {rel && <span className="rm-rel">{rel}</span>}
        </div>
        <div className="row wrap" style={{ gap: 6, marginTop: 8 }}>
          <span className="rm-type">{t.label}</span>
          {r.offset_label && <span className="chip rm-offset">{r.offset_label}</span>}
          {past && <span className="badge">{r.status === 'sent' ? 'Sent' : 'Passed'}</span>}
        </div>
      </div>
      <div className="rm-actions">
        {!past && (
          <button className="btn xs ghost" onClick={() => onRemove(r, 'dismiss')} aria-label={`Dismiss reminder: ${r.title}`}><Check size={14} />Dismiss</button>
        )}
        <button className="btn xs ghost icon rm-del" onClick={() => onRemove(r, 'delete')} aria-label={`Delete reminder: ${r.title}`} title="Delete"><Trash2 size={14} /></button>
      </div>
    </div>
  );
}

export default function Reminders() {
  const { openDialog, refresh, toast } = useApp();
  const { data, error } = useApi('/reminders');
  const [leaving, setLeaving] = useState(() => new Set());
  const [removed, setRemoved] = useState(() => new Set());
  const supported = typeof window !== 'undefined' && 'Notification' in window;
  const [perm, setPerm] = useState(supported ? Notification.permission : 'unsupported');

  if (error) return <div className="page"><div className="form-error">{error.message}</div></div>;
  if (!data) return <PageSkeleton />;

  const now = nowDt();
  const list = data.reminders.filter((r) => !removed.has(r.id)).map((r) => ({ ...r, leaving: leaving.has(r.id) }));
  const upcoming = list.filter((r) => r.status === 'pending' && r.reminder_time >= now).sort((a, b) => a.reminder_time.localeCompare(b.reminder_time));
  const earlier = list.filter((r) => !(r.status === 'pending' && r.reminder_time >= now)).sort((a, b) => b.reminder_time.localeCompare(a.reminder_time));

  const remove = async (r, how) => {
    setLeaving((s) => new Set(s).add(r.id));
    try {
      await Promise.all([
        how === 'delete' ? api.del(`/reminders/${r.id}`) : api.put(`/reminders/${r.id}`, { status: 'dismissed' }),
        new Promise((res) => setTimeout(res, 220)),
      ]);
      setRemoved((s) => new Set(s).add(r.id));
      toast(how === 'delete' ? 'Reminder deleted' : 'Reminder dismissed', 'info');
      refresh();
    } catch (e) {
      setLeaving((s) => { const n = new Set(s); n.delete(r.id); return n; });
      toast(e.message, 'error');
    }
  };

  const askPermission = async () => {
    try {
      const p = await Notification.requestPermission();
      setPerm(p);
      if (p === 'granted') {
        api.put('/me/preferences', { notify_browser: 1 }).catch(() => {});
        toast("Browser notifications are on. We'll nudge you right on time.");
      } else toast('No problem. Reminders will still show up here in the app.', 'info');
    } catch {
      toast('Your browser blocked the request.', 'error');
    }
  };

  const next = upcoming[0];

  return (
    <div className="page reminders-page">
      <div className="page-head">
        <div>
          <h1>Reminders</h1>
          <p>{upcoming.length ? <>{upcoming.length} upcoming · next <strong className="rm-next">{fmtDayLabel(next.reminder_time)}, {fmtTime(next.reminder_time)}</strong></> : 'Gentle nudges before classes, deadlines and events.'}</p>
        </div>
        <div className="page-actions" data-tour="rem-add">
          <button className="btn primary" onClick={() => openDialog('reminder')}><Plus size={17} />Add reminder</button>
        </div>
      </div>

      {perm === 'default' && (
        <section className="card rm-perm">
          <div className="rm-perm-icon"><BellRing size={20} /></div>
          <div className="grow">
            <h3>Turn on browser notifications</h3>
            <p className="small muted">Get a gentle nudge even when MIND MAP is in another tab.</p>
          </div>
          <button className="btn sm soft" onClick={askPermission}>Turn on</button>
        </section>
      )}

      {upcoming.length === 0 && earlier.length === 0 ? (
        <section className="card">
          <EmptyState cat="sleepy" icon={CalendarClock} title="You're all caught up." text="Add a reminder for a class, a deadline or a registration and we'll nudge you before it."
            action={<button className="btn primary sm" onClick={() => openDialog('reminder')}><Plus size={15} />Add reminder</button>} />
        </section>
      ) : (
        <div className="stack" style={{ gap: 28 }}>
          <section>
            <div className="rm-section-head"><h2>Upcoming</h2><span className="badge primary">{upcoming.length}</span></div>
            {upcoming.length === 0 ? (
              <div className="card"><EmptyState cat="sleepy" icon={Bell} title="You're all caught up." text="Nothing coming up. Add one when you need it." /></div>
            ) : (
              <div className="rm-grid">
                {upcoming.map((r, i) => <ReminderCard key={r.id} r={r} now={now} index={i} onRemove={remove} />)}
              </div>
            )}
          </section>
          {earlier.length > 0 && (
            <section>
              <div className="rm-section-head"><h2>Earlier</h2><span className="badge">{earlier.length}</span></div>
              <div className="rm-grid">
                {earlier.map((r, i) => <ReminderCard key={r.id} r={r} now={now} index={i} past onRemove={remove} />)}
              </div>
            </section>
          )}
        </div>
      )}
    </div>
  );
}
