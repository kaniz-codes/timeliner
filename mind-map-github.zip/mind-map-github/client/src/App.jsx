import { lazy, Suspense } from 'react';
import { Navigate, Route, Routes, useLocation, useSearchParams } from 'react-router-dom';
import { useApp } from './lib/app.jsx';
import Layout from './components/Layout.jsx';
import { PageSkeleton } from './components/ui.jsx';
import Login from './pages/Login.jsx';
import ResetPassword, { ForgotPassword } from './pages/ResetPassword.jsx';

const Onboarding = lazy(() => import('./pages/Onboarding.jsx'));
const Dashboard = lazy(() => import('./pages/Dashboard.jsx'));
const RoutineImport = lazy(() => import('./pages/RoutineImport.jsx'));
const Goals = lazy(() => import('./pages/Goals.jsx'));
const GoalDetail = lazy(() => import('./pages/GoalDetail.jsx'));
const RoadmapReview = lazy(() => import('./pages/RoadmapReview.jsx'));
const Extracurricular = lazy(() => import('./pages/Extracurricular.jsx'));
const Timeline = lazy(() => import('./pages/Timeline.jsx'));
const Reminders = lazy(() => import('./pages/Reminders.jsx'));
const Assistant = lazy(() => import('./pages/Assistant.jsx'));
const Profile = lazy(() => import('./pages/Profile.jsx'));
const Settings = lazy(() => import('./pages/Settings.jsx'));
const More = lazy(() => import('./pages/More.jsx'));
const SearchPage = lazy(() => import('./pages/Search.jsx'));

// Pages that were merged keep their old addresses working.
function PlannerRedirect() {
  const [params] = useSearchParams();
  const goal = params.get('goal');
  return <Navigate to={goal ? `/goals/${goal}?generate=1` : '/goals'} replace />;
}

function TimelineRedirect() {
  const { search } = useLocation();
  return <Navigate to={`/schedule${search}`} replace />;
}

function Protected({ children }) {
  const { user, booting } = useApp();
  const location = useLocation();
  if (booting) return <PageSkeleton />;
  if (!user) return <Navigate to="/login" replace state={{ from: location.pathname }} />;
  if (!user.onboarded && location.pathname !== '/onboarding') return <Navigate to="/onboarding" replace />;
  return children;
}

export default function App() {
  const { user } = useApp();
  return (
    <Suspense fallback={<PageSkeleton />}>
    <Routes>
      <Route path="/login" element={user ? <Navigate to="/" replace /> : <Login mode="login" />} />
      <Route path="/register" element={user ? <Navigate to="/" replace /> : <Login mode="register" />} />
      <Route path="/forgot" element={<ForgotPassword />} />
      <Route path="/reset" element={<ResetPassword />} />
      <Route path="/onboarding" element={<Protected><Onboarding /></Protected>} />
      <Route element={<Protected><Layout /></Protected>}>
        <Route index element={<Dashboard />} />
        <Route path="schedule" element={<Timeline />} />
        <Route path="schedule/import" element={<RoutineImport />} />
        <Route path="goals" element={<Goals />} />
        <Route path="goals/:id" element={<GoalDetail />} />
        <Route path="planner" element={<PlannerRedirect />} />
        <Route path="planner/review/:rid" element={<RoadmapReview />} />
        <Route path="extracurricular" element={<Extracurricular />} />
        <Route path="timeline" element={<TimelineRedirect />} />
        <Route path="day" element={<Navigate to="/schedule" replace />} />
        <Route path="week" element={<Navigate to="/schedule?view=week" replace />} />
        <Route path="reminders" element={<Reminders />} />
        <Route path="progress" element={<Navigate to="/#progress" replace />} />
        <Route path="assistant" element={<Assistant />} />
        <Route path="profile" element={<Profile />} />
        <Route path="settings" element={<Settings />} />
        <Route path="search" element={<SearchPage />} />
        <Route path="more" element={<More />} />
      </Route>
      <Route path="*" element={<Navigate to="/" replace />} />
    </Routes>
    </Suspense>
  );
}
