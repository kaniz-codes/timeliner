import { StrictMode } from 'react';
import { createRoot } from 'react-dom/client';
import { BrowserRouter } from 'react-router-dom';
import './index.css';
import { AppProvider } from './lib/app.jsx';
import App from './App.jsx';
import { unlockSoundOnFirstTap } from './lib/sound.js';

unlockSoundOnFirstTap();

createRoot(document.getElementById('root')).render(
  <StrictMode>
    <BrowserRouter>
      <AppProvider>
        <App />
      </AppProvider>
    </BrowserRouter>
  </StrictMode>,
);
