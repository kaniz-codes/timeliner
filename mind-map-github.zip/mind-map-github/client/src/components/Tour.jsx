// First-visit tour: Miso points at each part of the home screen and says how to use it.
// Runs once per browser; "Replay the tour" in Settings starts it again.
import { useEffect, useLayoutEffect, useState } from 'react';
import { useLocation, useNavigate } from 'react-router-dom';
import { Cat } from './Cat.jsx';
import { play } from '../lib/sound.js';
import { TOURS } from '../lib/guide.js';
import './tour.css';

const DONE_KEY = 'mindmap.tour.done';
// Start any tour from anywhere: startTour('goals'). The dashboard tour also runs once on first visit.
export const startTour = (id = 'dashboard') => {
  if (id === 'dashboard') localStorage.removeItem(DONE_KEY);
  window.dispatchEvent(new CustomEvent('mindmap:tour', { detail: id }));
};

function findTarget(key) {
  return [...document.querySelectorAll(`[data-tour="${key}"]`)].find(visible) || null;
}

function visible(el) {
  if (!el) return false;
  const r = el.getBoundingClientRect();
  return r.width > 0 && r.height > 0 && getComputedStyle(el).visibility !== 'hidden';
}

export default function Tour() {
  const location = useLocation();
  const navigate = useNavigate();
  const [on, setOn] = useState(false);
  const [tourId, setTourId] = useState('dashboard');
  const [i, setI] = useState(0);
  const [rect, setRect] = useState(null);

  // Only steps whose target is on screen (the sidebar is hidden on phones, for example).
  const steps = on ? TOURS[tourId].steps.filter((s) => !s.target || findTarget(s.target)) : [];
  const step = steps[i];

  useEffect(() => {
    const start = (e) => {
      const id = TOURS[e.detail] ? e.detail : 'dashboard';
      const here = location.pathname + location.search;
      if (here !== TOURS[id].path) navigate(TOURS[id].path);
      setOn(false);
      setTourId(id);
      setI(0);
      setTimeout(() => setOn(true), here === TOURS[id].path ? 150 : 900);
    };
    window.addEventListener('mindmap:tour', start);
    return () => window.removeEventListener('mindmap:tour', start);
  }, [location.pathname, navigate]);

  // First visit to the home screen: wait for it to render, then begin.
  useEffect(() => {
    if (location.pathname !== '/' || localStorage.getItem(DONE_KEY)) return;
    const id = setTimeout(() => { if (findTarget('today')) { setTourId('dashboard'); setOn(true); } }, 1200);
    return () => clearTimeout(id);
  }, [location.pathname]);

  useLayoutEffect(() => {
    if (!on || !step) return;
    const el = step.target && findTarget(step.target);
    const measure = () => setRect(el ? el.getBoundingClientRect() : null);
    if (el) el.scrollIntoView({ block: 'center', behavior: 'smooth' });
    else setRect(null);
    const id = setTimeout(measure, el ? 350 : 0);
    window.addEventListener('resize', measure);
    window.addEventListener('scroll', measure, true);
    return () => { clearTimeout(id); window.removeEventListener('resize', measure); window.removeEventListener('scroll', measure, true); };
  }, [on, step]);

  if (!on || !step) return null;

  const finish = () => {
    if (tourId === 'dashboard') localStorage.setItem(DONE_KEY, '1');
    setOn(false);
    setI(0);
  };
  const next = () => {
    if (i >= steps.length - 1) {
      play('sparkle');
      finish();
    } else {
      play('tap');
      setI(i + 1);
    }
  };

  // Card goes below the highlighted area, or above it if there is no room.
  const pad = 8;
  const hole = rect && { top: rect.top - pad, left: rect.left - pad, width: rect.width + pad * 2, height: rect.height + pad * 2 };
  const cardW = Math.min(360, window.innerWidth - 24);
  let cardStyle = { left: '50%', top: '50%', transform: 'translate(-50%, -50%)' };
  if (hole) {
    const below = hole.top + hole.height + 12;
    const fitsBelow = below + 200 < window.innerHeight;
    const left = Math.max(12, Math.min(window.innerWidth - cardW - 12, hole.left + hole.width / 2 - cardW / 2));
    cardStyle = fitsBelow ? { top: below, left } : { top: Math.max(12, hole.top - 12), left, transform: 'translateY(-100%)' };
  }

  return (
    <div className="tour" role="dialog" aria-modal="true" aria-label={step.title}>
      {hole ? <div className="tour-hole" style={hole} /> : <div className="tour-dim" />}
      <div className="tour-card" style={{ ...cardStyle, width: cardW }} key={i}>
        <div className="tour-cat"><Cat mood={step.mood} size={64} /></div>
        <div className="grow">
          <div className="tour-title">{step.title}</div>
          <p>{step.text}</p>
          <div className="tour-foot">
            <span className="tour-dots">{steps.map((s, k) => <i key={s.title} className={k === i ? 'on' : ''} />)}</span>
            {i < steps.length - 1 && <button className="btn ghost sm" onClick={finish}>Skip</button>}
            <button className="btn primary sm" autoFocus onClick={next}>{i === steps.length - 1 ? (tourId === 'dashboard' ? 'Start planning' : 'Got it') : i === 0 && tourId === 'dashboard' ? "Let's go" : 'Next'}</button>
          </div>
        </div>
      </div>
    </div>
  );
}
