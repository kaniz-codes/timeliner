// Weekly review: the first Dashboard visit of a new week, Miso sums up last week and looks at the next.
import { useEffect, useState } from 'react';
import { useLocation, useNavigate } from 'react-router-dom';
import { CheckCircle2, Clock, Tent, CircleSlash, CalendarRange } from 'lucide-react';
import { api } from '../lib/api.js';
import { useApp } from '../lib/app.jsx';
import { addDays, fmtDate, fmtDuration, startOfWeek, today } from '../lib/format.js';
import { play } from '../lib/sound.js';
import { Cat } from './Cat.jsx';
import Plant, { plantKindFor } from './Plant.jsx';
import { CountUp } from './ui.jsx';
import './weekly-review.css';

const SEEN_KEY = 'mindmap.review.seen';
export const openWeeklyReview = () => window.dispatchEvent(new Event('mindmap:review'));

export default function WeeklyReview() {
  const { user, prefs } = useApp();
  const location = useLocation();
  const navigate = useNavigate();
  const [data, setData] = useState(null);
  const lastWeek = addDays(startOfWeek(today(), prefs?.week_start ?? 0), -7);

  const show = () => api.get(`/review?week=${lastWeek}`).then((r) => { setData(r); play('sparkle'); }).catch(() => {});

  useEffect(() => {
    window.addEventListener('mindmap:review', show);
    return () => window.removeEventListener('mindmap:review', show);
  });

  // Once per week, only on the Dashboard, and never on top of the first-visit tour.
  useEffect(() => {
    if (!user || location.pathname !== '/' || !prefs) return;
    if (!localStorage.getItem('mindmap.tour.done') || localStorage.getItem(SEEN_KEY) === lastWeek) return;
    const id = setTimeout(() => {
      api.get(`/review?week=${lastWeek}`).then((r) => {
        localStorage.setItem(SEEN_KEY, lastWeek);
        if (r.tasksDone || r.activities || r.missed) { setData(r); play('sparkle'); }
      }).catch(() => {});
    }, 900);
    return () => clearTimeout(id);
  }, [user, prefs, location.pathname, lastWeek]);

  if (!data) return null;
  const close = () => { localStorage.setItem(SEEN_KEY, lastWeek); setData(null); };
  const stats = [
    { icon: CheckCircle2, value: data.tasksDone, label: data.tasksDone === 1 ? 'task done' : 'tasks done', tone: 'done' },
    { icon: Clock, value: Math.round(data.focusedMinutes / 60), suffix: 'h', label: 'of focused work', tone: 'primary' },
    { icon: Tent, value: data.activities, label: data.activities === 1 ? 'activity' : 'activities', tone: 'activity' },
    { icon: CircleSlash, value: data.missed, label: 'missed', tone: 'danger' },
  ];
  const line = data.tasksDone >= 8 ? 'What a week! You kept every plant watered.'
    : data.tasksDone > 0 ? 'Nice work. Small steps add up.'
      : 'A quiet week. This one is a fresh start.';

  return (
    <div className="overlay" onMouseDown={(e) => e.target === e.currentTarget && close()}>
      <div className="modal wide review" role="dialog" aria-modal="true" aria-label="Your week in review">
        <div className="review-head">
          <Cat mood={data.tasksDone > 0 ? 'cheer' : 'happy'} size={84} />
          <div>
            <div className="tiny muted strong review-kicker">YOUR WEEK · {fmtDate(data.week.start)} – {fmtDate(data.week.end)}</div>
            <h2>{line}</h2>
            {data.bestDay && <p className="muted small keep">Best day: {fmtDate(data.bestDay.date, { weekday: 'long' })}, {data.bestDay.count} task{data.bestDay.count > 1 ? 's' : ''} done.</p>}
          </div>
        </div>
        <div className="review-stats">
          {stats.map((s) => (
            <div key={s.label} className={`review-stat ${s.tone}`}>
              <s.icon size={18} />
              <b><CountUp value={s.value} />{s.suffix || ''}</b>
              <span>{s.label}</span>
            </div>
          ))}
        </div>
        {data.goals.length > 0 && (
          <div className="review-garden">
            <div className="small strong">Plants that grew</div>
            <div className="review-plants">
              {data.goals.slice(0, 4).map((g) => (
                <div key={g.id} className="review-plant">
                  <Plant progress={g.progress} kind={plantKindFor(g.id)} size={64} label={g.title} />
                  <span className="truncate">{g.title}</span>
                  <b>+{g.gained}%</b>
                </div>
              ))}
            </div>
          </div>
        )}
        <div className="review-next">
          <CalendarRange size={18} />
          <span className="grow">
            This week looks <b>{data.next.mood.toLowerCase()}</b>: {fmtDuration(data.next.totalMinutes)} planned
            {data.next.busiest ? `, busiest on ${data.next.busiest.weekday}` : ''}.
          </span>
        </div>
        <div className="modal-foot" style={{ padding: 0 }}>
          <button className="btn ghost" onClick={close}>Close</button>
          <button className="btn primary" onClick={() => { close(); navigate('/schedule?view=week'); }}>Plan my week</button>
        </div>
      </div>
    </div>
  );
}

