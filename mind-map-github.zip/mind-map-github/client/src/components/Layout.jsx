import { Suspense, useEffect, useRef, useState } from 'react';
import { NavLink, Outlet, useLocation, useNavigate } from 'react-router-dom';
import {
  Home, CalendarDays, Target, Tent, Bell, MessageCircle, User, Settings, LogOut,
  Search, Plus, Moon, Sun, BookOpen, ListTodo, X,
} from 'lucide-react';
import { useApp } from '../lib/app.jsx';
import { api } from '../lib/api.js';
import { DialogHost } from './dialogs.jsx';
import GrowMoment from './GrowMoment.jsx';
import Tour from './Tour.jsx';
import MisoGuide, { openGuide } from './MisoGuide.jsx';
import WeeklyReview from './WeeklyReview.jsx';
import { Cat } from './Cat.jsx';
import { play } from '../lib/sound.js';
import { PageSkeleton } from './ui.jsx';
import { fmtDayLabel } from '../lib/format.js';
import './layout.css';



const NAV = [
  { to: '/', label: 'Dashboard', icon: Home, end: true },
  { to: '/schedule', label: 'My Schedule', icon: BookOpen },
  { to: '/goals', label: 'Goals', icon: Target },
  { to: '/extracurricular', label: 'Extracurricular', icon: Tent },
  { to: '/reminders', label: 'Reminders', icon: Bell },
  { to: '/assistant', label: 'AI Assistant', icon: MessageCircle },
];

const ADD_ITEMS = [
  { type: 'class', label: 'Class', icon: BookOpen, color: 'var(--class)' },
  { type: 'task', label: 'Task', icon: ListTodo, color: 'var(--goal)' },
  { type: 'goal', label: 'Goal', icon: Target, color: 'var(--primary)' },
  { type: 'activity', label: 'Extracurricular activity', icon: Tent, color: 'var(--activity)' },
  { type: 'reminder', label: 'Reminder', icon: Bell, color: 'var(--deadline)' },
];

function QuickAdd({ open, setOpen, className = '' }) {
  const { openDialog } = useApp();
  const ref = useRef(null);
  useEffect(() => {
    if (!open) return;
    const close = (e) => !ref.current?.contains(e.target) && setOpen(false);
    const esc = (e) => e.key === 'Escape' && setOpen(false);
    document.addEventListener('mousedown', close);
    document.addEventListener('keydown', esc);
    return () => { document.removeEventListener('mousedown', close); document.removeEventListener('keydown', esc); };
  }, [open, setOpen]);
  return (
    <div ref={ref} className={`quickadd ${className}`}>
      {open && (
        <div className="quickadd-menu" role="menu">
          <div className="tiny muted strong" style={{ padding: '4px 10px 6px' }}>Add</div>
          {ADD_ITEMS.map((it, i) => (
            <button key={it.type} role="menuitem" style={{ animationDelay: `${i * 30}ms` }} onClick={() => { setOpen(false); openDialog(it.type); }}>
              <span className="qa-icon" style={{ color: it.color }}><it.icon size={17} /></span>{it.label}
            </button>
          ))}
        </div>
      )}
    </div>
  );
}

function SearchBox() {
  const navigate = useNavigate();
  const [q, setQ] = useState('');
  const [results, setResults] = useState([]);
  const [open, setOpen] = useState(false);
  const ref = useRef(null);
  const input = useRef(null);

  useEffect(() => {
    const onKey = (e) => {
      if ((e.metaKey || e.ctrlKey) && e.key.toLowerCase() === 'k') { e.preventDefault(); input.current?.focus(); }
    };
    window.addEventListener('keydown', onKey);
    return () => window.removeEventListener('keydown', onKey);
  }, []);
  useEffect(() => {
    if (q.trim().length < 2) { setResults([]); return; }
    const id = setTimeout(() => api.get(`/search?q=${encodeURIComponent(q.trim())}`).then((r) => setResults(r.results.slice(0, 8))).catch(() => {}), 180);
    return () => clearTimeout(id);
  }, [q]);
  useEffect(() => {
    const close = (e) => !ref.current?.contains(e.target) && setOpen(false);
    document.addEventListener('mousedown', close);
    return () => document.removeEventListener('mousedown', close);
  }, []);

  const go = (r) => {
    setOpen(false);
    setQ('');
    const to = { goal: `/goals/${r.id}`, task: r.goal_id ? `/goals/${r.goal_id}` : '/schedule', class: '/schedule?view=classes', activity: '/extracurricular' }[r.type];
    navigate(to);
  };

  return (
    <div className="search" ref={ref}>
      <Search size={17} className="muted" />
      <input ref={input} value={q} placeholder="Search everything…" aria-label="Search goals, tasks, courses and activities"
        onFocus={() => setOpen(true)} onChange={(e) => { setQ(e.target.value); setOpen(true); }}
        onKeyDown={(e) => { if (e.key === 'Enter' && q.trim()) { setOpen(false); navigate(`/search?q=${encodeURIComponent(q.trim())}`); } }} />
      <kbd className="kbd">⌘K</kbd>
      {open && q.trim().length >= 2 && (
        <div className="search-pop">
          {results.length === 0 && <div className="small muted" style={{ padding: 12 }}>Nothing found for “{q}”.</div>}
          {results.map((r) => (
            <button key={`${r.type}-${r.id}`} onClick={() => go(r)}>
              <span className={`dot ${r.type === 'goal' ? 'goal' : r.type}`} />
              <span className="grow truncate"><strong>{r.title}</strong><span className="muted small"> · {r.subtitle}</span></span>
              <span className="tiny muted">{r.date ? fmtDayLabel(r.date) : r.type}</span>
            </button>
          ))}
          {results.length > 0 && (
            <button className="search-all" onClick={() => { setOpen(false); navigate(`/search?q=${encodeURIComponent(q.trim())}`); }}>
              See all results and filters
            </button>
          )}
        </div>
      )}
    </div>
  );
}

// Polls for due reminders; shows a toast and, if allowed, a browser notification.
function useReminderPoller() {
  const { toast, prefs, user } = useApp();
  useEffect(() => {
    if (!user) return;
    const tick = () => api.get('/reminders/due').then(({ due }) => {
      for (const r of due) {
        toast(`Reminder: ${r.title}`, 'info', 6000);
        if (prefs?.notify_browser && 'Notification' in window && Notification.permission === 'granted') {
          new Notification('MIND MAP', { body: r.title, icon: '/logo.svg' });
        }
      }
    }).catch(() => {});
    tick();
    const id = setInterval(tick, 60000);
    return () => clearInterval(id);
  }, [user, prefs?.notify_browser, toast]);
}

export default function Layout() {
  const { user, logout, theme, setTheme } = useApp();
  const [addOpen, setAddOpen] = useState(false);
  const [mobileAdd, setMobileAdd] = useState(false);
  const location = useLocation();
  const navigate = useNavigate();
  useReminderPoller();
  useEffect(() => { setAddOpen(false); setMobileAdd(false); }, [location.pathname]);

  return (
    <div className="shell">
      <aside className="sidebar">
        <div className="brand" onClick={() => navigate('/')}>
          <img src="/logo.svg" alt="" width={36} height={36} />
          <span>MIND MAP</span>
        </div>
        <nav className="nav" data-tour="nav">
          {NAV.map((n) => (
            <NavLink key={n.to} to={n.to} end={n.end} className={({ isActive }) => (isActive ? 'active' : '')}>
              <n.icon size={19} /><span>{n.label}</span>
            </NavLink>
          ))}
        </nav>
        <div className="nav nav-bottom">
          <button className="nav-guide" data-tour="guide" onClick={openGuide}><span className="nav-guide-cat"><Cat mood="happy" size={30} /></span><span>Miso's guide</span></button>
          <NavLink to="/profile"><User size={19} /><span>Profile</span></NavLink>
          <NavLink to="/settings"><Settings size={19} /><span>Settings</span></NavLink>
          <button onClick={logout}><LogOut size={19} /><span>Sign out</span></button>
        </div>
      </aside>

      <div className="main">
        <header className="topbar">
          <img src="/logo.svg" alt="MIND MAP" width={32} height={32} className="topbar-logo" onClick={() => navigate('/')} />
          <SearchBox />
          <div className="row" style={{ gap: 10, position: 'relative' }}>
            <button className="btn icon" onClick={() => { play('tap'); setTheme(theme === 'dark' ? 'light' : 'dark'); }} aria-label={theme === 'dark' ? 'Switch to light mode' : 'Switch to dark mode'}>
              {theme === 'dark' ? <Sun size={18} /> : <Moon size={18} />}
            </button>
            <button data-tour="add" className={`btn primary add-btn ${addOpen ? 'open' : ''}`} onClick={() => { play('tap'); setAddOpen((o) => !o); }} aria-expanded={addOpen} aria-haspopup="menu">
              <Plus size={18} className="add-plus" /><span>Add</span>
            </button>
            <QuickAdd open={addOpen} setOpen={setAddOpen} />
            <NavLink to="/profile" className="avatar" aria-label="Profile">{user?.name?.[0]?.toUpperCase()}</NavLink>
          </div>
        </header>
        <main key={location.pathname.split('/')[1]} className="content">
          <Suspense fallback={<PageSkeleton />}><Outlet /></Suspense>
        </main>
      </div>

      <nav className="bottomnav" aria-label="Main">
        <NavLink to="/" end><Home size={21} /><span>Home</span></NavLink>
        <NavLink to="/schedule"><BookOpen size={21} /><span>Schedule</span></NavLink>
        <button data-tour="add" className={`bn-add ${mobileAdd ? 'open' : ''}`} onClick={() => setMobileAdd((o) => !o)} aria-label="Add"><Plus size={24} /></button>
        <NavLink to="/assistant"><MessageCircle size={21} /><span>AI</span></NavLink>
        <NavLink to="/more"><User size={21} /><span>Profile</span></NavLink>
      </nav>
      <QuickAdd open={mobileAdd} setOpen={setMobileAdd} className="mobile" />

      <Toasts />
      <DialogHost />
      <GrowMoment />
      <Tour />
      <MisoGuide />
      <WeeklyReview />
    </div>
  );
}

export function Toasts() {
  const { toasts, dismiss } = useApp();
  return (
    <div className="toasts" aria-live="polite">
      {toasts.map((t) => (
        <div key={t.id} className={`toast ${t.kind} ${t.leaving ? 'out' : ''}`}>
          <span className="grow">{t.message}</span>
          {t.action && <button className="btn xs soft" onClick={() => { dismiss(t.id); t.action.onClick(); }}>{t.action.label}</button>}
          <button className="btn ghost icon xs" onClick={() => dismiss(t.id)} aria-label="Dismiss"><X size={14} /></button>
        </div>
      ))}
    </div>
  );
}

export { NAV };
