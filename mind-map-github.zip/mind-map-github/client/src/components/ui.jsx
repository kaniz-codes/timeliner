import { useEffect, useRef, useState } from 'react';
import { X, Check, Pencil, CalendarClock, MoreHorizontal } from 'lucide-react';
import { cap, fmtDuration, fmtRange, fmtDue } from '../lib/format.js';
import { Cat, catEnabled } from './Cat.jsx';
import { play } from '../lib/sound.js';
import { useApp } from '../lib/app.jsx';

export function PriorityBadge({ priority }) {
  if (!priority) return null;
  return <span className={`badge ${priority}`}>{cap(priority)}</span>;
}

const STATUS_STYLE = {
  completed: 'done', missed: 'danger', rescheduled: 'primary', in_progress: 'class', cancelled: '', pending: '',
  interested: '', registered: 'activity', upcoming: 'deadline',
};
export function StatusBadge({ status }) {
  if (!status) return null;
  return <span className={`badge ${STATUS_STYLE[status] ?? ''}`}>{cap(status.replace('_', ' '))}</span>;
}

// Animates from 0 (or the previous value) to the new value.
export function ProgressBar({ value = 0, kind = '', label }) {
  const [w, setW] = useState(0);
  useEffect(() => {
    const id = requestAnimationFrame(() => setW(Math.max(0, Math.min(100, value))));
    return () => cancelAnimationFrame(id);
  }, [value]);
  return (
    <div className={`bar ${kind}`} role="progressbar" aria-valuenow={Math.round(value)} aria-valuemin={0} aria-valuemax={100} aria-label={label}>
      <i style={{ width: `${w}%` }} />
    </div>
  );
}

export function Ring({ value = 0, size = 64, stroke = 7, color = 'var(--primary)', children, label }) {
  const [v, setV] = useState(0);
  useEffect(() => {
    const id = requestAnimationFrame(() => setV(Math.max(0, Math.min(100, value))));
    return () => cancelAnimationFrame(id);
  }, [value]);
  const r = (size - stroke) / 2;
  const c = 2 * Math.PI * r;
  return (
    <div style={{ position: 'relative', width: size, height: size, flex: 'none' }} role="img" aria-label={label}>
      <svg className="ring" width={size} height={size} style={{ transform: 'rotate(-90deg)' }}>
        <circle cx={size / 2} cy={size / 2} r={r} fill="none" stroke="var(--surface-2)" strokeWidth={stroke} />
        <circle cx={size / 2} cy={size / 2} r={r} fill="none" stroke={color} strokeWidth={stroke} strokeLinecap="round"
          strokeDasharray={c} strokeDashoffset={c * (1 - v / 100)} />
      </svg>
      <div style={{ position: 'absolute', inset: 0, display: 'grid', placeItems: 'center', textAlign: 'center' }}>{children}</div>
    </div>
  );
}

// `cat` = a Miso mood; when Miso is on she replaces the icon.
// Counts up to `value` once when it first appears or changes (numbers only).
export function CountUp({ value, duration = 600 }) {
  const [shown, setShown] = useState(0);
  useEffect(() => {
    const target = Number(value) || 0;
    if (window.matchMedia('(prefers-reduced-motion: reduce)').matches) { setShown(target); return; }
    let raf;
    const t0 = performance.now();
    const from = 0;
    const step = (t) => {
      const k = Math.min(1, (t - t0) / duration);
      setShown(Math.round(from + (target - from) * (1 - (1 - k) ** 3)));
      if (k < 1) raf = requestAnimationFrame(step);
    };
    raf = requestAnimationFrame(step);
    return () => cancelAnimationFrame(raf);
  }, [value, duration]);
  return <>{shown}</>;
}

export function EmptyState({ icon: Icon, title, text, action, cat }) {
  const showCat = cat && catEnabled();
  return (
    <div className="empty">
      {showCat ? <Cat mood={cat} size={84} /> : Icon && <div className="art"><Icon size={28} /></div>}
      {title && <h3>{title}</h3>}
      {text && <p>{text}</p>}
      {action}
    </div>
  );
}

export function Spinner({ label }) {
  return <div className="row muted small" role="status"><div className="spinner" />{label}</div>;
}

export function Skeleton({ h = 16, w = '100%', style }) {
  return <div className="skeleton" style={{ height: h, width: w, ...style }} />;
}

export function PageSkeleton() {
  return (
    <div className="page">
      <Skeleton h={34} w={280} />
      <Skeleton h={16} w={380} style={{ marginTop: 12 }} />
      <div className="grid cols-3" style={{ marginTop: 28 }}>
        {[0, 1, 2].map((i) => <Skeleton key={i} h={140} />)}
      </div>
      <Skeleton h={260} style={{ marginTop: 20 }} />
    </div>
  );
}

export function Tabs({ value, onChange, options }) {
  return (
    <div className="tabs" role="tablist">
      {options.map((o) => {
        const opt = typeof o === 'string' ? { value: o, label: o } : o;
        return (
          <button type="button" key={opt.value} role="tab" aria-selected={value === opt.value} className={value === opt.value ? 'active' : ''} onClick={() => { if (value !== opt.value) play('tap'); onChange(opt.value); }}>
            {opt.label}{opt.count != null && <span className="count">{opt.count}</span>}
          </button>
        );
      })}
    </div>
  );
}

export function Modal({ title, onClose, children, footer, wide }) {
  useEffect(() => {
    const onKey = (e) => e.key === 'Escape' && onClose();
    window.addEventListener('keydown', onKey);
    return () => window.removeEventListener('keydown', onKey);
  }, [onClose]);
  return (
    <div className="overlay" onMouseDown={(e) => e.target === e.currentTarget && onClose()}>
      <div className={`modal ${wide ? 'wide' : ''}`} role="dialog" aria-modal="true" aria-label={typeof title === 'string' ? title : undefined}>
        <div className="modal-head">
          <h2>{title}</h2>
          <button className="btn ghost icon sm" onClick={onClose} aria-label="Close"><X size={18} /></button>
        </div>
        <div className="modal-body">{children}</div>
        {footer && <div className="modal-foot">{footer}</div>}
      </div>
    </div>
  );
}

export function Field({ label, hint, children, full }) {
  return (
    <label className={`field ${full ? 'full' : ''}`}>
      <span>{label}{hint && <span className="hint"> · {hint}</span>}</span>
      {children}
    </label>
  );
}

export function Checkbox({ checked, onChange, label }) {
  // `popped` plays the check pop only when the student ticks it, not on first render.
  const [popped, setPopped] = useState(false);
  const click = (e) => {
    if (!checked) setPopped(true);
    onChange?.(e);
  };
  return (
    <button type="button" className={`check ${checked ? 'on' : ''} ${popped && checked ? 'pop' : ''}`} onClick={click} aria-pressed={checked} aria-label={label}>
      <svg viewBox="0 0 16 16" fill="none" stroke="currentColor" strokeWidth="2.6" strokeLinecap="round" strokeLinejoin="round"><path d="M3.5 8.5l3 3 6-7" /></svg>
    </button>
  );
}

// Small "..." menu. items: [{ label, icon, onClick, danger }]
export function Menu({ items, label = 'More actions' }) {
  const [open, setOpen] = useState(false);
  const ref = useRef(null);
  useEffect(() => {
    if (!open) return;
    const close = (e) => !ref.current?.contains(e.target) && setOpen(false);
    document.addEventListener('mousedown', close);
    return () => document.removeEventListener('mousedown', close);
  }, [open]);
  return (
    <div ref={ref} style={{ position: 'relative' }}>
      <button className="btn ghost icon sm" aria-label={label} aria-expanded={open} onClick={(e) => { e.stopPropagation(); setOpen((o) => !o); }}>
        <MoreHorizontal size={18} />
      </button>
      {open && (
        <div className="menu" style={{ right: 0, top: 36 }}>
          {items.map((it) => (
            <button key={it.label} className={it.danger ? 'danger' : ''} onClick={(e) => { e.stopPropagation(); setOpen(false); it.onClick(); }}>
              {it.icon && <it.icon size={16} />}{it.label}
            </button>
          ))}
        </div>
      )}
    </div>
  );
}

/**
 * One task/class/activity row. `item` uses the server's block shape
 * ({ kind, title, start, end, status, priority, ... }) or a task row.
 * Hover reveals quick actions: complete, edit, reschedule.
 */
export function ItemRow({ item, onComplete, onUncomplete, onEdit, onReschedule, meta, right, showTime = true }) {
  const [flash, setFlash] = useState(false);
  const { uncompleteTask } = useApp();
  const kind = item.kind || 'task';
  const done = item.status === 'completed';
  const missed = item.status === 'missed';
  const start = item.start || item.scheduled_start;
  const end = item.end || item.scheduled_end;
  const isTask = kind === 'task';
  const minutes = item.minutes || item.estimated_minutes;
  const defaultMeta = [
    showTime && start ? fmtRange(start, end) : null,
    minutes ? fmtDuration(minutes) : null,
    item.goal_title || item.room ? (item.goal_title || `Room ${item.room}`) : null,
    item.location || null,
  ].filter(Boolean).join(' · ');

  const complete = async () => {
    setFlash(true);
    await onComplete?.(item);
  };

  return (
    <div className={`item ${kind} ${done ? 'completed' : ''} ${missed ? 'missed' : ''} ${flash ? 'flash' : ''}`}>
      {isTask && onComplete && <Checkbox checked={done} onChange={done ? () => { setFlash(false); (onUncomplete || uncompleteTask)(item); } : complete} label={done ? `Mark ${item.title} as not done` : `Complete ${item.title}`} />}
      <div className="grow">
        <div className="item-title truncate">{item.title}</div>
        <div className="item-meta truncate">{meta ?? defaultMeta}</div>
      </div>
      {isTask && !done && (
        <div className="item-actions">
          {onComplete && <button className="btn xs ghost" onClick={complete} title="Complete"><Check size={14} />Done</button>}
          {onEdit && <button className="btn xs ghost" onClick={() => onEdit(item)} title="Edit"><Pencil size={14} /></button>}
          {onReschedule && <button className="btn xs ghost" onClick={() => onReschedule(item)} title="Reschedule"><CalendarClock size={14} />Move</button>}
        </div>
      )}
      {right}
      {isTask && item.priority === 'high' && !done && <PriorityBadge priority="high" />}
      {missed && <StatusBadge status="missed" />}
    </div>
  );
}

export function DueText({ date }) {
  return <span>{fmtDue(date)}</span>;
}
