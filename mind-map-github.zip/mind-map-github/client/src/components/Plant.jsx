import { useEffect, useRef, useState } from 'react';
import './plant.css';

/* A goal drawn as a potted plant. Everything is a continuous function of the
   (tweened) progress value, so each finished task visibly grows the plant and
   changes between stages never "pop". Style: flat shapes, no outlines, one
   darker half per shape for soft shading. */

export const PLANT_STAGES = [
  { min: 0, name: 'Seed' },
  { min: 1, name: 'Sprout' },
  { min: 20, name: 'Seedling' },
  { min: 45, name: 'Young plant' },
  { min: 70, name: 'Budding' },
  { min: 100, name: 'In bloom' },
];

const KIND_LIST = ['sunflower', 'tulip', 'lemon', 'strawberry', 'lavender'];
const FRUIT_KINDS = ['lemon', 'strawberry'];

const stageName = (i, kind) => (i === 5 && FRUIT_KINDS.includes(kind) ? 'Fruiting' : PLANT_STAGES[i].name);

export function stageOf(progress, kind) {
  const p = Math.max(0, Math.min(100, Number(progress) || 0));
  let index = 0;
  PLANT_STAGES.forEach((s, i) => { if (p >= s.min) index = i; });
  const next = index < PLANT_STAGES.length - 1
    ? { min: PLANT_STAGES[index + 1].min, name: stageName(index + 1, kind) }
    : null;
  return { index, name: stageName(index, kind), next };
}

export function plantKindFor(seed) {
  let n;
  if (typeof seed === 'number' || /^\d+$/.test(String(seed ?? ''))) n = Math.abs(Math.floor(Number(seed) || 0));
  else {
    n = 0;
    for (const ch of String(seed ?? '')) n = (n * 31 + ch.charCodeAt(0)) >>> 0;
  }
  return KIND_LIST[n % KIND_LIST.length];
}

/* ---------- palette & per-kind shape settings ---------- */

const GREEN = { leafC: '#67bd72', shadeC: '#4fa25d', stem: '#5aaa66' };
const KINDS = {
  sunflower: { ...GREEN, h: 0.8, leaf: 'pointed', L: 40, W: 16, ang: [74, 36], branch: null, bs: 1.42 },
  tulip: { h: 0.8, leaf: 'blade', L: 56, W: 9, ang: [30, 0], branch: null, bs: 1.45, leafC: '#72bf7c', shadeC: '#57a363', stem: '#62ad6b' },
  lemon: { h: 0.86, leaf: 'round', L: 32, W: 14, ang: [66, 30], branch: { len: 44, v: 52 }, bs: 1.35, leafC: '#4fae67', shadeC: '#3b9255', stem: '#8a6a4f' },
  strawberry: { ...GREEN, h: 0.4, leaf: 'trio', L: 34, W: 10, ang: [70, 24], branch: { len: 46, v: 98 }, bs: 1.4 },
  lavender: { h: 0.86, leaf: 'narrow', L: 34, W: 5.6, ang: [44, 16], branch: { len: 56, v: 17 }, bs: 1.3, leafC: '#8fbf95', shadeC: '#739f79', stem: '#7fb088' },
};
const colorsOf = (k) => ({ leaf: k.leafC, shade: k.shadeC, stem: k.stem });

// Stem leaves: t = progress where it starts growing, f = position along the stem.
const LEAVES = [
  { t: 20, f: 0.32, side: -1, s: 1 },
  { t: 28, f: 0.5, side: 1, s: 0.95 },
  { t: 38, f: 0.16, side: 1, s: 1.05 },
  { t: 50, f: 0.64, side: -1, s: 0.86 },
  { t: 60, f: 0.78, side: 1, s: 0.76 },
  { t: 68, f: 0.12, side: -1, s: 1 },
];
const TULIP_LEAVES = [
  { t: 12, f: 0.04, side: -1, s: 0.8 },
  { t: 26, f: 0.06, side: 1, s: 0.9 },
  { t: 44, f: 0.18, side: -1, s: 0.78 },
  { t: 60, f: 0.24, side: 1, s: 0.7 },
];
// Strawberry is a rosette: leaves on long stalks fanning out from the base.
const STRAW_LEAVES = [
  { t: 20, f: 0.05, side: -1, v: 52, s: 0.9 },
  { t: 28, f: 0.05, side: 1, v: 48, s: 0.95 },
  { t: 38, f: 0.03, side: -1, v: 78, s: 0.85 },
  { t: 48, f: 0.03, side: 1, v: 80, s: 0.85 },
  { t: 58, f: 0.1, side: -1, v: 24, s: 0.9 },
  { t: 66, f: 0.1, side: 1, v: 20, s: 0.85 },
];
const BRANCHES = [
  { t: 45, f: 0.46, side: 1 },
  { t: 56, f: 0.6, side: -1 },
];
const BUD_T = [70, 78, 86];

const BASE = { x: 100, y: 168 };

const clamp = (v, a = 0, b = 1) => Math.min(b, Math.max(a, v));
const ramp = (p, a, b) => clamp((p - a) / (b - a));
const easeOut = (t) => 1 - (1 - t) ** 3;
const rad = (d) => (d * Math.PI) / 180;
const r1 = (n) => Math.round(n * 10) / 10;

/* ---------- geometry helpers ---------- */

function quad(b, c, t, tt) {
  const u = 1 - tt;
  return {
    x: u * u * b.x + 2 * u * tt * c.x + tt * tt * t.x,
    y: u * u * b.y + 2 * u * tt * c.y + tt * tt * t.y,
    // tangent angle in degrees
    a: (Math.atan2(2 * u * (c.y - b.y) + 2 * tt * (t.y - c.y), 2 * u * (c.x - b.x) + 2 * tt * (t.x - c.x)) * 180) / Math.PI,
  };
}

function leafPaths(shape, L, W) {
  if (shape === 'round') {
    return [
      `M0 0C${r1(L * 0.12)} ${r1(-W * 1.25)} ${r1(L * 0.86)} ${r1(-W * 1.2)} ${r1(L)} 0C${r1(L * 0.86)} ${r1(W * 1.2)} ${r1(L * 0.12)} ${r1(W * 1.25)} 0 0Z`,
      `M0 0L${r1(L)} 0C${r1(L * 0.86)} ${r1(W * 1.2)} ${r1(L * 0.12)} ${r1(W * 1.25)} 0 0Z`,
    ];
  }
  // pointed / narrow / blade: soft almond with a pointed tip
  return [
    `M0 0C${r1(L * 0.22)} ${r1(-W * 1.3)} ${r1(L * 0.7)} ${r1(-W * 1.2)} ${r1(L)} 0C${r1(L * 0.7)} ${r1(W * 1.2)} ${r1(L * 0.22)} ${r1(W * 1.3)} 0 0Z`,
    `M0 0L${r1(L)} 0C${r1(L * 0.7)} ${r1(W * 1.2)} ${r1(L * 0.22)} ${r1(W * 1.3)} 0 0Z`,
  ];
}

function Leaf({ x, y, a, s, flip, shape, L, W, c, pet = 0.32 }) {
  if (s <= 0.01) return null;
  const tr = `translate(${r1(x)} ${r1(y)}) rotate(${r1(a)}) scale(${r1(s * 100) / 100} ${r1((flip ? -s : s) * 100) / 100})`;
  if (shape === 'trio') {
    const [f, h] = leafPaths('round', L * 0.62, W);
    const leaflet = (ang, k) => (
      <g transform={`translate(${r1(L * (pet - 0.02))} 0) rotate(${ang}) scale(${k})`}>
        <path d={f} fill={c.leaf} />
        <path d={h} fill={c.shade} />
      </g>
    );
    return (
      <g transform={tr}>
        <path d={`M0 0L${r1(L * pet)} 0`} stroke={c.stem} strokeWidth="2.6" strokeLinecap="round" />
        {leaflet(-44, 0.86)}
        {leaflet(44, 0.86)}
        {leaflet(0, 1)}
      </g>
    );
  }
  const [f, h] = leafPaths(shape, L, W);
  return (
    <g transform={tr}>
      <path d={f} fill={c.leaf} />
      <path d={h} fill={c.shade} />
    </g>
  );
}

/* ---------- buds, flowers, fruit (local coords: attach at 0,0, "up" = -y) ---------- */

function star(n, ro, ri, cy = 0) {
  let d = '';
  for (let i = 0; i < n * 2; i++) {
    const r = i % 2 ? ri : ro;
    const a = rad(-90 + (i * 180) / n);
    d += `${i ? 'L' : 'M'}${r1(Math.cos(a) * r)} ${r1(Math.sin(a) * r + cy)}`;
  }
  return d + 'Z';
}

function Bud({ kind, ripe }) {
  if (kind === 'sunflower') {
    return (
      <g>
        {ripe > 0.35 && [-40, -20, 0, 20, 40].map((a) => (
          <ellipse key={a} cx="0" cy="-15" rx="2.6" ry={r1(3 + ripe * 3)} fill="#fcc83a" transform={`rotate(${a} 0 -7)`} opacity={r1(ramp(ripe, 0.35, 0.7))} />
        ))}
        <path d={star(7, 10, 6.2, -7)} fill="#4f9a58" strokeLinejoin="round" stroke="#4f9a58" strokeWidth="2" />
        <circle cx="0" cy="-7" r="6.4" fill="#63b66c" />
        <path d="M-6.4 -7a6.4 6.4 0 0 0 12.8 0Z" fill="#54a45e" />
      </g>
    );
  }
  if (kind === 'tulip') {
    return (
      <g>
        <path d="M0 2C-7.5 0-8 -12 0 -21C8 -12 7.5 0 0 2Z" fill="#7cc485" />
        <g transform={`translate(0 -21) scale(${r1(0.3 + ripe * 0.7)}) translate(0 21)`} opacity={r1(0.4 + ripe * 0.6)}>
          <path d="M0 -21C5.5 -15 6.5 -9 5.6 -6C3 -8 -3 -8 -5.6 -6C-6.5 -9 -5.5 -15 0 -21Z" fill="#f47d8a" />
        </g>
        <path d="M0 2C4 0 7.5 -8 0 -21C3 -10 3 -3 0 2Z" fill="#000" opacity="0.08" />
        <path d="M0 2C-6 1-6.5 -6 -4 -9C-2 -4 -1 -1 0 2Z" fill="#6bb574" />
      </g>
    );
  }
  if (kind === 'lavender') {
    const n = 3 + Math.round(ripe * 3);
    return (
      <g>
        {Array.from({ length: n }, (_, i) => (
          <ellipse key={i} cx={i % 2 ? 1.3 : -1.3} cy={r1(-3 - i * 3.2)} rx="2.6" ry="3.2" fill={i % 2 ? '#9f8fd0' : '#b2a3dd'} />
        ))}
      </g>
    );
  }
  // lemon & strawberry: little white blossom buds with a green calyx
  return (
    <g>
      <circle cx="0" cy="-5" r="4.4" fill="#fffaf2" />
      <path d="M-4.4 -5a4.4 4.4 0 0 0 8.8 0Z" fill={kind === 'lemon' ? '#f6d9dc' : '#f1ece4'} />
      <path d={star(5, 4.6, 2, -1.2)} fill="#5aa865" />
    </g>
  );
}

const PETAL = 'M0 -8C5.4 -10.5 6 -18.5 0 -25.5C-6 -18.5 -5.4 -10.5 0 -8Z';

function Sunflower() {
  const petals = Array.from({ length: 14 }, (_, i) => (i * 360) / 14);
  return (
    <g transform="translate(0 -10) rotate(-6)">
      {petals.map((a) => (
        <path key={`b${a}`} d={PETAL} fill="#f2a632" transform={`rotate(${r1(a + 180 / 14)}) scale(1 1.04)`} />
      ))}
      {petals.map((a) => (
        <path key={a} d={PETAL} fill="#fcc93b" transform={`rotate(${r1(a)})`} />
      ))}
      <circle r="11" fill="#7b4a2c" />
      <circle r="7.6" fill="#8f5b35" />
      {[[-3, -2], [2.5, -3.2], [3.4, 1.6], [-1.2, 3.2], [-4.4, 1.4], [0.4, 0]].map(([x, y], i) => (
        <circle key={i} cx={x} cy={y} r="0.95" fill="#5e3620" />
      ))}
      <ellipse cx="-3.6" cy="-5" rx="3" ry="1.8" fill="#fff" opacity="0.14" transform="rotate(-30 -3.6 -5)" />
    </g>
  );
}

function Tulip() {
  return (
    <g>
      <path d="M-9 -6C-10.5 -19 -4 -29 0 -32C4 -29 10.5 -19 9 -6Z" fill="#df5a6b" />
      <path d="M1 2C-9 2-14 -6 -13.5 -17C-13.2 -23 -10.5 -27 -8 -29C-6 -20 -2 -11 4 -4C4 0 3 2 1 2Z" fill="#fb8f9b" />
      <path d="M-1 2C9 2 14 -6 13.5 -17C13.2 -23 10.5 -27 8 -29C6 -20 2 -11 -4 -4C-4 0 -3 2 -1 2Z" fill="#ef7282" />
      <path d="M-10 -19C-10 -23 -9 -25 -7.6 -26.5C-7 -23 -6.5 -21 -6 -19.5C-7.5 -19 -9 -18.5 -10 -19Z" fill="#fff" opacity="0.35" />
    </g>
  );
}

function Lavender() {
  const n = 8;
  return (
    <g>
      {Array.from({ length: n }, (_, i) => {
        const y = -2 - i * 3.9;
        const k = 1 - i * 0.055;
        return (
          <g key={i}>
            <ellipse cx={r1(-2.6 * k)} cy={r1(y)} rx={r1(3 * k)} ry={r1(3.6 * k)} fill={i % 2 ? '#9a7fe6' : '#8a6bdc'} />
            <ellipse cx={r1(2.6 * k)} cy={r1(y - 1.6)} rx={r1(3 * k)} ry={r1(3.6 * k)} fill={i % 2 ? '#b096f2' : '#a286ee'} />
          </g>
        );
      })}
      <ellipse cx="0" cy={r1(-3.9 * n)} rx="2.2" ry="3" fill="#b9a2f5" />
    </g>
  );
}

function Lemon({ side }) {
  return (
    <g>
      <path d={`M0 0Q${side * 2} 6 ${side * 3} 10`} stroke="#6f9a58" strokeWidth="1.8" fill="none" strokeLinecap="round" />
      <g transform={`translate(${side * 4} 19) rotate(${side * -14})`}>
        <ellipse cx="0" cy="0" rx="8.4" ry="10" fill="#f9d545" />
        <circle cx="0" cy="10" r="2" fill="#f2c737" />
        <path d="M0 -10A8.4 10 0 0 1 0 10Z" fill="#edbd2b" />
        <ellipse cx="-3.4" cy="-3.6" rx="2" ry="3.4" fill="#fff6c4" opacity="0.8" transform="rotate(18 -3.4 -3.6)" />
      </g>
    </g>
  );
}

function Strawberry({ side }) {
  const seeds = [[-3.6, -2], [0, -3.4], [3.6, -2], [-2, 1.8], [2, 1.8], [0, 5.4], [-4.8, 2.6], [4.8, 2.6]];
  return (
    <g>
      <path d={`M0 0Q${side * 7} 3 ${side * 8} 12`} stroke="#5aa865" strokeWidth="1.8" fill="none" strokeLinecap="round" />
      <g transform={`translate(${side * 8} 21) rotate(${side * -10})`}>
        <path d="M0 -8C7 -9 11 -3 8.6 3.6C6.6 9 2.6 12 0 12C-2.6 12 -6.6 9 -8.6 3.6C-11 -3 -7 -9 0 -8Z" fill="#ef4c5c" />
        <path d="M0 -8C7 -9 11 -3 8.6 3.6C6.6 9 2.6 12 0 12Z" fill="#da3c4f" />
        {seeds.map(([x, y], i) => <ellipse key={i} cx={x} cy={y} rx="0.8" ry="1.2" fill="#ffe3a0" />)}
        <path d={star(5, 6.4, 2.6, -8)} fill="#5aa865" />
        <ellipse cx="-4.4" cy="-3" rx="1.6" ry="2.6" fill="#fff" opacity="0.3" transform="rotate(25 -4.4 -3)" />
      </g>
    </g>
  );
}

function Blossom() {
  return (
    <g transform="translate(0 -5)">
      {[0, 72, 144, 216, 288].map((a) => (
        <circle key={a} cx="0" cy="-4.2" r="3.9" fill="#fffaf3" transform={`rotate(${a})`} />
      ))}
      <circle r="2.8" fill="#f7c948" />
    </g>
  );
}

function SparkleShape({ fill }) {
  return <path d="M0 -6Q0.9 -0.9 6 0Q0.9 0.9 0 6Q-0.9 0.9 -6 0Q-0.9 -0.9 0 -6Z" fill={fill} />;
}

/* ---------- motion helpers ---------- */

const reduced = () => typeof window !== 'undefined' && window.matchMedia?.('(prefers-reduced-motion: reduce)').matches;

function useTweened(target, ms = 800) {
  const [v, setV] = useState(target);
  const cur = useRef(target);
  useEffect(() => {
    const from = cur.current;
    if (from === target) return undefined;
    if (reduced()) { cur.current = target; setV(target); return undefined; }
    let raf;
    const start = performance.now();
    const step = (now) => {
      const k = Math.min(1, (now - start) / ms);
      const val = from + (target - from) * easeOut(k);
      cur.current = val;
      setV(val);
      if (k < 1) raf = requestAnimationFrame(step);
    };
    raf = requestAnimationFrame(step);
    return () => cancelAnimationFrame(raf);
  }, [target, ms]);
  return v;
}

const PARTICLES = [
  { a: -165, d: 38, type: 'leaf' },
  { a: -130, d: 46, type: 'spark' },
  { a: -92, d: 40, type: 'leaf' },
  { a: -52, d: 46, type: 'spark' },
  { a: -15, d: 38, type: 'leaf' },
  { a: -112, d: 26, type: 'dot' },
  { a: -70, d: 28, type: 'dot' },
];

/* ---------- component ---------- */

export default function Plant({ progress = 0, kind = 'sunflower', size = 140, grow = false, label }) {
  const kindKey = KINDS[kind] ? kind : 'sunflower';
  const k = KINDS[kindKey];
  const c = colorsOf(k);
  const target = clamp(Number(progress) || 0, 0, 100);
  const p = useTweened(target);
  const stage = stageOf(target, kindKey);

  const [burst, setBurst] = useState(0);
  useEffect(() => { if (grow) setBurst((b) => b + 1); }, [grow]);
  const [delay] = useState(() => `${-(Math.random() * 4).toFixed(2)}s`);

  // Stem
  const H = p > 0 ? k.h * (18 + 104 * (p / 100)) : 0;
  const bend = Math.min(6, H * 0.07);
  const B = BASE;
  const T = { x: B.x + bend, y: B.y - H };
  const C = { x: B.x - bend * 1.1, y: B.y - H * 0.5 };
  const sw = 3.2 + 3.4 * ramp(p, 0, 100);
  const tip = quad(B, C, T, 1);
  const growK = 0.82 + 0.18 * ramp(p, 20, 100);
  const bloom = p >= 99.95;

  const leafAngle = (f, side) => {
    const v = k.ang[0] - f * k.ang[1];
    return -90 + side * v;
  };

  const leafList = kindKey === 'tulip' ? TULIP_LEAVES : kindKey === 'strawberry' ? STRAW_LEAVES : LEAVES;
  const leaves = leafList.map((l, i) => {
    const g = easeOut(ramp(p, l.t, l.t + 10));
    if (g <= 0) return null;
    const pt = quad(B, C, T, l.f);
    return (
      <Leaf key={i} x={pt.x} y={pt.y} a={l.v != null ? -90 + l.side * l.v : leafAngle(l.f, l.side)} s={l.s * g * growK} flip={l.side < 0} pet={l.v != null ? 0.95 : 0.32}
        shape={k.leaf} L={k.L} W={k.W} c={c} />
    );
  });

  // Side branches (lemon, strawberry, lavender)
  const branchEnds = [];
  const branches = k.branch ? BRANCHES.map((b, i) => {
    const g = easeOut(ramp(p, b.t, b.t + 14));
    if (g <= 0) return null;
    const A = quad(B, C, T, b.f);
    const len = k.branch.len * g * growK;
    const ang = rad(-90 + b.side * k.branch.v);
    const E = { x: A.x + Math.cos(ang) * len, y: A.y + Math.sin(ang) * len };
    const M = { x: (A.x + E.x) / 2 - b.side * len * 0.12, y: (A.y + E.y) / 2 - len * 0.16 };
    const end = quad(A, M, E, 1);
    branchEnds[i] = { ...end, g, side: b.side };
    const leafy = kindKey === 'lemon';
    return (
      <g key={i}>
        <path d={`M${r1(A.x)} ${r1(A.y)}Q${r1(M.x)} ${r1(M.y)} ${r1(E.x)} ${r1(E.y)}`} stroke={c.stem} strokeWidth={r1(sw * 0.72)} fill="none" strokeLinecap="round" />
        {leafy && (
          <>
            <Leaf x={E.x} y={E.y} a={end.a - 30} s={0.72 * g} shape={k.leaf} L={k.L} W={k.W} c={c} flip={false} />
            <Leaf x={E.x} y={E.y} a={end.a + 30} s={0.64 * g} shape={k.leaf} L={k.L} W={k.W} c={c} flip />
          </>
        )}
        {kindKey === 'lavender' && (
          <Leaf x={(A.x + E.x) / 2} y={(A.y + E.y) / 2} a={-90 + b.side * 40} s={0.6 * g} flip={b.side < 0}
            shape={k.leaf} L={k.L} W={k.W} c={c} />
        )}
      </g>
    );
  }) : null;

  // Lemon tree: a soft round canopy fills in behind the leaves as it matures.
  const cg = easeOut(ramp(p, 42, 80));
  const cpt = quad(B, C, T, 0.72);
  const canopy = cg > 0 ? (
    <g transform={`translate(${r1(cpt.x)} ${r1(cpt.y)}) scale(${r1(cg * growK * 100) / 100})`} fill="#3f9657">
      <circle cx="0" cy="-4" r="27" />
      <circle cx="-22" cy="8" r="19" />
      <circle cx="22" cy="6" r="20" />
    </g>
  ) : null;

  // Crown: the pair of young leaves at the tip (the two baby leaves while a sprout)
  const cs = (p < 20 ? 0.5 + 0.38 * ramp(p, 1, 19) : 0.82 - 0.3 * ramp(p, 70, 100))
    * (kindKey === 'tulip' ? 1 - ramp(p, 24, 44) : 1);
  const cv = 58 - 22 * ramp(p, 1, 40);
  const crownShape = kindKey === 'lavender' || kindKey === 'tulip' ? 'pointed' : 'round';
  const crownW = kindKey === 'tulip' ? 8.5 : kindKey === 'lavender' ? 7 : 11.5;
  const crown = p > 0 && !(bloom && kindKey === 'sunflower') ? (
    <g>
      <Leaf x={tip.x} y={tip.y} a={tip.a - cv} s={cs} shape={crownShape} L={30} W={crownW} c={c} flip />
      <Leaf x={tip.x} y={tip.y} a={tip.a + cv} s={cs * 0.94} shape={crownShape} L={30} W={crownW} c={c} flip={false} />
    </g>
  ) : null;

  // Bud / bloom points: tip first, then branch ends
  const points = [{ ...tip, side: 1 }, branchEnds[0], branchEnds[1]].filter(Boolean);
  const fruit = FRUIT_KINDS.includes(kindKey);
  const flowerOnPoint = (pt, i) => {
    const rot = pt.a + 90;
    if (!bloom) {
      const g = easeOut(ramp(p, BUD_T[i], BUD_T[i] + 10));
      if (g <= 0 || (i > 0 && (kindKey === 'sunflower' || kindKey === 'tulip'))) return null;
      const s = k.bs * g * (0.72 + 0.34 * ramp(p, 70, 99)) * (i ? 0.85 : 1);
      return (
        <g key={`bud${i}`} transform={`translate(${r1(pt.x)} ${r1(pt.y)}) rotate(${r1(rot)}) scale(${r1(s * 100) / 100})`}>
          <Bud kind={kindKey} ripe={ramp(p, 70, 99)} />
        </g>
      );
    }
    let el;
    if (kindKey === 'sunflower') el = i === 0 ? <Sunflower /> : null;
    else if (kindKey === 'tulip') el = i === 0 ? <Tulip /> : null;
    else if (kindKey === 'lavender') el = <Lavender />;
    else if (kindKey === 'lemon') el = <Lemon side={i === 0 ? 1 : pt.side} />;
    else el = i === 0 ? <Blossom /> : <Strawberry side={pt.side} />;
    if (!el) return null;
    const tr = `translate(${r1(pt.x)} ${r1(pt.y)})${fruit ? '' : ` rotate(${r1(rot)})`} scale(${k.bs})`;
    return (
      <g key={`bl${i}`} transform={tr}>
        <g className="plant-bloom" style={{ animationDelay: `${i * 90}ms` }}>{el}</g>
      </g>
    );
  };

  const seedFade = 1 - ramp(p, 0.5, 9);
  const top = { x: tip.x, y: tip.y };

  const aria = `${label || 'Plant'}: ${stage.name}, ${Math.round(target)}% grown`;

  return (
    <svg className="plant" role="img" aria-label={aria} viewBox="0 0 200 230" width={size} height={Math.round(size * 1.15)}>
      {/* ground shadow */}
      <ellipse cx="100" cy="223" rx="38" ry="4" fill="#000" opacity="0.07" />

      {/* pot */}
      <g transform="translate(100 222) scale(0.86) translate(-100 -222)">
      <path d="M61 170L139 170L130.6 215.6Q129.6 222 123.4 222L76.6 222Q70.4 222 69.4 215.6Z" fill="var(--plant-pot, #e5896b)" />
      <path d="M113 170L139 170L130.6 215.6Q129.6 222 123.4 222L110 222Q114 196 113 170Z" fill="#000" opacity="0.06" />
      <path d="M60.6 174L139.4 174L138.5 180L61.5 180Z" fill="#b85f46" opacity="0.28" />
      <path d="M73.5 185Q75 184 76.4 185L74.8 208Q74 210 72.6 208Z" fill="#fff" opacity="0.28" />
      <rect x="54" y="158" width="92" height="17" rx="6.5" fill="var(--plant-rim, #ee9a7c)" />
      <ellipse cx="100" cy="159" rx="46" ry="8.6" fill="var(--plant-rim-top, #f4ad90)" />
      <ellipse cx="100" cy="159.6" rx="39.5" ry="6.2" fill="#6d4636" />
      <path d="M60.5 159.6A39.5 6.2 0 0 1 139.5 159.6Q100 156 60.5 159.6Z" fill="#583727" />
      <path d="M59 165Q60 168.5 62 170" stroke="#fff" strokeOpacity="0.4" strokeWidth="2" fill="none" strokeLinecap="round" />
      </g>

      {/* seed */}
      {seedFade > 0 && (
        <g opacity={r1(seedFade)} transform={`translate(${r1(100 + 10 * (1 - seedFade))} ${r1(166 + 1.5 * (1 - seedFade))}) rotate(-18)`}>
          <ellipse rx="9.6" ry="6.6" fill="#dca46a" />
          <path d="M-9.6 0A9.6 6.6 0 0 0 9.6 0Z" fill="#c68b53" />
          <ellipse cx="-3.4" cy="-2.6" rx="2.8" ry="1.4" fill="#f3cf9f" opacity="0.9" />
        </g>
      )}

      {/* plant */}
      {p > 0 && (
        <g className="plant-sway" style={{ animationDelay: delay }}>
          <g key={burst} className={burst ? 'plant-body plant-grow' : 'plant-body'}>
            {kindKey === 'lemon' && canopy}
            {branches}
            <path d={`M${B.x} ${B.y}Q${r1(C.x)} ${r1(C.y)} ${r1(T.x)} ${r1(T.y)}`} stroke={c.stem} strokeWidth={r1(sw)} fill="none" strokeLinecap="round" />
            {leaves}
            {crown}
            {points.map(flowerOnPoint)}
          </g>
        </g>
      )}

      {/* sparkles once fully grown */}
      {bloom && (
        <g>
          {[
            { x: top.x - 42, y: top.y + 6, s: 0.9, f: '#f7c948', d: 0 },
            { x: top.x + 44, y: top.y - 10, s: 0.7, f: '#b4a2ff', d: 1.2 },
            { x: top.x + 50, y: Math.min(top.y + 52, 116), s: 0.62, f: '#f7c948', d: 2.1 },
          ].map((s, i) => (
            <g key={i} transform={`translate(${r1(s.x)} ${r1(s.y)}) scale(${s.s})`}>
              <g className="plant-twinkle" style={{ animationDelay: `${s.d}s` }}><SparkleShape fill={s.f} /></g>
            </g>
          ))}
        </g>
      )}

      {/* growth burst */}
      {burst > 0 && (
        <g key={`p${burst}`} transform={`translate(${r1(top.x)} ${r1(top.y + 6)})`}>
          {PARTICLES.map((pt, i) => {
            const dx = r1(Math.cos(rad(pt.a)) * pt.d);
            const dy = r1(Math.sin(rad(pt.a)) * pt.d);
            return (
              <g key={i} className="plant-particle" style={{ '--dx': `${dx}px`, '--dy': `${dy}px`, '--rot': `${pt.a + 90}deg`, animationDelay: `${i * 35}ms` }}>
                {pt.type === 'leaf' && <path d="M0 0C3 -4.5 9 -4.5 12 0C9 4.5 3 4.5 0 0Z" fill={c.leaf} transform="translate(-6 0)" />}
                {pt.type === 'spark' && <g transform="scale(1.05)"><SparkleShape fill="#f7c948" /></g>}
                {pt.type === 'dot' && <circle r="2.4" fill="#9dd6a4" />}
              </g>
            );
          })}
        </g>
      )}
    </svg>
  );
}
