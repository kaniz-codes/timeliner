// The user manual, told by Miso. A help button opens the chapters; "Show me" runs a tour on the real page.
import { useEffect, useState } from 'react';
import { X, ChevronDown, PlayCircle } from 'lucide-react';
import { Cat, catEnabled } from './Cat.jsx';
import { startTour } from './Tour.jsx';
import { CHAPTERS } from '../lib/guide.js';
import { play } from '../lib/sound.js';
import './miso-guide.css';

export const openGuide = () => window.dispatchEvent(new Event('mindmap:guide'));

export default function MisoGuide() {
  const [open, setOpen] = useState(false);
  const [openId, setOpenId] = useState('start');
  const [, setCatTick] = useState(0);

  useEffect(() => {
    const show = () => setOpen(true);
    const rerender = () => setCatTick((n) => n + 1);
    window.addEventListener('mindmap:guide', show);
    window.addEventListener('mindmap:cat', rerender);
    return () => { window.removeEventListener('mindmap:guide', show); window.removeEventListener('mindmap:cat', rerender); };
  }, []);
  useEffect(() => {
    if (!open) return;
    const esc = (e) => e.key === 'Escape' && setOpen(false);
    window.addEventListener('keydown', esc);
    return () => window.removeEventListener('keydown', esc);
  }, [open]);

  const showMe = (c) => {
    play('tap');
    setOpen(false);
    startTour(c.tour);
  };

  return (
    <>
      <button className="guide-btn" data-tour="guide" onClick={() => { play('tap'); setOpen(true); }} aria-label="Open Miso's guide" title="How to use MIND MAP">
        {catEnabled() ? <Cat mood="happy" size={46} /> : <span className="guide-q">?</span>}
      </button>

      {open && (
        <div className="overlay guide-overlay" onMouseDown={(e) => e.target === e.currentTarget && setOpen(false)}>
          <aside className="guide" role="dialog" aria-modal="true" aria-label="How to use MIND MAP">
            <div className="guide-head">
              <Cat mood="wave" size={60} />
              <div className="grow">
                <h2>Miso's guide</h2>
                <p className="small muted keep">How to use MIND MAP, step by step.</p>
              </div>
              <button className="btn ghost icon sm" onClick={() => setOpen(false)} aria-label="Close guide"><X size={18} /></button>
            </div>
            <div className="guide-list">
              {CHAPTERS.map((c, n) => {
                const isOpen = openId === c.id;
                return (
                  <section key={c.id} className={`guide-ch ${isOpen ? 'open' : ''}`}>
                    <button className="guide-ch-head" onClick={() => setOpenId(isOpen ? null : c.id)} aria-expanded={isOpen}>
                      <span className="guide-num">{n + 1}</span>
                      <span className="grow">{c.title}</span>
                      <ChevronDown size={17} className="guide-chev" />
                    </button>
                    {isOpen && (
                      <div className="guide-ch-body">
                        <ol>{c.steps.map((s) => <li key={s}>{s}</li>)}</ol>
                        <button className="btn soft sm" onClick={() => showMe(c)}><PlayCircle size={16} />Show me</button>
                      </div>
                    )}
                  </section>
                );
              })}
            </div>
          </aside>
        </div>
      )}
    </>
  );
}
