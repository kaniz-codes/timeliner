import { useEffect, useState } from 'react';
import { X } from 'lucide-react';
import './cat.css';

// Miso, the MIND MAP cat. Pure inline SVG; all motion lives in cat.css.
export const CAT_ON_KEY = 'mindmap.cat';
export const catEnabled = () => localStorage.getItem(CAT_ON_KEY) !== 'off';
export const setCatEnabled = (on) => {
  localStorage.setItem(CAT_ON_KEY, on ? 'on' : 'off');
  window.dispatchEvent(new Event('mindmap:cat'));
};

const C = {
  fur: '#f6b477',
  stripe: '#e48c4c',
  cream: '#fff4e6',
  line: '#9c5a33',
  eye: '#3a2622',
  ear: '#f6a3a0',
  nose: '#ec8580',
  blush: '#ff8fa3',
  mouth: '#7a3b2e',
  heart: '#f0567a',
  gold: '#ffc44d',
};
const LINE = { stroke: C.line, strokeWidth: 2.2, strokeLinejoin: 'round', strokeLinecap: 'round' };

// A limb drawn as an outlined thick stroke with a round paw at the end.
function Limb({ d, paw, className, small = false }) {
  const w = small ? 8 : 9;
  return (
    <g className={className}>
      <path d={d} fill="none" stroke={C.line} strokeWidth={w + 4.4} strokeLinecap="round" />
      <path d={d} fill="none" stroke={C.fur} strokeWidth={w} strokeLinecap="round" />
      <ellipse cx={paw[0]} cy={paw[1]} rx={small ? 5.8 : 6.6} ry={small ? 5.2 : 6.2} fill={C.fur} {...LINE} />
    </g>
  );
}

function Heart({ x, y, s = 1, fill = C.heart, className }) {
  return (
    <g transform={`translate(${x} ${y}) scale(${s})`}><path className={className} fill={fill}
      d="M0 3.2C-1.4 1.4-4.6 0.2-4.6-2.4c0-1.6 1.2-2.8 2.6-2.8 1 0 1.6 0.5 2 1.2 0.4-0.7 1-1.2 2-1.2 1.4 0 2.6 1.2 2.6 2.8 0 2.6-3.2 3.8-4.6 5.6Z" /></g>
  );
}

function Sparkle({ x, y, s = 1, fill = C.gold, className, style }) {
  return (
    <g transform={`translate(${x} ${y}) scale(${s})`}><path className={className} style={style} fill={fill}
      d="M0-6C0.6-2 2-0.6 6 0 2 0.6 0.6 2 0 6-0.6 2-2 0.6-6 0-2-0.6-0.6-2 0-6Z" /></g>
  );
}

function Eyes({ mood }) {
  if (mood === 'cheer') {
    return (
      <g fill="none" stroke={C.eye} strokeWidth={2.8} strokeLinecap="round">
        <path d="M40.5 56 Q46 49.5 51.5 56" />
        <path d="M68.5 56 Q74 49.5 79.5 56" />
      </g>
    );
  }
  if (mood === 'sleepy') {
    return (
      <g fill="none" stroke={C.eye} strokeWidth={2.4} strokeLinecap="round">
        <path d="M41 54.5 Q46 58.5 51 54.5" />
        <path d="M69 54.5 Q74 58.5 79 54.5" />
      </g>
    );
  }
  if (mood === 'love') {
    return (
      <g className="cat-hearteyes">
        <Heart x={46} y={54.5} s={1.45} />
        <Heart x={74} y={54.5} s={1.45} />
        <circle cx={43.6} cy={51.2} r={1.1} fill="#fff" opacity={0.9} />
        <circle cx={71.6} cy={51.2} r={1.1} fill="#fff" opacity={0.9} />
      </g>
    );
  }
  // Open eyes (happy / wave / think / sad). `think` looks up, `sad` looks a little down.
  const dy = mood === 'think' ? -2.2 : mood === 'sad' ? 1 : 0;
  const dx = mood === 'think' ? 1.2 : 0;
  const ry = mood === 'sad' ? 5.8 : 6.4;
  return (
    <g className="cat-eyes">
      {[46, 74].map((x) => (
        <g key={x} transform={`translate(${x + dx} ${54 + dy})`}>
          <ellipse rx={5.4} ry={ry} fill={C.eye} />
          <circle cx={-1.7} cy={-2.3} r={2.1} fill="#fff" />
          <circle cx={1.9} cy={2.2} r={0.95} fill="#fff" opacity={0.85} />
        </g>
      ))}
    </g>
  );
}

function Mouth({ mood }) {
  const s = { fill: 'none', stroke: C.mouth, strokeWidth: 1.7, strokeLinecap: 'round', strokeLinejoin: 'round' };
  if (mood === 'cheer' || mood === 'love' || mood === 'wave') {
    return (
      <g>
        <path d="M54.6 64.4 Q60 64.9 65.4 64.4 Q64.6 71.2 60 71.2 Q55.4 71.2 54.6 64.4Z" fill={C.mouth} stroke={C.mouth} strokeWidth={1.2} strokeLinejoin="round" />
        <path d="M56.8 69.2 Q60 66.6 63.2 69.2 Q61.8 71 60 71 Q58.2 71 56.8 69.2Z" fill="#f27f86" />
      </g>
    );
  }
  if (mood === 'sad') return <path d="M56 67.6 Q60 64.4 64 67.6" {...s} />;
  if (mood === 'think') return <path d="M57.5 66.4 Q60.5 65.4 63.5 66.8" {...s} />;
  if (mood === 'sleepy') return <path d="M57 64.6 Q58.5 66.4 60 64.8 Q61.5 66.4 63 64.6" {...s} />;
  return <path d="M54.6 64.3 Q57.3 68 60 64.6 Q62.7 68 65.4 64.3" {...s} />;
}

export function Cat({ mood = 'happy', size = 72 }) {
  const armsUp = mood === 'cheer';
  return (
    <svg className={`cat cat--${mood}`} width={size} height={size} viewBox="0 0 120 120"
      role="img" aria-label="Miso the cat">
      <ellipse cx={60} cy={114} rx={30} ry={3.6} className="cat-shadow" />

      <g className="cat-bob">
        {/* Tail (behind the body) */}
        <g className="cat-tail">
          <path d="M44 107 C30 109 17 103 15 91 C13.8 84 14.6 78.5 18.5 73.5" fill="none" stroke={C.line} strokeWidth={13.4} strokeLinecap="round" />
          <path d="M44 107 C30 109 17 103 15 91 C13.8 84 14.6 78.5 18.5 73.5" fill="none" stroke={C.fur} strokeWidth={9} strokeLinecap="round" />
          <path d="M12.4 86.4 l6.4 0.4 M15.4 97.4 l6 -2.8" stroke={C.stripe} strokeWidth={3} strokeLinecap="round" />
        </g>

        {/* Body */}
        <ellipse cx={60} cy={93} rx={28} ry={20} fill={C.fur} {...LINE} />
        <ellipse cx={60} cy={97} rx={15.5} ry={13} fill={C.cream} />
        <path d="M33.6 88 l6 1.4 M33 95 l5.6 0.4 M86.4 88 l-6 1.4 M87 95 l-5.6 0.4" stroke={C.stripe} strokeWidth={3} strokeLinecap="round" />

        {/* Feet */}
        {[47, 73].map((x) => (
          <g key={x}>
            <ellipse cx={x} cy={110.5} rx={9} ry={5.4} fill={C.cream} {...LINE} />
            <path d={`M${x - 2.6} 108.6 v2.6 M${x + 2.6} 108.6 v2.6`} stroke={C.line} strokeWidth={1.4} strokeLinecap="round" opacity={0.55} />
          </g>
        ))}

        {/* Resting paws sit under the head so the arm tops tuck away */}
        {mood !== 'cheer' && <Limb d="M42 80 Q43.5 93 51 98" paw={[52, 98]} small />}
        {mood !== 'cheer' && mood !== 'wave' && mood !== 'think' && <Limb d="M78 80 Q76.5 93 69 98" paw={[68, 98]} small />}

        {/* Head */}
        <g className="cat-head">
          <g className="cat-ear cat-ear--l">
            <path d="M25.5 40 Q25 19 29.5 14.2 Q32.6 11.4 37.6 14.6 L53 26.5 Z" fill={C.fur} {...LINE} />
            <path d="M31.4 31.6 Q31 21.4 33.2 19.2 Q34.8 18 37 19.6 L45 25.6 Z" fill={C.ear} />
          </g>
          <g className="cat-ear cat-ear--r">
            <path d="M94.5 40 Q95 19 90.5 14.2 Q87.4 11.4 82.4 14.6 L67 26.5 Z" fill={C.fur} {...LINE} />
            <path d="M88.6 31.6 Q89 21.4 86.8 19.2 Q85.2 18 83 19.6 L75 25.6 Z" fill={C.ear} />
          </g>
          <ellipse cx={60} cy={52} rx={37} ry={30} fill={C.fur} {...LINE} />
          <path d="M60 23.6 v7 M52.4 24.8 l1.4 5.8 M67.6 24.8 l-1.4 5.8" stroke={C.stripe} strokeWidth={3.2} strokeLinecap="round" />
          <path d="M23.8 48.6 l6.2 1.4 M23.6 55 l5.6 0.2 M96.2 48.6 l-6.2 1.4 M96.4 55 l-5.6 0.2" stroke={C.stripe} strokeWidth={3} strokeLinecap="round" />
          <ellipse cx={60} cy={65.5} rx={12.5} ry={8.6} fill={C.cream} />
          <ellipse cx={35.5} cy={63.5} rx={mood === 'love' ? 6.4 : 5.6} ry={3.3} fill={C.blush} opacity={mood === 'love' ? 0.7 : 0.5} />
          <ellipse cx={84.5} cy={63.5} rx={mood === 'love' ? 6.4 : 5.6} ry={3.3} fill={C.blush} opacity={mood === 'love' ? 0.7 : 0.5} />
          <path d="M27 62 l-8.6 -2 M27.4 66.4 l-8 1.2 M93 62 l8.6 -2 M92.6 66.4 l8 1.2" stroke={C.line} strokeWidth={1.3} strokeLinecap="round" opacity={0.45} />
          {mood === 'sad' && (
            <path d="M40.6 45.2 Q45 42.4 49.8 43.4 M79.4 45.2 Q75 42.4 70.2 43.4" fill="none" stroke={C.line} strokeWidth={1.9} strokeLinecap="round" opacity={0.75} />
          )}
          <Eyes mood={mood} />
          <path d="M56.8 60.2 Q60 58.9 63.2 60.2 Q62.6 62.7 60 63.7 Q57.4 62.7 56.8 60.2Z" fill={C.nose} stroke={C.nose} strokeWidth={0.8} strokeLinejoin="round" />
          <Mouth mood={mood} />
        </g>

        {/* Front paws / arms per mood */}
        {mood === 'wave' && (
          <>
            <Limb className="cat-arm-wave" d="M80 90 Q93 82 99 63" paw={[99.5, 61]} />
          </>
        )}
        {armsUp && (
          <>
            <Limb className="cat-arm-l" d="M40 90 Q27 82 21 63" paw={[20.5, 61]} />
            <Limb className="cat-arm-r" d="M80 90 Q93 82 99 63" paw={[99.5, 61]} />
          </>
        )}
        {mood === 'think' && (
          <>
            <Limb d="M78 94 Q76 84 70.5 80.5" paw={[69.5, 79.5]} />
          </>
        )}
      </g>

      {/* Mood extras */}
      {mood === 'cheer' && (
        <g className="cat-sparkles">
          <Sparkle x={12} y={30} s={0.9} style={{ '--d': '0.15s' }} />
          <Sparkle x={108} y={24} s={1.1} fill="#b79cff" style={{ '--d': '0.3s' }} />
          <Sparkle x={104} y={92} s={0.7} style={{ '--d': '0.45s' }} />
          <Sparkle x={10} y={86} s={0.6} fill="#b79cff" style={{ '--d': '0.6s' }} />
        </g>
      )}
      {mood === 'sleepy' && (
        <g className="cat-zzz" fill="#a49cf0" fontFamily="var(--font-display)" fontWeight="800">
          <text x={93} y={25} fontSize={16} style={{ '--d': '0s' }}>z</text>
          <text x={104} y={12} fontSize={11} style={{ '--d': '1.3s' }}>z</text>
        </g>
      )}
      {mood === 'love' && <Heart className="cat-float-heart" x={106} y={25} s={1.6} />}
      {mood === 'think' && (
        <g className="cat-thought" fill="#b79cff">
          <circle cx={97} cy={22} r={2.2} style={{ '--d': '0.1s' }} />
          <circle cx={104} cy={14} r={3} style={{ '--d': '0.35s' }} />
          <circle cx={112.5} cy={5.5} r={3.8} style={{ '--d': '0.6s' }} />
        </g>
      )}
    </svg>
  );
}

function useCatEnabled() {
  const [on, setOn] = useState(catEnabled);
  useEffect(() => {
    const sync = () => setOn(catEnabled());
    window.addEventListener('mindmap:cat', sync);
    window.addEventListener('storage', sync);
    return () => {
      window.removeEventListener('mindmap:cat', sync);
      window.removeEventListener('storage', sync);
    };
  }, []);
  return on;
}

export function CatGuide({ message, mood = 'happy', size = 64, onClose, action, compact = false }) {
  const on = useCatEnabled();
  if (!on) return null;
  return (
    <div className={`cat-guide${compact ? ' compact' : ''}`}>
      <Cat mood={mood} size={compact ? 40 : size} />
      <div className="cat-bubble">
        <div className="cat-bubble-body">
          <p className="cat-msg" title={compact ? message : undefined}>{message}</p>
          {action && (
            <button type="button" className="btn xs soft cat-action" onClick={action.onClick}>{action.label}</button>
          )}
        </div>
        {onClose && (
          <button type="button" className="cat-close" onClick={onClose} aria-label="Dismiss Miso">
            <X size={14} strokeWidth={2.4} />
          </button>
        )}
      </div>
    </div>
  );
}
