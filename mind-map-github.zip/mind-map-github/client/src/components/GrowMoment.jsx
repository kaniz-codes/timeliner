// When a goal task is finished, that goal's plant grows on screen for a moment.
// At 100% the plant blooms and Miso cheers.
import { useEffect, useState } from 'react';
import Plant, { plantKindFor, stageOf } from './Plant.jsx';
import { Cat, catEnabled } from './Cat.jsx';
import { play } from '../lib/sound.js';
import { useApp } from '../lib/app.jsx';
import './grow-moment.css';

export default function GrowMoment() {
  const { uncompleteTask } = useApp();
  const [m, setM] = useState(null);
  const [shown, setShown] = useState(0);
  const [grow, setGrow] = useState(false);

  useEffect(() => {
    const on = (e) => {
      const d = e.detail;
      setM(d);
      setShown(d.before ?? d.progress);
      setGrow(false);
      // Let the plant render at the old size first, then grow to the new one.
      setTimeout(() => {
        setShown(d.progress);
        setGrow(true);
        const k = plantKindFor(d.id);
        const up = stageOf(d.progress, k).index > stageOf(d.before ?? 0, k).index;
        play(d.progress >= 100 ? 'bloom' : up ? 'levelup' : 'grow');
      }, 250);
      setTimeout(() => setGrow(false), 1300);
    };
    window.addEventListener('mindmap:grow', on);
    return () => window.removeEventListener('mindmap:grow', on);
  }, []);

  useEffect(() => {
    if (!m || m.progress >= 100) return;
    const id = setTimeout(() => setM(null), 3800);
    return () => clearTimeout(id);
  }, [m]);

  if (!m) return null;
  const kind = plantKindFor(m.id);
  const before = stageOf(m.before ?? 0, kind);
  const after = stageOf(m.progress, kind);
  const levelUp = after.index > before.index;

  if (m.progress >= 100) {
    return (
      <div className="overlay" onMouseDown={(e) => e.target === e.currentTarget && setM(null)}>
        <div className="modal bloom" role="dialog" aria-modal="true" aria-label="Goal complete">
          <div className="bloom-art">
            <Plant progress={shown} kind={kind} size={200} grow={grow} label={m.title} />
            {catEnabled() && <div className="bloom-cat"><Cat mood="cheer" size={92} /></div>}
          </div>
          <h2>Goal complete!</h2>
          <p className="muted">{m.title} is fully grown. {after.name === 'Fruiting' ? 'Look at all that fruit.' : 'It is in full bloom.'}</p>
          <div className="row" style={{ justifyContent: 'center' }}>
            {m.taskRef && <button className="btn ghost" onClick={() => { setM(null); uncompleteTask(m.taskRef); }}>Undo</button>}
            <button className="btn primary" autoFocus onClick={() => setM(null)}>Yay!</button>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="grow-moment" role="status" aria-live="polite" onClick={() => setM(null)}>
      <Plant progress={shown} kind={kind} size={72} grow={grow} label={m.title} />
      <div className="grow">
        <div className="strong">{levelUp ? `New stage: ${after.name}!` : m.combo >= 2 ? `${m.combo} in a row! Your plant grew` : 'Your plant grew'}</div>
        <div className="small muted truncate">{m.title}</div>
        <div className="grow-bar"><i style={{ width: `${shown}%` }} /></div>
        <div className="tiny muted">{m.progress}% grown{after.next ? ` · ${after.next.name} at ${after.next.min}%` : ''}</div>
      </div>
      {m.taskRef && (
        <button className="btn xs soft" onClick={(e) => { e.stopPropagation(); setM(null); uncompleteTask(m.taskRef); }}>Undo</button>
      )}
    </div>
  );
}
