// Shared dialogs opened through useApp().openDialog(type, props).
// Types: 'class' | 'task' | 'goal' | 'activity' | 'reminder' | 'reschedule'
import { useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { Sparkles, MessageCircle, CalendarClock, Scissors, AlertTriangle, Clock, CalendarDays } from 'lucide-react';
import { api } from '../lib/api.js';
import { useApp } from '../lib/app.jsx';
import { Modal, Field, Spinner, PriorityBadge } from './ui.jsx';
import { DAYS, fmtDuration, fmtDue, fmtSlot, fmtDate, today, addMinutesDt } from '../lib/format.js';

export const ACTIVITY_CATEGORIES = ['Club activity', 'Competition', 'Workshop', 'Seminar', 'Hackathon', 'Volunteer work', 'Sports', 'Cultural event', 'Career fair', 'Other'];
export const ACTIVITY_STATUSES = ['interested', 'registered', 'upcoming', 'completed', 'cancelled'];

function useForm(initial) {
  const [v, setV] = useState(initial);
  const bind = (k) => ({ value: v[k] ?? '', onChange: (e) => setV((s) => ({ ...s, [k]: e.target.value })) });
  return [v, setV, bind];
}

function Footer({ onClose, saving, label = 'Save', onDelete }) {
  return (
    <>
      {onDelete && <button type="button" className="btn danger" onClick={onDelete} style={{ marginRight: 'auto' }}>Delete</button>}
      <button type="button" className="btn ghost" onClick={onClose}>Cancel</button>
      <button type="submit" form="dialog-form" className="btn primary" disabled={saving}>{saving ? 'Saving…' : label}</button>
    </>
  );
}

function useSubmit(fn) {
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState(null);
  const submit = async (e) => {
    e?.preventDefault();
    setSaving(true);
    setError(null);
    try {
      await fn();
    } catch (err) {
      setError(err.message);
    } finally {
      setSaving(false);
    }
  };
  return { saving, error, submit };
}

export function ClassDialog({ initial, onClose, onSaved }) {
  const { refresh, toast } = useApp();
  const editing = !!initial?.id;
  const [v, , bind] = useForm({ course_code: '', title: '', day: String(new Date().getDay()), start_time: '09:00', end_time: '10:30', room: '', instructor: '', recurring: 'weekly', ...initial });
  const { saving, error, submit } = useSubmit(async () => {
    const body = { ...v, day: Number(v.day) };
    const r = editing ? await api.put(`/classes/${initial.id}`, body) : await api.post('/classes', body);
    refresh();
    toast(editing ? 'Class updated' : `${r.class.course_code} added every ${DAYS[r.class.day]}`);
    onSaved?.(r.class);
    onClose();
  });
  const del = async () => {
    await api.del(`/classes/${initial.id}`);
    refresh();
    toast('Class removed', 'info');
    onClose();
  };
  return (
    <Modal title={editing ? 'Edit class' : 'Add a class'} onClose={onClose} footer={<Footer onClose={onClose} saving={saving} onDelete={editing ? del : null} label={editing ? 'Save' : 'Add class'} />}>
      <form id="dialog-form" onSubmit={submit} className="form-grid">
        {error && <div className="form-error full">{error}</div>}
        <Field label="Course code"><input className="input" placeholder="CSE 327" autoFocus {...bind('course_code')} required /></Field>
        <Field label="Course title"><input className="input" placeholder="Software Engineering" {...bind('title')} /></Field>
        <Field label="Day">
          <select className="select" {...bind('day')}>{DAYS.map((d, i) => <option key={d} value={i}>{d}</option>)}</select>
        </Field>
        <Field label="Repeats">
          <select className="select" {...bind('recurring')}><option value="weekly">Every week</option></select>
        </Field>
        <Field label="Starts"><input type="time" className="input" {...bind('start_time')} required /></Field>
        <Field label="Ends"><input type="time" className="input" {...bind('end_time')} required /></Field>
        <Field label="Room"><input className="input" placeholder="301" {...bind('room')} /></Field>
        <Field label="Instructor"><input className="input" placeholder="Dr. Rahman" {...bind('instructor')} /></Field>
      </form>
    </Modal>
  );
}

export function TaskDialog({ initial, onClose, onSaved }) {
  const { refresh, toast } = useApp();
  const editing = !!initial?.id;
  const [goals, setGoals] = useState([]);
  useEffect(() => { api.get('/goals').then((r) => setGoals(r.goals)).catch(() => {}); }, []);
  const [v, setV, bind] = useForm({
    title: '', description: '', estimated_minutes: 60, priority: 'medium', goal_id: '',
    when: editing && initial.scheduled_start ? 'pick' : 'auto', date: initial?.scheduled_start?.slice(0, 10) || today(), time: initial?.scheduled_start?.slice(11, 16) || '18:00',
    ...initial,
    deadline: initial?.deadline?.slice(0, 10) || '',
  });
  const { saving, error, submit } = useSubmit(async () => {
    const minutes = Number(v.estimated_minutes);
    const body = {
      title: v.title, description: v.description, estimated_minutes: minutes, deadline: v.deadline || null,
      priority: v.priority, goal_id: v.goal_id ? Number(v.goal_id) : null,
    };
    if (v.when === 'pick') {
      body.scheduled_start = `${v.date}T${v.time}`;
      body.scheduled_end = addMinutesDt(body.scheduled_start, minutes);
    } else if (v.when === 'none') {
      body.scheduled_start = null;
      body.scheduled_end = null;
    }
    let r;
    if (editing) r = await api.put(`/tasks/${initial.id}`, body);
    else r = await api.post('/tasks', { ...body, auto_schedule: v.when === 'auto' });
    refresh();
    if (!editing && v.when === 'auto') {
      toast(r.placement ? `Placed in your free time: ${fmtSlot(r.placement.start, r.placement.end)}` : 'Saved. No free slot before the deadline yet.', r.placement ? 'success' : 'info');
    } else toast(editing ? 'Task updated' : 'Task added');
    onSaved?.(r.task);
    onClose();
  });
  const del = async () => {
    await api.del(`/tasks/${initial.id}`);
    refresh();
    toast('Task deleted', 'info');
    onClose();
  };
  return (
    <Modal title={editing ? 'Edit task' : 'Add a task'} onClose={onClose} footer={<Footer onClose={onClose} saving={saving} onDelete={editing ? del : null} label={editing ? 'Save' : 'Add task'} />}>
      <form id="dialog-form" onSubmit={submit} className="form-grid">
        {error && <div className="form-error full">{error}</div>}
        <Field label="Task" full><input className="input" placeholder="React assignment submission" autoFocus {...bind('title')} required /></Field>
        <Field label="Estimated time">
          <select className="select" {...bind('estimated_minutes')}>
            {[15, 30, 45, 60, 90, 120, 150, 180, 240].map((m) => <option key={m} value={m}>{fmtDuration(m)}</option>)}
          </select>
        </Field>
        <Field label="Deadline"><input type="date" className="input" {...bind('deadline')} /></Field>
        <Field label="Priority">
          <select className="select" {...bind('priority')}><option value="high">High</option><option value="medium">Medium</option><option value="low">Low</option></select>
        </Field>
        <Field label="Goal" hint="optional">
          <select className="select" {...bind('goal_id')}>
            <option value="">No goal</option>
            {goals.map((g) => <option key={g.id} value={g.id}>{g.title}</option>)}
          </select>
        </Field>
        <Field label="When" full>
          <div className="row wrap">
            {[['auto', 'Find a free slot for me'], ['pick', 'I\'ll pick a time'], ['none', 'Not scheduled']].map(([k, l]) => (
              <button type="button" key={k} className={`chip ${v.when === k ? 'active' : ''}`} onClick={() => setV((s) => ({ ...s, when: k }))}>{l}</button>
            ))}
          </div>
        </Field>
        {v.when === 'pick' && (
          <>
            <Field label="Date"><input type="date" className="input" {...bind('date')} /></Field>
            <Field label="Start"><input type="time" className="input" {...bind('time')} /></Field>
          </>
        )}
        <Field label="Notes" full><textarea className="textarea" rows={2} {...bind('description')} /></Field>
      </form>
    </Modal>
  );
}

export function GoalDialog({ initial, onClose, onSaved }) {
  const { refresh, toast } = useApp();
  const navigate = useNavigate();
  const editing = !!initial?.id;
  const [v, , bind] = useForm({
    title: '', description: '', deadline: '', current_level: 'Beginner', weekly_hours: 6, priority: 'medium',
    preferred_time: 'evening', existing_knowledge: '', budget: '', notes: '', ...initial,
  });
  const { saving, error, submit } = useSubmit(async () => {
    const body = { ...v, weekly_hours: Number(v.weekly_hours) };
    const r = editing ? await api.put(`/goals/${initial.id}`, body) : await api.post('/goals', body);
    refresh();
    toast(editing ? 'Goal updated' : 'Goal created. Next: generate a roadmap.');
    onClose();
    if (onSaved) onSaved(r.goal);
    else if (!editing) navigate(`/goals/${r.goal.id}`);
  });
  return (
    <Modal wide title={editing ? 'Edit goal' : 'Create a goal'} onClose={onClose} footer={<Footer onClose={onClose} saving={saving} label={editing ? 'Save' : 'Create goal'} />}>
      <form id="dialog-form" onSubmit={submit} className="form-grid">
        {error && <div className="form-error full">{error}</div>}
        <Field label="Goal" full><input className="input" placeholder="Become a Frontend Developer" autoFocus {...bind('title')} required /></Field>
        <Field label="Why it matters" full><textarea className="textarea" rows={2} placeholder="Land an internship by next summer" {...bind('description')} /></Field>
        <Field label="Target deadline"><input type="date" className="input" min={today()} {...bind('deadline')} /></Field>
        <Field label="Current level">
          <select className="select" {...bind('current_level')}>{['Beginner', 'Intermediate', 'Advanced'].map((l) => <option key={l}>{l}</option>)}</select>
        </Field>
        <Field label="Weekly time available" hint="hours">
          <input type="number" className="input" min={1} max={40} {...bind('weekly_hours')} />
        </Field>
        <Field label="Priority">
          <select className="select" {...bind('priority')}><option value="high">High</option><option value="medium">Medium</option><option value="low">Low</option></select>
        </Field>
        <Field label="Preferred study time">
          <select className="select" {...bind('preferred_time')}>
            <option value="morning">Morning</option><option value="afternoon">Afternoon</option><option value="evening">Evening</option><option value="any">Any time</option>
          </select>
        </Field>
        <Field label="Budget" hint="optional"><input className="input" placeholder="Free resources only" {...bind('budget')} /></Field>
        <Field label="What you already know" full><input className="input" placeholder="Basic HTML, a little JavaScript" {...bind('existing_knowledge')} /></Field>
        <Field label="Notes" full><textarea className="textarea" rows={2} {...bind('notes')} /></Field>
      </form>
    </Modal>
  );
}

export function ActivityDialog({ initial, onClose, onSaved }) {
  const { refresh, toast } = useApp();
  const editing = !!initial?.id;
  const [v, , bind] = useForm({
    title: '', category: 'Club activity', description: '', registration_deadline: '', event_date: '', start_time: '', end_time: '',
    location: '', priority: 'medium', status: 'interested', notes: '', ...initial,
  });
  const { saving, error, submit } = useSubmit(async () => {
    const body = Object.fromEntries(Object.entries(v).map(([k, x]) => [k, x === '' ? null : x]));
    const r = editing ? await api.put(`/activities/${initial.id}`, body) : await api.post('/activities', body);
    refresh();
    if (r.conflicts?.length) {
      const c = r.conflicts[0];
      toast(`Saved, but it overlaps ${c.title} by ${fmtDuration(c.overlapMinutes)}`, 'error', 5000);
    } else toast(editing ? 'Activity updated' : 'Activity added');
    onSaved?.(r.activity);
    onClose();
  });
  const del = async () => {
    await api.del(`/activities/${initial.id}`);
    refresh();
    toast('Activity removed', 'info');
    onClose();
  };
  return (
    <Modal wide title={editing ? 'Edit activity' : 'Add an activity'} onClose={onClose} footer={<Footer onClose={onClose} saving={saving} onDelete={editing ? del : null} label={editing ? 'Save' : 'Add activity'} />}>
      <form id="dialog-form" onSubmit={submit} className="form-grid">
        {error && <div className="form-error full">{error}</div>}
        <Field label="Activity" full><input className="input" placeholder="Programming Club meetup" autoFocus {...bind('title')} required /></Field>
        <Field label="Category"><select className="select" {...bind('category')}>{ACTIVITY_CATEGORIES.map((c) => <option key={c}>{c}</option>)}</select></Field>
        <Field label="Status">
          <select className="select" {...bind('status')}>{ACTIVITY_STATUSES.map((s) => <option key={s} value={s}>{s[0].toUpperCase() + s.slice(1)}</option>)}</select>
        </Field>
        <Field label="Event date"><input type="date" className="input" {...bind('event_date')} /></Field>
        <Field label="Registration deadline" hint="optional"><input type="date" className="input" {...bind('registration_deadline')} /></Field>
        <Field label="Starts"><input type="time" className="input" {...bind('start_time')} /></Field>
        <Field label="Ends"><input type="time" className="input" {...bind('end_time')} /></Field>
        <Field label="Location"><input className="input" placeholder="Lab 4" {...bind('location')} /></Field>
        <Field label="Priority">
          <select className="select" {...bind('priority')}><option value="high">High</option><option value="medium">Medium</option><option value="low">Low</option></select>
        </Field>
        <Field label="Description" full><textarea className="textarea" rows={2} {...bind('description')} /></Field>
        <Field label="Notes" full><input className="input" placeholder="Bring a laptop" {...bind('notes')} /></Field>
      </form>
    </Modal>
  );
}

export function ReminderDialog({ initial, onClose }) {
  const { refresh, toast } = useApp();
  const [refs, setRefs] = useState({ tasks: [], activities: [], classes: [], goals: [] });
  useEffect(() => {
    Promise.all([api.get('/tasks?status=pending,in_progress,rescheduled,missed'), api.get('/activities'), api.get('/classes'), api.get('/goals')])
      .then(([t, a, c, g]) => setRefs({
        tasks: t.tasks, classes: c.classes, goals: g.goals.filter((x) => x.deadline),
        activities: a.activities.filter((x) => !['completed', 'cancelled'].includes(x.status)),
      })).catch(() => {});
  }, []);
  const [v, setV, bind] = useForm({ reference_type: 'task', reference_id: '', offset: '1h', title: '', date: today(), time: '09:00', ...initial });
  const options = {
    task: refs.tasks.map((t) => [t.id, t.title]),
    deadline: refs.tasks.filter((t) => t.deadline).map((t) => [t.id, `${t.title} (${fmtDue(t.deadline).toLowerCase()})`]),
    activity: refs.activities.filter((a) => a.event_date).map((a) => [a.id, `${a.title} · ${fmtDate(a.event_date)}`]),
    registration: refs.activities.filter((a) => a.registration_deadline).map((a) => [a.id, `${a.title} registration · ${fmtDate(a.registration_deadline)}`]),
    class: refs.classes.map((c) => [c.id, `${c.course_code} · ${DAYS[c.day]} ${c.start_time}`]),
    goal: refs.goals.map((g) => [g.id, g.title]),
  };
  const { saving, error, submit } = useSubmit(async () => {
    const body = v.reference_type === 'custom' || v.offset === 'custom'
      ? { reference_type: v.reference_type, reference_id: v.reference_id || null, title: v.title || options[v.reference_type]?.find(([id]) => String(id) === String(v.reference_id))?.[1], reminder_time: `${v.date}T${v.time}` }
      : { reference_type: v.reference_type, reference_id: Number(v.reference_id), offset: v.offset, title: v.title || undefined };
    await api.post('/reminders', body);
    refresh();
    toast('Reminder set');
    onClose();
  });
  const custom = v.reference_type === 'custom' || v.offset === 'custom';
  return (
    <Modal title="Add a reminder" onClose={onClose} footer={<Footer onClose={onClose} saving={saving} label="Set reminder" />}>
      <form id="dialog-form" onSubmit={submit} className="form-grid">
        {error && <div className="form-error full">{error}</div>}
        <Field label="Remind me about">
          <select className="select" value={v.reference_type} onChange={(e) => setV((s) => ({ ...s, reference_type: e.target.value, reference_id: '' }))}>
            <option value="task">A goal task</option><option value="deadline">A deadline</option><option value="class">A class</option>
            <option value="activity">An extracurricular event</option><option value="registration">A registration deadline</option>
            <option value="goal">A goal deadline</option><option value="custom">Something else</option>
          </select>
        </Field>
        {v.reference_type !== 'custom' ? (
          <Field label="Which one">
            <select className="select" {...bind('reference_id')} required>
              <option value="">Choose…</option>
              {(options[v.reference_type] || []).map(([id, l]) => <option key={id} value={id}>{l}</option>)}
            </select>
          </Field>
        ) : (
          <Field label="Title"><input className="input" placeholder="Print my resume" {...bind('title')} required /></Field>
        )}
        {v.reference_type !== 'custom' && (
          <Field label="When" full>
            <div className="row wrap">
              {[['1h', '1 hour before'], ['1d', '1 day before'], ['3d', '3 days before'], ['7d', '7 days before'], ['custom', 'Custom']].map(([k, l]) => (
                <button type="button" key={k} className={`chip ${v.offset === k ? 'active' : ''}`} onClick={() => setV((s) => ({ ...s, offset: k }))}>{l}</button>
              ))}
            </div>
          </Field>
        )}
        {custom && (
          <>
            <Field label="Date"><input type="date" className="input" {...bind('date')} /></Field>
            <Field label="Time"><input type="time" className="input" {...bind('time')} /></Field>
          </>
        )}
      </form>
    </Modal>
  );
}

// Missed or unwanted slot → ranked free slots from the backend, split if nothing fits, risk if time runs out.
export function RescheduleDialog({ task: initialTask, onClose }) {
  const { refresh, toast } = useApp();
  const navigate = useNavigate();
  const [data, setData] = useState(null);
  const [error, setError] = useState(null);
  const [picked, setPicked] = useState(0);
  const [manual, setManual] = useState(false);
  const [manualAt, setManualAt] = useState({ date: today(), time: '18:00' });
  const [newDeadline, setNewDeadline] = useState('');
  const [busy, setBusy] = useState(false);

  const load = () => api.get(`/tasks/${initialTask.id}/suggestions`).then(setData).catch((e) => setError(e.message));
  useEffect(() => { load(); }, [initialTask.id]); // eslint-disable-line react-hooks/exhaustive-deps

  const run = async (fn, msg) => {
    setBusy(true);
    setError(null);
    try {
      await fn();
      refresh();
      toast(msg);
      onClose();
    } catch (e) {
      setError(e.message);
    } finally {
      setBusy(false);
    }
  };

  const t = data?.task || initialTask;
  const s = data?.suggestions || [];
  const askAi = () => { onClose(); navigate(`/assistant?task=${t.id}`); };

  return (
    <Modal wide title={t.status === 'missed' ? "You didn't complete this task" : 'Find a new time'} onClose={onClose}
      footer={data && (
        <>
          <button className="btn ghost" onClick={askAi}><MessageCircle size={16} />Ask AI</button>
          <button className="btn" onClick={() => setManual((m) => !m)}><CalendarDays size={16} />Choose manually</button>
          {s.length > 0 && (
            <button className="btn primary" disabled={busy} onClick={() => run(() => api.post(`/tasks/${t.id}/move`, { start: s[picked].start, end: s[picked].end }), `Task moved to ${s[picked].label}`)}>
              <CalendarClock size={16} />Reschedule
            </button>
          )}
        </>
      )}>
      <div className="stack">
        <div className="row wrap" style={{ gap: 16 }}>
          <div className="grow">
            <div className="item-title">{t.title}</div>
            <div className="item-meta">{t.goal_title || 'Task'}</div>
          </div>
          <div className="row small"><Clock size={15} className="muted" />{fmtDuration(t.estimated_minutes)}</div>
          <div className="row small"><CalendarDays size={15} className="muted" />{t.deadline ? fmtDue(t.deadline) : 'No deadline'}</div>
          <PriorityBadge priority={t.priority} />
        </div>
        {error && <div className="form-error">{error}</div>}
        {!data && !error && <Spinner label="Checking your classes, activities and free time…" />}

        {data?.risk && (
          <div className="conflict">
            <div className="row" style={{ marginBottom: 6 }}><AlertTriangle size={18} color="var(--danger)" /><strong>Deadline at risk</strong></div>
            <p className="small">Needs {fmtDuration(data.risk.requiredMinutes)}, but only {fmtDuration(data.risk.availableMinutes)} is free before the deadline.</p>
            <div className="row wrap" style={{ marginTop: 10 }}>
              <input type="date" className="input sm" style={{ width: 160 }} min={today()} value={newDeadline} onChange={(e) => setNewDeadline(e.target.value)} />
              <button className="btn sm" disabled={!newDeadline || busy} onClick={() => run(() => api.put(`/tasks/${t.id}`, { deadline: newDeadline }), 'Deadline extended')}>Extend deadline</button>
              <button className="btn sm" onClick={() => { onClose(); navigate('/schedule?view=week'); }}>Reduce lower-priority tasks</button>
              <button className="btn sm ghost" onClick={askAi}>Ask AI for advice</button>
            </div>
          </div>
        )}

        {s.length > 0 && (
          <div className="stack tight">
            <span className="small strong muted">Best time</span>
            {s.map((o, i) => (
              <button key={o.start} onClick={() => setPicked(i)} className="item" style={{ textAlign: 'left', cursor: 'pointer', borderLeftColor: i === picked ? 'var(--primary)' : 'var(--border-strong)', background: i === picked ? 'var(--primary-soft)' : undefined }}>
                <div className="grow">
                  <div className="item-title">{o.label}</div>
                  <div className="item-meta">{o.reasons.join(' · ') || 'Free and before the deadline'}</div>
                </div>
                {i === 0 && <span className="badge primary"><Sparkles size={12} />Recommended</span>}
              </button>
            ))}
            {s.length > 1 && <span className="tiny muted">Other options are on different days so you can keep your evenings flexible.</span>}
          </div>
        )}

        {data && !s.length && data.split && (
          <div className="card flat" style={{ background: 'var(--surface-2)' }}>
            <div className="row" style={{ marginBottom: 8 }}><Scissors size={17} /><strong>No single slot fits {fmtDuration(t.estimated_minutes)}</strong></div>
            {data.split.chunks.length > 1 ? (
              <>
                <p className="small muted" style={{ marginBottom: 10 }}>Split it into {data.split.chunks.length} parts instead?</p>
                <div className="stack tight">
                  {data.split.chunks.map((c) => <div key={c.start} className="free"><strong>{fmtDuration(c.minutes)}</strong>{c.label}</div>)}
                </div>
                {!data.split.possible && <p className="small" style={{ color: 'var(--danger-text)', marginTop: 8 }}>Still {fmtDuration(data.split.missingMinutes)} short before the deadline.</p>}
                <button className="btn primary sm" style={{ marginTop: 12 }} disabled={busy}
                  onClick={() => run(() => api.post(`/tasks/${t.id}/split`, { chunks: data.split.chunks }), `Split into ${data.split.chunks.length} parts`)}>
                  Split task
                </button>
              </>
            ) : <p className="small muted">There isn't enough free time before the deadline. Extend it or ask the assistant what to drop.</p>}
          </div>
        )}

        {manual && (
          <div className="row wrap">
            <input type="date" className="input sm" style={{ width: 170 }} value={manualAt.date} min={today()} onChange={(e) => setManualAt((m) => ({ ...m, date: e.target.value }))} />
            <input type="time" className="input sm" style={{ width: 130 }} value={manualAt.time} onChange={(e) => setManualAt((m) => ({ ...m, time: e.target.value }))} />
            <button className="btn sm primary" disabled={busy}
              onClick={() => run(() => api.post(`/tasks/${t.id}/move`, { start: `${manualAt.date}T${manualAt.time}` }), 'Task moved')}>
              Move here
            </button>
            <span className="tiny muted">We'll check it doesn't clash with anything.</span>
          </div>
        )}
      </div>
    </Modal>
  );
}

const DIALOGS = { class: ClassDialog, task: TaskDialog, goal: GoalDialog, activity: ActivityDialog, reminder: ReminderDialog, reschedule: RescheduleDialog };

export function DialogHost() {
  const { dialog, closeDialog } = useApp();
  if (!dialog) return null;
  const C = DIALOGS[dialog.type];
  return C ? <C {...dialog.props} onClose={closeDialog} /> : null;
}
